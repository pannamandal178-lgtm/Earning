export const COINS_PER_AD = 5;
export const COINS_PER_QUIZ = 5;
export const COINS_DAILY_BONUS = 10;
export const DAILY_AD_LIMIT = 20;
export const DAILY_QUIZ_LIMIT = 20;
export const AD_COOLDOWN_MS = 10000;
export const REFERRAL_BONUS = 50; // both the new user and the referrer get 50 coins

// Complete Task & Earn (ad link tab). Admin can change reward and link from Admin Hub > Settings.
export const TASK_REWARD_COINS = 10;

// Play & Earn (Fruit Catch): max coins a user can earn from the game per day (admin can change it)
export const GAME_DAILY_COIN_LIMIT = 50;
export const TASK_MIN_SECONDS = 60;
export const COINS_PER_INR = 100;
export const WD_UPI_COINS = 2300;
export const WD_GIFT_COINS = 2000;
// Withdrawal rates (fixed):
// UPI: Rs20 = 2,500 coins, Rs50 = 6,250, Rs100 = 12,500
export const WD_UPI_COINS_PER_INR = 125;
// Google Play / Amazon gift card: Rs20 = 2,000 coins, Rs50 = 5,000, Rs100 = 10,000
export const WD_GIFT_COINS_PER_INR = 100;
export const ANTI_CHEAT_STRIKE_LIMIT = 5;

// Milestone bonus coins, keyed by ad/quiz count reached in a single day
export const MILESTONE_BONUSES: { [count: number]: number } = {
  5: 10,
  10: 20,
  20: 50,
};

export const CPAGRIP_PUBLISHER_ID = ""; // To be filled by user
export const CPAGRIP_OFFERWALL_ID = ""; // To be filled by user
export const CPALEAD_ID = ""; // To be filled by user
export const CUSTOM_OFFERWALL_URL = ""; // To be filled by user
export const MONLIX_ID = ""; // To be filled by user

// Ad Networks
export const GOOGLE_H5_AD_CLIENT = ""; // Google H5 Ads Client ID (ca-pub-xxx)

// How many people the leaderboard shows (everybody else only sees their own rank number)
export const LEADERBOARD_SIZE = 10;
