/** Monetag Vignette Banner (shows by itself; users get no reward for it). */
export const VIGNETTE_SCRIPT = 'https://n6wxm.com/vignette.min.js';
export const VIGNETTE_ZONE = '12169230';

let lastShown = 0;

/**
 * Loads the Vignette tag again so a new ad can appear (for example when the Offers page or the Offerwall opens).
 * Monetag decides if an ad really shows (frequency settings). We only ask at most once every `minGapMs`.
 */
export function showVignetteAd(minGapMs = 20000) {
  const now = Date.now();
  if (now - lastShown < minGapMs) return;
  lastShown = now;
  try {
    document.querySelectorAll('script[data-vignette]').forEach((el) => el.remove());
    const s = document.createElement('script');
    s.dataset.zone = VIGNETTE_ZONE;
    s.dataset.vignette = '1';
    s.src = VIGNETTE_SCRIPT;
    const host = [document.documentElement, document.body].filter(Boolean).pop() as HTMLElement;
    host.appendChild(s);
  } catch (_) {
    /* the page works without the ad */
  }
}
