/** Daily "Complete Task" feature: shared settings and helpers. */
export const TASK_SERVER_URL = 'https://earning-nk1y.onrender.com'; // the postback / task server (Render)
export const TASK_DAY_OFFSET_MIN = 330; // India time (UTC+5:30) - must match DAY_UTC_OFFSET_MINUTES on the server
// Monetag "Vignette Banner" tag
export const TASK_AD_SCRIPT = 'https://n6wxm.com/vignette.min.js';
export const TASK_AD_ZONE = '12169230';

export const TASK_DEFAULTS = { dailyLimit: 7, waitSeconds: 5 };

/** Calendar day (YYYY-MM-DD) in India time. */
export const taskDay = (ms: number): string =>
  new Date(ms + TASK_DAY_OFFSET_MIN * 60000).toISOString().slice(0, 10);

export interface TaskConfig {
  dailyLimit: number;
  waitSeconds: number;
  /** coins to pay for finishing N tasks in one day, e.g. { "1": 4, "6": 20 } */
  payout: Record<string, number>;
}

const intIn = (v: unknown, min: number, max: number, fallback: number) => {
  const n = Math.floor(Number(v));
  return Number.isFinite(n) && n >= min && n <= max ? n : fallback;
};

export function normalizeTaskConfig(raw: any): TaskConfig {
  const payout: Record<string, number> = {};
  const src = raw && typeof raw.payout === 'object' && raw.payout ? raw.payout : {};
  for (const k of Object.keys(src)) {
    const n = Number(k);
    const coins = Math.floor(Number(src[k]));
    if (Number.isInteger(n) && n >= 1 && n <= 100 && Number.isFinite(coins) && coins >= 0) payout[String(n)] = coins;
  }
  return {
    dailyLimit: intIn(raw?.dailyLimit, 1, 100, TASK_DEFAULTS.dailyLimit),
    waitSeconds: intIn(raw?.waitSeconds, 1, 120, TASK_DEFAULTS.waitSeconds),
    payout
  };
}

/** Coins for finishing `count` tasks: the exact entry, otherwise the closest lower entry, otherwise 0. */
export function coinsForTasks(cfg: TaskConfig, count: number): number {
  if (count <= 0) return 0;
  const exact = cfg.payout[String(count)];
  if (exact !== undefined) return exact;
  let best = 0;
  let bestN = 0;
  for (const k of Object.keys(cfg.payout)) {
    const n = Number(k);
    if (n <= count && n > bestN) {
      bestN = n;
      best = cfg.payout[k];
    }
  }
  return best;
}

/** Loads the Vignette ad tag (same code Monetag gave us). A fresh script is added on every task so the ad shows again. */
export function injectTaskAd() {
  try {
    document.querySelectorAll('script[data-task-ad]').forEach((el) => el.remove());
    const s = document.createElement('script');
    s.dataset.zone = TASK_AD_ZONE;
    s.dataset.taskAd = '1';
    s.src = TASK_AD_SCRIPT;
    const host = [document.documentElement, document.body].filter(Boolean).pop() as HTMLElement;
    host.appendChild(s);
  } catch (_) {
    /* the task still works, only the ad is missing */
  }
}
