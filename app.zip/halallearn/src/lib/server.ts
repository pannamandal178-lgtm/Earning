/** The small helper server on Render (postbacks and the automatic account clean-up). */
export const SERVER_URL = 'https://earning-nk1y.onrender.com';

let lastPing = 0;
/**
 * Tells the server the app is open. That wakes the free server up and lets it match the database with
 * Firebase Authentication (accounts deleted there are removed here). Fire-and-forget, at most once every 2 minutes.
 */
export function pingSync() {
  const now = Date.now();
  if (now - lastPing < 120000) return;
  lastPing = now;
  fetch(`${SERVER_URL}/sync/ping`, { mode: 'no-cors' }).catch(() => {});
}
