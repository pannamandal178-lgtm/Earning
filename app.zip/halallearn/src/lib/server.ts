/** The small helper server on Render (postbacks and admin tools). */
export const SERVER_URL = 'https://earning-nk1y.onrender.com';
