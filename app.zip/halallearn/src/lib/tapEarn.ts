/** Tap & Earn: shared settings and helpers. */
export const TAP_DAY_OFFSET_MIN = 330; // India time (UTC+5:30); must match DAY_UTC_OFFSET_MINUTES on the server

export const TAP_DEFAULTS = { dailyLimit: 9, batchSize: 3, restSeconds: 15, longRestMinutes: 60 };

export interface TapConfig {
  dailyLimit: number; // taps per user per day
  batchSize: number; // taps before the long rest
  restSeconds: number; // wait after every tap
  longRestMinutes: number; // rest after a full batch
}

const intIn = (v: unknown, min: number, max: number, fallback: number) => {
  const n = Math.floor(Number(v));
  return Number.isFinite(n) && n >= min && n <= max ? n : fallback;
};

export function normalizeTapConfig(raw: any): TapConfig {
  return {
    dailyLimit: intIn(raw?.dailyLimit, 1, 100, TAP_DEFAULTS.dailyLimit),
    batchSize: intIn(raw?.batchSize, 1, 100, TAP_DEFAULTS.batchSize),
    restSeconds: intIn(raw?.restSeconds, 0, 600, TAP_DEFAULTS.restSeconds),
    longRestMinutes: intIn(raw?.longRestMinutes, 0, 1440, TAP_DEFAULTS.longRestMinutes)
  };
}

/** Calendar day (YYYY-MM-DD) in India time. */
export const tapDay = (ms: number): string =>
  new Date(ms + TAP_DAY_OFFSET_MIN * 60000).toISOString().slice(0, 10);

// Monetag "Rewarded interstitial" (the code Monetag gave us). The SDK adds a function show_11932994() to the page.
export const REWARDED_ZONE = '11932994';
export const REWARDED_SDK = 'https://libtl.com/sdk.js';
const REWARDED_FN = `show_${REWARDED_ZONE}`;

let sdkLoaded = false;

/** Loads the rewarded ad SDK once. Call it early (when the card is shown) so it is ready at the tap. */
export function loadRewardedSdk() {
  if (sdkLoaded || document.querySelector('script[data-rewarded-sdk]')) return;
  sdkLoaded = true;
  try {
    const s = document.createElement('script');
    s.src = REWARDED_SDK;
    s.dataset.zone = REWARDED_ZONE;
    s.dataset.sdk = REWARDED_FN;
    s.dataset.rewardedSdk = '1';
    s.async = true;
    s.onerror = () => {
      sdkLoaded = false; // most likely an ad blocker; the next tap tries again
    };
    document.head.appendChild(s);
  } catch (_) {
    sdkLoaded = false;
  }
}

/**
 * Shows the rewarded interstitial. Call it straight inside the tap.
 * Resolves when the SDK says the ad was watched, rejects on an error or after 3 minutes.
 * Returns null when the SDK is not ready yet.
 */
export function showRewardedAd(): Promise<void> | null {
  const fn = (window as any)[REWARDED_FN];
  if (typeof fn !== 'function') {
    loadRewardedSdk();
    return null;
  }
  let ad: Promise<void>;
  try {
    ad = Promise.resolve(fn()).then(() => undefined);
  } catch (e) {
    return Promise.reject(e);
  }
  const timeout = new Promise<never>((_, reject) => setTimeout(() => reject(new Error('timeout')), 180000));
  return Promise.race([ad, timeout]);
}
