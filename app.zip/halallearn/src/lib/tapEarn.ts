/** Tap & Earn: shared settings and helpers. */
export const TAP_DAY_OFFSET_MIN = 330; // India time (UTC+5:30); must match DAY_UTC_OFFSET_MINUTES on the server
export const ADCASH_ZONE = '12425038'; // Adcash Pop ad
export const ADCASH_SCRIPT = 'https://acscdn.com/script/aclib.js';

export const TAP_DEFAULTS = { dailyLimit: 9, batchSize: 3, restSeconds: 15, longRestMinutes: 60 };

export interface TapConfig {
  dailyLimit: number; // taps per user per day
  batchSize: number; // taps before the long rest
  restSeconds: number; // wait after every tap
  longRestMinutes: number; // rest after a full batch
}

const intIn = (v: unknown, min: number, max: number, fallback: number) => {
  const n = Math.floor(Number(v));
  return Number.isFinite(n) && n >= min && n <= max ? n : fallback;
};

export function normalizeTapConfig(raw: any): TapConfig {
  return {
    dailyLimit: intIn(raw?.dailyLimit, 1, 100, TAP_DEFAULTS.dailyLimit),
    batchSize: intIn(raw?.batchSize, 1, 100, TAP_DEFAULTS.batchSize),
    restSeconds: intIn(raw?.restSeconds, 0, 600, TAP_DEFAULTS.restSeconds),
    longRestMinutes: intIn(raw?.longRestMinutes, 0, 1440, TAP_DEFAULTS.longRestMinutes)
  };
}

/** Calendar day (YYYY-MM-DD) in India time. */
export const tapDay = (ms: number): string =>
  new Date(ms + TAP_DAY_OFFSET_MIN * 60000).toISOString().slice(0, 10);

let aclibPromise: Promise<void> | null = null;

/** Loads the Adcash script once (the same script Adcash gave us). */
export function loadAclib(): Promise<void> {
  if (aclibPromise) return aclibPromise;
  aclibPromise = new Promise<void>((resolve, reject) => {
    if ((window as any).aclib) return resolve();
    const s = document.createElement('script');
    s.id = 'aclib';
    s.type = 'text/javascript';
    s.src = ADCASH_SCRIPT;
    s.async = true;
    s.onload = () => resolve();
    s.onerror = () => {
      aclibPromise = null;
      reject(new Error('aclib'));
    };
    document.head.appendChild(s);
  });
  return aclibPromise;
}

/** Shows the Adcash Pop ad. Call it straight inside the tap so the browser allows the pop-up. */
export function runAdcashPop() {
  const w = window as any;
  try {
    if (w.aclib && typeof w.aclib.runPop === 'function') {
      w.aclib.runPop({ zoneId: ADCASH_ZONE });
      return;
    }
    loadAclib()
      .then(() => w.aclib?.runPop?.({ zoneId: ADCASH_ZONE }))
      .catch(() => {});
  } catch (_) {
    /* the tap is still counted, only the ad is missing */
  }
}
