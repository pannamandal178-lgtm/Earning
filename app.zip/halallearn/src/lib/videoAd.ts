/**
 * Video ad (VAST tag from Adcash "youradexchange.com") played with Google's IMA SDK.
 * The ad opens full screen. The result tells if it was watched to the end.
 */
export const VIDEO_AD_TAG = 'https://youradexchange.com/video/select.php?r=12427842';
const IMA_SDK = 'https://imasdk.googleapis.com/js/sdkloader/ima3.js';

let imaPromise: Promise<void> | null = null;
let imaFailed = false;

/** Loads the IMA SDK once. Call it early (for example when the card is shown) so it is ready at the tap. */
export function loadIma(): Promise<void> {
  if (imaPromise) return imaPromise;
  imaPromise = new Promise<void>((resolve, reject) => {
    if ((window as any).google?.ima) return resolve();
    const s = document.createElement('script');
    s.src = IMA_SDK;
    s.async = true;
    s.onload = () => resolve();
    s.onerror = () => {
      imaFailed = true; // most likely an ad blocker
      imaPromise = null;
      reject(new Error('ima'));
    };
    document.head.appendChild(s);
  });
  return imaPromise;
}

export interface VideoAdResult {
  /** complete = watched to the end; skipped = closed or skipped; no-ad = nothing to show; blocked = SDK blocked; loading = SDK not ready yet */
  status: 'complete' | 'skipped' | 'no-ad' | 'error' | 'blocked' | 'loading';
  code?: number;
  message?: string;
}

/**
 * Plays the video ad full screen. Call it straight inside the user's tap
 * (the first part runs before any await, so the browser lets the ad play with sound).
 */
export function runVideoAd(): Promise<VideoAdResult> {
  const g = (window as any).google;
  if (!g || !g.ima) {
    const failed = imaFailed;
    loadIma().catch(() => {});
    return Promise.resolve({ status: failed ? 'blocked' : 'loading' });
  }

  return new Promise<VideoAdResult>((resolve) => {
    const overlay = document.createElement('div');
    overlay.style.cssText =
      'position:fixed;left:0;top:0;width:100%;height:100%;background:#000;z-index:2147483000;overflow:hidden;';
    const video = document.createElement('video');
    video.setAttribute('playsinline', '');
    video.style.cssText = 'position:absolute;left:0;top:0;width:100%;height:100%;background:#000;';
    const adContainer = document.createElement('div');
    adContainer.style.cssText = 'position:absolute;left:0;top:0;width:100%;height:100%;';
    const msg = document.createElement('div');
    msg.textContent = 'Loading video ad...';
    msg.style.cssText =
      'position:absolute;left:0;right:0;top:50%;text-align:center;color:#94a3b8;font:600 13px sans-serif;';
    const close = document.createElement('button');
    close.textContent = '\u2715';
    close.setAttribute('aria-label', 'Close');
    close.style.cssText =
      'position:absolute;right:10px;top:10px;z-index:5;width:36px;height:36px;border-radius:18px;border:0;background:rgba(255,255,255,0.15);color:#fff;font-size:16px;';
    overlay.append(video, adContainer, msg, close);
    document.body.appendChild(overlay);

    let finished = false;
    let completed = false;
    let adsManager: any = null;
    let adsLoader: any = null;

    const onResize = () => {
      try {
        adsManager?.resize(window.innerWidth, window.innerHeight, g.ima.ViewMode.NORMAL);
      } catch (_) {
        /* ignore */
      }
    };

    const finish = (r: VideoAdResult) => {
      if (finished) return;
      finished = true;
      clearTimeout(loadTimer);
      clearTimeout(maxTimer);
      window.removeEventListener('resize', onResize);
      try {
        adsManager?.destroy();
      } catch (_) {
        /* ignore */
      }
      try {
        adsLoader?.destroy();
      } catch (_) {
        /* ignore */
      }
      overlay.remove();
      resolve(r);
    };

    // no ad started within 15 seconds -> give up; whole ad must end within 3 minutes
    const loadTimer = setTimeout(() => finish({ status: 'error', code: 0, message: 'timeout' }), 15000);
    const maxTimer = setTimeout(() => finish({ status: 'error', code: 0, message: 'too long' }), 180000);
    close.onclick = () => finish({ status: 'skipped' });
    window.addEventListener('resize', onResize);

    const onError = (e: any) => {
      const err = e?.getError?.();
      const code: number | undefined = err?.getErrorCode?.();
      const message: string | undefined = err?.getMessage?.();
      // 1009 = empty VAST answer, 303 = no ads after wrapper: there is simply no ad to show now
      finish({ status: code === 1009 || code === 303 ? 'no-ad' : 'error', code, message });
    };

    try {
      const container = new g.ima.AdDisplayContainer(adContainer, video);
      container.initialize(); // must happen inside the tap
      adsLoader = new g.ima.AdsLoader(container);
      adsLoader.addEventListener(g.ima.AdErrorEvent.Type.AD_ERROR, onError, false);
      adsLoader.addEventListener(
        g.ima.AdsManagerLoadedEvent.Type.ADS_MANAGER_LOADED,
        (evt: any) => {
          try {
            const settings = new g.ima.AdsRenderingSettings();
            settings.restoreCustomPlaybackStateOnAdBreakComplete = true;
            adsManager = evt.getAdsManager(video, settings);
            adsManager.addEventListener(g.ima.AdErrorEvent.Type.AD_ERROR, onError);
            adsManager.addEventListener(g.ima.AdEvent.Type.STARTED, () => {
              clearTimeout(loadTimer);
              msg.style.display = 'none';
            });
            adsManager.addEventListener(g.ima.AdEvent.Type.COMPLETE, () => {
              completed = true;
            });
            adsManager.addEventListener(g.ima.AdEvent.Type.SKIPPED, () => finish({ status: 'skipped' }));
            adsManager.addEventListener(g.ima.AdEvent.Type.ALL_ADS_COMPLETED, () =>
              finish({ status: completed ? 'complete' : 'skipped' })
            );
            adsManager.init(window.innerWidth, window.innerHeight, g.ima.ViewMode.NORMAL);
            adsManager.start();
          } catch (err: any) {
            finish({ status: 'error', code: 0, message: String(err?.message || err) });
          }
        },
        false
      );
      const request = new g.ima.AdsRequest();
      request.adTagUrl = VIDEO_AD_TAG;
      request.linearAdSlotWidth = window.innerWidth;
      request.linearAdSlotHeight = window.innerHeight;
      request.nonLinearAdSlotWidth = window.innerWidth;
      request.nonLinearAdSlotHeight = 150;
      adsLoader.requestAds(request);
    } catch (err: any) {
      finish({ status: 'error', code: 0, message: String(err?.message || err) });
    }
  });
}
