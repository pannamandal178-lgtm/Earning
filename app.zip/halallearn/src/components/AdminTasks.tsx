import React, { useCallback, useEffect, useState } from 'react';
import { collection, doc, getDoc, getDocs, increment, query, setDoc, where, writeBatch } from 'firebase/firestore';
import { toast } from 'react-hot-toast';
import { Loader2 } from 'lucide-react';
import { db } from '../firebase';
import { coinsForTasks, normalizeTaskConfig, taskDay, type TaskConfig } from '../lib/taskGame';

interface Row {
  id: string;
  uid: string;
  name: string;
  email: string;
  count: number;
  paid: boolean;
  paidCoins: number;
}

const inputCls =
  'w-full h-11 bg-white/5 border border-white/10 rounded-xl px-3 text-sm outline-none focus:border-accent/40 transition-all';
const labelCls = 'text-[10px] text-gray-500 uppercase font-bold px-1';

/**
 * Admin Hub -> Tasks.
 *  - set the daily limit, the wait time, the ad zone and how many coins N finished tasks are worth
 *  - see how many tasks every user finished on a day
 *  - pay that day (only yesterday or earlier, never today)
 */
export function AdminTasksTab() {
  const todayStr = taskDay(Date.now());
  const yesterdayStr = taskDay(Date.now() - 86400000);

  const [saved, setSaved] = useState<TaskConfig>(normalizeTaskConfig(null));
  const [limit, setLimit] = useState('7');
  const [wait, setWait] = useState('5');
  const [zone, setZone] = useState('');
  const [table, setTable] = useState<string[]>([]);
  const [perTask, setPerTask] = useState('');
  const [saving, setSaving] = useState(false);

  const [date, setDate] = useState(yesterdayStr);
  const [rows, setRows] = useState<Row[]>([]);
  const [loadingRows, setLoadingRows] = useState(false);
  const [paying, setPaying] = useState(false);

  // ---- settings
  useEffect(() => {
    (async () => {
      try {
        const s = await getDoc(doc(db, 'appConfig', 'taskGame'));
        const cfg = normalizeTaskConfig(s.exists() ? s.data() : null);
        setSaved(cfg);
        setLimit(String(cfg.dailyLimit));
        setWait(String(cfg.waitSeconds));
        setZone(cfg.adZone);
        setTable(Array.from({ length: cfg.dailyLimit }, (_, i) => (cfg.payout[String(i + 1)] ?? '').toString()));
      } catch (_) {
        toast.error('Could not load the task settings');
      }
    })();
  }, []);

  const limitNum = Math.max(1, Math.min(100, Math.floor(Number(limit)) || 1));

  // keep the table length in step with the limit
  useEffect(() => {
    setTable((prev) => Array.from({ length: limitNum }, (_, i) => prev[i] ?? ''));
  }, [limitNum]);

  const fillFromRate = () => {
    const r = Math.floor(Number(perTask));
    if (!Number.isFinite(r) || r < 0) {
      toast.error('Write a number, for example 4');
      return;
    }
    setTable(Array.from({ length: limitNum }, (_, i) => String(r * (i + 1))));
    toast.success(`Table filled: 1 task = ${r} coins. Change any row if you want, then Save.`);
  };

  const save = async () => {
    const waitNum = Math.floor(Number(wait));
    if (!Number.isFinite(waitNum) || waitNum < 1 || waitNum > 120) return toast.error('Wait time must be 1 to 120 seconds');
    if (!/^\d{4,12}$/.test(zone.trim())) return toast.error('Ad zone must be a number');
    const payout: Record<string, number> = {};
    for (let i = 0; i < limitNum; i++) {
      const raw = (table[i] ?? '').trim();
      if (raw === '') continue;
      const v = Math.floor(Number(raw));
      if (!Number.isFinite(v) || v < 0) return toast.error(`Row ${i + 1}: write a number`);
      payout[String(i + 1)] = v;
    }
    setSaving(true);
    try {
      await setDoc(doc(db, 'appConfig', 'taskGame'), {
        dailyLimit: limitNum,
        waitSeconds: waitNum,
        adZone: zone.trim(),
        payout,
        updatedAt: Date.now()
      });
      setSaved(normalizeTaskConfig({ dailyLimit: limitNum, waitSeconds: waitNum, adZone: zone.trim(), payout }));
      toast.success('Saved');
    } catch (_) {
      toast.error('Could not save');
    } finally {
      setSaving(false);
    }
  };

  // ---- users of the chosen day
  const loadRows = useCallback(async () => {
    setLoadingRows(true);
    try {
      const snap = await getDocs(query(collection(db, 'gameTasks'), where('date', '==', date)));
      const list: Row[] = snap.docs.map((d) => {
        const x: any = d.data();
        return {
          id: d.id,
          uid: String(x.uid || d.id.split('_')[0]),
          name: String(x.name || ''),
          email: String(x.email || ''),
          count: Number(x.count) || 0,
          paid: x.paid === true,
          paidCoins: Number(x.paidCoins) || 0
        };
      });
      list.sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));
      setRows(list);
    } catch (_) {
      toast.error('Could not load the list');
    } finally {
      setLoadingRows(false);
    }
  }, [date]);

  useEffect(() => {
    loadRows();
  }, [loadRows]);

  const canPay = date < todayStr;
  const coinsFor = (n: number) => coinsForTasks(saved, n);
  const payable = rows.filter((r) => !r.paid && coinsFor(r.count) > 0);
  const totalCoins = payable.reduce((sum, r) => sum + coinsFor(r.count), 0);

  const payAll = async () => {
    if (!canPay) return toast.error("Today's tasks can only be paid tomorrow or later");
    if (payable.length === 0) return toast.error('Nobody to pay (check the rates and Save them first)');
    if (!window.confirm(`Pay ${totalCoins.toLocaleString()} coins to ${payable.length} users for ${date}?`)) return;

    setPaying(true);
    let paidUsers = 0;
    let failed = 0;
    try {
      const writeFor = (batch: ReturnType<typeof writeBatch>, r: Row) => {
        const c = coinsFor(r.count);
        batch.update(doc(db, 'users', r.uid), {
          coins: increment(c),
          totalEarnings: increment(c),
          weeklyCoins: increment(c),
          monthlyCoins: increment(c)
        });
        batch.set(doc(db, 'gameTasks', r.id), { paid: true, paidCoins: c, paidAt: Date.now() }, { merge: true });
        batch.set(doc(db, 'users', r.uid, 'transactions', `task_${date}`), {
          type: 'task',
          amount: c,
          note: `Daily tasks (${r.count} done) - ${date}`,
          createdAt: Date.now()
        });
      };
      for (let i = 0; i < payable.length; i += 150) {
        const chunk = payable.slice(i, i + 150);
        try {
          const batch = writeBatch(db);
          chunk.forEach((r) => writeFor(batch, r));
          await batch.commit();
          paidUsers += chunk.length;
        } catch (_) {
          // one bad user (for example a deleted account) must not stop the others
          for (const r of chunk) {
            try {
              const b = writeBatch(db);
              writeFor(b, r);
              await b.commit();
              paidUsers += 1;
            } catch (__) {
              failed += 1;
            }
          }
        }
      }
      toast.success(`Paid ${paidUsers} users${failed ? `, ${failed} failed` : ''}`);
    } finally {
      setPaying(false);
      loadRows();
    }
  };

  return (
    <div className="space-y-6">
      {/* ---- settings ---- */}
      <div className="bg-surface border border-border rounded-2xl p-4 space-y-4">
        <h3 className="text-sm font-black">Task settings</h3>
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1">
            <label className={labelCls}>Tasks per user per day</label>
            <input className={inputCls} inputMode="numeric" value={limit} onChange={(e) => setLimit(e.target.value)} />
          </div>
          <div className="space-y-1">
            <label className={labelCls}>Seconds to stay on ad</label>
            <input className={inputCls} inputMode="numeric" value={wait} onChange={(e) => setWait(e.target.value)} />
          </div>
        </div>
        <div className="space-y-1">
          <label className={labelCls}>Ad zone number</label>
          <input className={inputCls + ' font-mono'} inputMode="numeric" value={zone} onChange={(e) => setZone(e.target.value)} />
        </div>

        <div className="space-y-2">
          <label className={labelCls}>Quick fill: 1 task = how many coins?</label>
          <div className="flex gap-2">
            <input className={inputCls} inputMode="numeric" placeholder="4" value={perTask} onChange={(e) => setPerTask(e.target.value)} />
            <button onClick={fillFromRate} className="px-4 rounded-xl bg-white/10 text-xs font-bold shrink-0">
              Fill table
            </button>
          </div>
        </div>

        <div className="space-y-2">
          <label className={labelCls}>Coins for finishing N tasks in a day (change any row)</label>
          <div className="grid grid-cols-2 gap-2">
            {Array.from({ length: limitNum }, (_, i) => (
              <div key={i} className="flex items-center gap-2">
                <span className="text-xs text-text-muted w-16 shrink-0">{i + 1} {i === 0 ? 'task' : 'tasks'}</span>
                <input
                  className={inputCls}
                  inputMode="numeric"
                  value={table[i] ?? ''}
                  onChange={(e) => setTable((prev) => prev.map((v, k) => (k === i ? e.target.value : v)))}
                />
              </div>
            ))}
          </div>
          <p className="text-[10px] text-text-muted">An empty row means 0 coins for that number of tasks.</p>
        </div>

        <button onClick={save} disabled={saving} className="w-full h-12 rounded-xl bg-accent text-black font-black text-sm">
          {saving ? 'Saving...' : 'Save settings'}
        </button>
      </div>

      {/* ---- users of one day ---- */}
      <div className="bg-surface border border-border rounded-2xl p-4 space-y-4">
        <h3 className="text-sm font-black">Tasks done by users</h3>
        <div className="flex gap-2 items-center">
          <input
            type="date"
            className={inputCls}
            value={date}
            max={todayStr}
            onChange={(e) => e.target.value && setDate(e.target.value)}
          />
          <button onClick={loadRows} className="px-4 h-11 rounded-xl bg-white/10 text-xs font-bold shrink-0">
            Refresh
          </button>
        </div>

        {!canPay && (
          <p className="text-[11px] text-yellow-400 font-bold">
            This is today. Coins can only be given for yesterday or earlier. Pick an earlier date to pay.
          </p>
        )}

        {loadingRows ? (
          <div className="py-6 flex justify-center">
            <Loader2 className="animate-spin text-accent" />
          </div>
        ) : rows.length === 0 ? (
          <p className="text-xs text-text-muted">Nobody finished a task on {date}.</p>
        ) : (
          <div className="space-y-2">
            {rows.map((r) => (
              <div key={r.id} className="flex items-center justify-between gap-3 bg-white/5 rounded-xl px-3 py-2">
                <div className="min-w-0">
                  <p className="text-sm font-bold truncate">{r.name || r.uid}</p>
                  <p className="text-[10px] text-text-muted truncate">{r.email}</p>
                </div>
                <div className="text-right shrink-0">
                  <p className="text-sm font-black">{r.count} {r.count === 1 ? 'task' : 'tasks'}</p>
                  <p className={'text-[10px] font-bold ' + (r.paid ? 'text-green-400' : 'text-accent')}>
                    {r.paid ? `Paid ${r.paidCoins}` : `${coinsFor(r.count)} coins`}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="flex items-center justify-between text-xs text-text-muted font-bold">
          <span>{rows.length} users</span>
          <span>To pay: {totalCoins.toLocaleString()} coins ({payable.length} users)</span>
        </div>

        <button
          onClick={payAll}
          disabled={paying || !canPay || payable.length === 0}
          className={
            'w-full h-12 rounded-xl font-black text-sm ' +
            (!canPay || payable.length === 0 ? 'bg-white/5 text-text-muted' : 'bg-accent text-black')
          }
        >
          {paying ? 'Paying...' : `Pay all for ${date}`}
        </button>
        <p className="text-[10px] text-text-muted">
          Rates used for paying are the saved ones above. Each user is paid only once per day, even if you press again.
        </p>
      </div>
    </div>
  );
}
