import React, { useCallback, useEffect, useState } from 'react';
import { collection, doc, getDoc, getDocs, increment, query, setDoc, where, writeBatch } from 'firebase/firestore';
import { toast } from 'react-hot-toast';
import { Loader2 } from 'lucide-react';
import { db } from '../firebase';
import { normalizeTapConfig, tapDay } from '../lib/tapEarn';

interface Row {
  id: string;
  uid: string;
  name: string;
  email: string;
  count: number;
  paid: boolean;
  paidCoins: number;
}

const inputCls =
  'w-full h-11 bg-white/5 border border-white/10 rounded-xl px-3 text-sm outline-none focus:border-accent/40 transition-all';
const labelCls = 'text-[10px] text-gray-500 uppercase font-bold px-1';

/**
 * Admin Hub -> Tap & Earn.
 *  - rules: ads per day, ads before the long rest, rest after every ad, long rest minutes
 *  - the list of users with how many ads each tapped on a day
 *  - type "coins per ad" and press Save & pay: every user gets (ads x coins per ad). Only yesterday or earlier.
 */
export function AdminTapTab() {
  const todayStr = tapDay(Date.now());
  const yesterdayStr = tapDay(Date.now() - 86400000);

  const [limit, setLimit] = useState('9');
  const [batch, setBatch] = useState('3');
  const [rest, setRest] = useState('15');
  const [longRest, setLongRest] = useState('60');
  const [saving, setSaving] = useState(false);

  const [date, setDate] = useState(yesterdayStr);
  const [rate, setRate] = useState('');
  const [rows, setRows] = useState<Row[]>([]);
  const [loadingRows, setLoadingRows] = useState(false);
  const [paying, setPaying] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const s = await getDoc(doc(db, 'appConfig', 'tapEarn'));
        const c = normalizeTapConfig(s.exists() ? s.data() : null);
        setLimit(String(c.dailyLimit));
        setBatch(String(c.batchSize));
        setRest(String(c.restSeconds));
        setLongRest(String(c.longRestMinutes));
      } catch (_) {
        toast.error('Could not load the settings');
      }
    })();
  }, []);

  const saveRules = async () => {
    const c = normalizeTapConfig({ dailyLimit: limit, batchSize: batch, restSeconds: rest, longRestMinutes: longRest });
    if (
      String(c.dailyLimit) !== String(Math.floor(Number(limit))) ||
      String(c.batchSize) !== String(Math.floor(Number(batch))) ||
      String(c.restSeconds) !== String(Math.floor(Number(rest))) ||
      String(c.longRestMinutes) !== String(Math.floor(Number(longRest)))
    ) {
      return toast.error('Check the numbers: ads per day 1-100, before rest 1-100, rest 0-600 seconds, long rest 0-1440 minutes');
    }
    setSaving(true);
    try {
      await setDoc(doc(db, 'appConfig', 'tapEarn'), { ...c, updatedAt: Date.now() });
      toast.success('Rules saved');
    } catch (_) {
      toast.error('Could not save');
    } finally {
      setSaving(false);
    }
  };

  const loadRows = useCallback(async () => {
    setLoadingRows(true);
    try {
      const snap = await getDocs(query(collection(db, 'tapDays'), where('date', '==', date)));
      const list: Row[] = snap.docs.map((d) => {
        const x: any = d.data();
        return {
          id: d.id,
          uid: String(x.uid || d.id.split('_')[0]),
          name: String(x.name || ''),
          email: String(x.email || ''),
          count: Number(x.count) || 0,
          paid: x.paid === true,
          paidCoins: Number(x.paidCoins) || 0
        };
      });
      list.sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));
      setRows(list);
    } catch (_) {
      toast.error('Could not load the list');
    } finally {
      setLoadingRows(false);
    }
  }, [date]);

  useEffect(() => {
    loadRows();
  }, [loadRows]);

  const rateNum = Math.floor(Number(rate));
  const rateOk = rate.trim() !== '' && Number.isFinite(rateNum) && rateNum > 0;
  const canPay = date < todayStr;
  const payable = rows.filter((r) => !r.paid && r.count > 0);
  const totalCoins = rateOk ? payable.reduce((sum, r) => sum + r.count * rateNum, 0) : 0;
  const totalAds = rows.reduce((sum, r) => sum + r.count, 0);

  const payAll = async () => {
    if (!canPay) return toast.error("Today's ads can only be paid tomorrow or later");
    if (!rateOk) return toast.error('Write how many coins one ad is worth');
    if (payable.length === 0) return toast.error('Nobody to pay on this date');
    if (
      !window.confirm(
        `Pay ${rateNum} coins per ad: ${totalCoins.toLocaleString()} coins to ${payable.length} users for ${date}?`
      )
    )
      return;

    setPaying(true);
    let paidUsers = 0;
    let failed = 0;
    try {
      const writeFor = (batchRef: ReturnType<typeof writeBatch>, r: Row) => {
        const c = r.count * rateNum;
        batchRef.update(doc(db, 'users', r.uid), {
          coins: increment(c),
          totalEarnings: increment(c),
          weeklyCoins: increment(c),
          monthlyCoins: increment(c)
        });
        batchRef.set(doc(db, 'tapDays', r.id), { paid: true, paidCoins: c, paidAt: Date.now() }, { merge: true });
        batchRef.set(doc(db, 'users', r.uid, 'transactions', `tap_${date}`), {
          type: 'task',
          amount: c,
          note: `Tap & Earn: ${r.count} ads x ${rateNum} - ${date}`,
          createdAt: Date.now()
        });
      };
      for (let i = 0; i < payable.length; i += 150) {
        const chunk = payable.slice(i, i + 150);
        try {
          const b = writeBatch(db);
          chunk.forEach((r) => writeFor(b, r));
          await b.commit();
          paidUsers += chunk.length;
        } catch (_) {
          // one bad user (for example a deleted account) must not stop the others
          for (const r of chunk) {
            try {
              const b1 = writeBatch(db);
              writeFor(b1, r);
              await b1.commit();
              paidUsers += 1;
            } catch (__) {
              failed += 1;
            }
          }
        }
      }
      toast.success(`Paid ${paidUsers} users${failed ? `, ${failed} failed` : ''}`);
    } finally {
      setPaying(false);
      loadRows();
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-surface border border-border rounded-2xl p-4 space-y-4">
        <h3 className="text-sm font-black">Rules for users</h3>
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1">
            <label className={labelCls}>Ads per day</label>
            <input className={inputCls} inputMode="numeric" value={limit} onChange={(e) => setLimit(e.target.value)} />
          </div>
          <div className="space-y-1">
            <label className={labelCls}>Ads before the long rest</label>
            <input className={inputCls} inputMode="numeric" value={batch} onChange={(e) => setBatch(e.target.value)} />
          </div>
          <div className="space-y-1">
            <label className={labelCls}>Rest after each ad (seconds)</label>
            <input className={inputCls} inputMode="numeric" value={rest} onChange={(e) => setRest(e.target.value)} />
          </div>
          <div className="space-y-1">
            <label className={labelCls}>Long rest (minutes)</label>
            <input className={inputCls} inputMode="numeric" value={longRest} onChange={(e) => setLongRest(e.target.value)} />
          </div>
        </div>
        <button onClick={saveRules} disabled={saving} className="w-full h-12 rounded-xl bg-accent text-black font-black text-sm">
          {saving ? 'Saving...' : 'Save rules'}
        </button>
        <p className="text-[10px] text-text-muted">
          Example: 9 ads per day, a 15 second rest after each ad, and after every 3 ads a 60 minute rest.
        </p>
      </div>

      <div className="bg-surface border border-border rounded-2xl p-4 space-y-4">
        <h3 className="text-sm font-black">Ads tapped by users</h3>
        <div className="flex gap-2 items-center">
          <input type="date" className={inputCls} value={date} max={todayStr} onChange={(e) => e.target.value && setDate(e.target.value)} />
          <button onClick={loadRows} className="px-4 h-11 rounded-xl bg-white/10 text-xs font-bold shrink-0">
            Refresh
          </button>
        </div>

        <div className="space-y-1">
          <label className={labelCls}>Coins for 1 ad</label>
          <input
            className={inputCls}
            inputMode="numeric"
            placeholder="for example 10"
            value={rate}
            onChange={(e) => setRate(e.target.value)}
          />
          <p className="text-[10px] text-text-muted">
            A user with 2 ads gets 2 x this number. Nothing is paid until you press the button below.
          </p>
        </div>

        {!canPay && (
          <p className="text-[11px] text-yellow-400 font-bold">
            This is today. Coins can only be given for yesterday or earlier. Pick an earlier date to pay.
          </p>
        )}

        {loadingRows ? (
          <div className="py-6 flex justify-center">
            <Loader2 className="animate-spin text-accent" />
          </div>
        ) : rows.length === 0 ? (
          <p className="text-xs text-text-muted">Nobody tapped an ad on {date}.</p>
        ) : (
          <div className="space-y-2">
            {rows.map((r) => (
              <div key={r.id} className="flex items-center justify-between gap-3 bg-white/5 rounded-xl px-3 py-2">
                <div className="min-w-0">
                  <p className="text-sm font-bold truncate">{r.name || r.uid}</p>
                  <p className="text-[10px] text-text-muted truncate">{r.email}</p>
                </div>
                <div className="text-right shrink-0">
                  <p className="text-sm font-black">{r.count} {r.count === 1 ? 'ad' : 'ads'}</p>
                  <p className={'text-[10px] font-bold ' + (r.paid ? 'text-green-400' : 'text-accent')}>
                    {r.paid ? `Paid ${r.paidCoins}` : rateOk ? `${r.count * rateNum} coins` : '-'}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="flex items-center justify-between text-xs text-text-muted font-bold">
          <span>{rows.length} users · {totalAds} ads</span>
          <span>To pay: {totalCoins.toLocaleString()} coins ({payable.length} users)</span>
        </div>

        <button
          onClick={payAll}
          disabled={paying || !canPay || !rateOk || payable.length === 0}
          className={
            'w-full h-12 rounded-xl font-black text-sm ' +
            (!canPay || !rateOk || payable.length === 0 ? 'bg-white/5 text-text-muted' : 'bg-accent text-black')
          }
        >
          {paying ? 'Paying...' : `Save & pay for ${date}`}
        </button>
        <p className="text-[10px] text-text-muted">
          Each user is paid only once per day, even if you press again. Users get no coins when they tap, only from you.
        </p>
      </div>
    </div>
  );
}
