import React, { useEffect, useRef, useState } from 'react';
import { doc, onSnapshot } from 'firebase/firestore';
import { toast } from 'react-hot-toast';
import { MousePointerClick, Check, Loader2 } from 'lucide-react';
import { auth, db } from '../firebase';
import { tr } from '../lib/i18n';
import { SERVER_URL } from '../lib/server';
import { loadRewardedSdk, normalizeTapConfig, showRewardedAd, tapDay, TAP_MIN_AWAY_SECONDS, type TapConfig } from '../lib/tapEarn';

interface DayState {
  count: number;
  lastAt: number;
  restUntil: number;
}

const PENDING_KEY = 'halal_tap_pending';

/** One tap on the button: it is remembered (also across a page reload) until it is counted or dropped. */
interface Attempt {
  ymid: string;
  uid: string;
  t: number;
  hiddenAt: number; // when the user left the page (0 = on the page)
  awayMs: number; // total time the user was away from the page
  settled: boolean; // the ad promise has finished (or the page was reloaded)
  valued: boolean; // Monetag said "valued"
  claimed: boolean;
}

const safeJson = (v: unknown) => {
  try {
    return String(JSON.stringify(v)).slice(0, 140);
  } catch (_) {
    return String(v);
  }
};

const fmt = (sec: number) => {
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${m}:${String(s).padStart(2, '0')}`;
};

/**
 * Tap -> Monetag's rewarded interstitial is shown. The tap is counted on the server when
 *   (a) Monetag says the ad was "valued", or
 *   (b) the user pressed Continue, visited the page behind it (left this site for 5+ seconds) and came back.
 * (b) also works when the phone reloads the site while the user is away: the tap is remembered in localStorage.
 * Closing the ad without visiting the page is not counted. The user gets no coins for it; the admin pays the next day.
 * Rest times and the daily limit are checked again on the server.
 */
export function TapEarnCard({ uid }: { uid: string }) {
  const [cfg, setCfg] = useState<TapConfig>(normalizeTapConfig(null));
  const [st, setSt] = useState<DayState>({ count: 0, lastAt: 0, restUntil: 0 });
  const [now, setNow] = useState(Date.now());
  const [busy, setBusy] = useState(false);
  const skew = useRef(0); // server time minus phone time, so a wrong phone clock does not matter
  const attempt = useRef<Attempt | null>(null);
  const [dbg, setDbg] = useState('');

  const today = tapDay(now);

  useEffect(
    () =>
      onSnapshot(
        doc(db, 'appConfig', 'tapEarn'),
        (s) => setCfg(normalizeTapConfig(s.exists() ? s.data() : null)),
        () => {}
      ),
    []
  );

  useEffect(() => {
    if (!uid) return;
    return onSnapshot(
      doc(db, 'tapDays', `${uid}_${today}`),
      (s) => {
        const d: any = s.exists() ? s.data() : {};
        setSt({ count: Number(d.count) || 0, lastAt: Number(d.lastAt) || 0, restUntil: Number(d.restUntil) || 0 });
      },
      () => setSt({ count: 0, lastAt: 0, restUntil: 0 })
    );
  }, [uid, today]);

  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);

  // get the ad SDK and the (free) server ready before the first tap
  useEffect(() => {
    loadRewardedSdk();
    fetch(`${SERVER_URL}/health`).catch(() => {});
  }, []);

  const adjusted = now + skew.current;
  const longLeft = Math.max(0, Math.ceil((st.restUntil - adjusted) / 1000));
  const shortLeft = Math.max(0, Math.ceil((st.lastAt + cfg.restSeconds * 1000 - adjusted) / 1000));
  const finished = st.count >= cfg.dailyLimit;
  const blocked = busy || finished || longLeft > 0 || shortLeft > 0;

  const claim = async () => {
    setBusy(true);
    try {
      const token = await auth.currentUser?.getIdToken();
      if (!token) throw new Error('no-token');
      const res = await fetch(`${SERVER_URL}/tap/claim`, { method: 'POST', headers: { Authorization: `Bearer ${token}` } });
      const data: any = await res.json().catch(() => ({}));
      if (typeof data.serverNow === 'number') skew.current = data.serverNow - Date.now();
      if (res.ok && data.ok) {
        setSt({ count: data.count, lastAt: data.lastAt, restUntil: data.restUntil });
        toast.success(tr('tap.counted', { n: data.count, max: data.limit }));
      } else if (data.error === 'wait') {
        toast.error(tr('tap.wait'));
      } else if (data.error === 'rest') {
        toast.error(tr('tap.restmsg'));
      } else if (data.error === 'limit') {
        toast.error(tr('tap.done', { max: cfg.dailyLimit }));
      } else {
        toast.error(tr('tap.error'));
      }
    } catch (_) {
      toast.error(tr('tap.error'));
    } finally {
      setBusy(false);
    }
  };

  const save = () => {
    try {
      if (attempt.current && !attempt.current.claimed) localStorage.setItem(PENDING_KEY, JSON.stringify(attempt.current));
    } catch (_) {
      /* ignore */
    }
  };
  const forget = () => {
    attempt.current = null;
    try {
      localStorage.removeItem(PENDING_KEY);
    } catch (_) {
      /* ignore */
    }
  };
  const awayOf = (a: Attempt) => a.awayMs + (a.hiddenAt ? Date.now() - a.hiddenAt : 0);

  // decides what happens with the current tap
  const settle = (why: string) => {
    const a = attempt.current;
    if (!a || a.claimed) return;
    const away = awayOf(a);
    setDbg(`${why} | valued: ${a.valued} | away: ${Math.round(away / 1000)}s`);
    if (a.valued || away >= TAP_MIN_AWAY_SECONDS * 1000) {
      a.claimed = true;
      forget();
      claim();
    } else if (a.settled) {
      // the ad is over and the user never visited the page behind it
      forget();
      setBusy(false);
      toast.error(tr('tap.notvalued'));
    }
  };
  const settleRef = useRef(settle);
  settleRef.current = settle;

  const tap = () => {
    if (blocked || !uid) return;
    setBusy(true);
    setDbg('');
    // the ad starts inside the tap (the browser only allows that)
    const ymid = `${uid}_${Date.now()}`;
    const ad = showRewardedAd(ymid);
    if (!ad) {
      setBusy(false);
      toast.error(tr('tap.adloading'));
      return;
    }
    attempt.current = { ymid, uid, t: Date.now(), hiddenAt: 0, awayMs: 0, settled: false, valued: false, claimed: false };
    save();
    ad.then((result: any) => {
      const a = attempt.current;
      if (!a || a.ymid !== ymid) return; // already finished in another way
      a.settled = true;
      // Monetag: the promise also resolves when the ad is closed early. Only "valued" counts by itself.
      a.valued = !!result && result.reward_event_type === 'valued';
      setDbg('ad result: ' + safeJson(result));
      settleRef.current('ad finished');
    }).catch((e: any) => {
      const a = attempt.current;
      if (!a || a.ymid !== ymid) return;
      a.settled = true;
      setDbg('ad error: ' + String((e && e.message) || e));
      if (awayOf(a) >= TAP_MIN_AWAY_SECONDS * 1000) {
        settleRef.current('ad error, but the page was visited');
      } else {
        forget();
        setBusy(false);
        toast.error(tr('tap.adfail'));
      }
    });
  };

  // the user leaves the site (to the page behind the ad's Continue button) and comes back
  useEffect(() => {
    const onVisibility = () => {
      const a = attempt.current;
      if (!a || a.claimed) return;
      if (document.visibilityState === 'hidden') {
        if (!a.hiddenAt) a.hiddenAt = Date.now();
        save();
      } else if (a.hiddenAt) {
        a.awayMs += Date.now() - a.hiddenAt;
        a.hiddenAt = 0;
        save();
        settleRef.current('came back');
      }
    };
    document.addEventListener('visibilitychange', onVisibility);
    return () => document.removeEventListener('visibilitychange', onVisibility);
  }, []);

  // the phone reloaded the site while the user was away: pick the tap up again
  useEffect(() => {
    if (!uid) return;
    try {
      const raw = localStorage.getItem(PENDING_KEY);
      if (!raw) return;
      const a: Attempt = JSON.parse(raw);
      if (a.uid !== uid || Date.now() - a.t > 30 * 60000) {
        localStorage.removeItem(PENDING_KEY);
        return;
      }
      a.settled = true; // the ad promise is gone after a reload
      attempt.current = a;
      setBusy(true);
      settleRef.current('page reloaded');
    } catch (_) {
      /* ignore */
    }
  }, [uid]);

  let label: React.ReactNode = tr('tap.cta');
  if (busy) {
    label = (
      <>
        <Loader2 className="animate-spin" size={16} /> {tr('tap.saving')}
      </>
    );
  } else if (finished) label = tr('tap.done', { max: cfg.dailyLimit });
  else if (longLeft > 0) label = tr('tap.rest', { t: fmt(longLeft) });
  else if (shortLeft > 0) label = tr('tap.next', { s: shortLeft });

  return (
    <div className="glass-card p-5 space-y-4">
      <div className="flex items-center gap-3">
        <div className="w-11 h-11 rounded-xl bg-accent/10 flex items-center justify-center">
          <MousePointerClick className="w-5 h-5 text-accent" />
        </div>
        <div className="flex-1">
          <h4 className="font-bold">{tr('tap.title')}</h4>
          <p className="text-[11px] text-text-muted">{tr('tap.count', { n: st.count, max: cfg.dailyLimit })}</p>
        </div>
        {finished && (
          <span className="w-7 h-7 rounded-full bg-accent text-black flex items-center justify-center">
            <Check size={16} />
          </span>
        )}
      </div>

      <div className="flex gap-1">
        {Array.from({ length: cfg.dailyLimit }, (_, i) => (
          <div key={i} className={'h-2 flex-1 rounded-full ' + (i < st.count ? 'bg-accent' : 'bg-white/10')} />
        ))}
      </div>

      <button
        onClick={tap}
        disabled={blocked}
        className={
          'w-full h-12 rounded-xl font-black text-sm flex items-center justify-center gap-2 ' +
          (blocked ? 'bg-white/5 text-text-muted' : 'bg-accent text-black')
        }
      >
        {label}
      </button>

      <p className="text-[10px] text-text-muted">{tr('tap.sub')}</p>
      {dbg && <p className="text-[9px] text-text-muted break-all opacity-70">{dbg}</p>}
      <p className="text-[10px] text-text-muted">
        {tr('tap.hint', { b: cfg.batchSize, m: cfg.longRestMinutes, s: cfg.restSeconds })}
      </p>
    </div>
  );
}
