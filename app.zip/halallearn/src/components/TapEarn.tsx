import React, { useEffect, useRef, useState } from 'react';
import { doc, onSnapshot } from 'firebase/firestore';
import { toast } from 'react-hot-toast';
import { MousePointerClick, Check, Loader2 } from 'lucide-react';
import { auth, db } from '../firebase';
import { tr } from '../lib/i18n';
import { SERVER_URL } from '../lib/server';
import { normalizeTapConfig, tapDay, type TapConfig } from '../lib/tapEarn';
import { loadIma, runVideoAd, type VideoAdResult } from '../lib/videoAd';

interface DayState {
  count: number;
  lastAt: number;
  restUntil: number;
}

const fmt = (sec: number) => {
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${m}:${String(s).padStart(2, '0')}`;
};

/**
 * Tap -> a video ad (Adcash, played with Google IMA) is shown full screen. It counts only when it is watched to the end.
 * The user gets no coins for it.
 * Rest times and the daily limit are checked again on the server. The admin pays for the taps the next day.
 */
export function TapEarnCard({ uid }: { uid: string }) {
  const [cfg, setCfg] = useState<TapConfig>(normalizeTapConfig(null));
  const [st, setSt] = useState<DayState>({ count: 0, lastAt: 0, restUntil: 0 });
  const [now, setNow] = useState(Date.now());
  const [busy, setBusy] = useState(false);
  const skew = useRef(0); // server time minus phone time, so a wrong phone clock does not matter

  const today = tapDay(now);

  useEffect(
    () =>
      onSnapshot(
        doc(db, 'appConfig', 'tapEarn'),
        (s) => setCfg(normalizeTapConfig(s.exists() ? s.data() : null)),
        () => {}
      ),
    []
  );

  useEffect(() => {
    if (!uid) return;
    return onSnapshot(
      doc(db, 'tapDays', `${uid}_${today}`),
      (s) => {
        const d: any = s.exists() ? s.data() : {};
        setSt({ count: Number(d.count) || 0, lastAt: Number(d.lastAt) || 0, restUntil: Number(d.restUntil) || 0 });
      },
      () => setSt({ count: 0, lastAt: 0, restUntil: 0 })
    );
  }, [uid, today]);

  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);

  // get the video ad SDK and the (free) server ready before the first tap
  useEffect(() => {
    loadIma().catch(() => {});
    fetch(`${SERVER_URL}/health`).catch(() => {});
  }, []);

  const adjusted = now + skew.current;
  const longLeft = Math.max(0, Math.ceil((st.restUntil - adjusted) / 1000));
  const shortLeft = Math.max(0, Math.ceil((st.lastAt + cfg.restSeconds * 1000 - adjusted) / 1000));
  const finished = st.count >= cfg.dailyLimit;
  const blocked = busy || finished || longLeft > 0 || shortLeft > 0;

  const adMessage = (ad: VideoAdResult) => {
    if (ad.status === 'loading') return tr('tap.adloading');
    if (ad.status === 'blocked') return tr('tap.adblocked');
    if (ad.status === 'skipped') return tr('tap.skipped');
    if (ad.status === 'no-ad') return tr('tap.noad');
    return tr('tap.aderror', { c: ad.code ?? 0 });
  };

  const tap = async () => {
    if (blocked || !uid) return;
    setBusy(true);
    // the video ad starts inside the tap (the browser only allows that); it is counted only if it is watched to the end
    const ad = await runVideoAd();
    if (ad.status !== 'complete') {
      setBusy(false);
      toast.error(adMessage(ad));
      return;
    }
    try {
      const token = await auth.currentUser?.getIdToken();
      if (!token) throw new Error('no-token');
      const res = await fetch(`${SERVER_URL}/tap/claim`, { method: 'POST', headers: { Authorization: `Bearer ${token}` } });
      const data = await res.json().catch(() => ({}));
      if (typeof data.serverNow === 'number') skew.current = data.serverNow - Date.now();
      if (res.ok && data.ok) {
        setSt({ count: data.count, lastAt: data.lastAt, restUntil: data.restUntil });
        toast.success(tr('tap.counted', { n: data.count, max: data.limit }));
      } else if (data.error === 'wait') {
        toast.error(tr('tap.wait'));
      } else if (data.error === 'rest') {
        toast.error(tr('tap.restmsg'));
      } else if (data.error === 'limit') {
        toast.error(tr('tap.done', { max: cfg.dailyLimit }));
      } else {
        toast.error(tr('tap.error'));
      }
    } catch (_) {
      toast.error(tr('tap.error'));
    } finally {
      setBusy(false);
    }
  };

  let label: React.ReactNode = tr('tap.cta');
  if (busy) {
    label = (
      <>
        <Loader2 className="animate-spin" size={16} /> {tr('tap.saving')}
      </>
    );
  } else if (finished) label = tr('tap.done', { max: cfg.dailyLimit });
  else if (longLeft > 0) label = tr('tap.rest', { t: fmt(longLeft) });
  else if (shortLeft > 0) label = tr('tap.next', { s: shortLeft });

  return (
    <div className="glass-card p-5 space-y-4">
      <div className="flex items-center gap-3">
        <div className="w-11 h-11 rounded-xl bg-accent/10 flex items-center justify-center">
          <MousePointerClick className="w-5 h-5 text-accent" />
        </div>
        <div className="flex-1">
          <h4 className="font-bold">{tr('tap.title')}</h4>
          <p className="text-[11px] text-text-muted">{tr('tap.count', { n: st.count, max: cfg.dailyLimit })}</p>
        </div>
        {finished && (
          <span className="w-7 h-7 rounded-full bg-accent text-black flex items-center justify-center">
            <Check size={16} />
          </span>
        )}
      </div>

      <div className="flex gap-1">
        {Array.from({ length: cfg.dailyLimit }, (_, i) => (
          <div key={i} className={'h-2 flex-1 rounded-full ' + (i < st.count ? 'bg-accent' : 'bg-white/10')} />
        ))}
      </div>

      <button
        onClick={tap}
        disabled={blocked}
        className={
          'w-full h-12 rounded-xl font-black text-sm flex items-center justify-center gap-2 ' +
          (blocked ? 'bg-white/5 text-text-muted' : 'bg-accent text-black')
        }
      >
        {label}
      </button>

      <p className="text-[10px] text-text-muted">{tr('tap.sub')}</p>
      <p className="text-[10px] text-text-muted">
        {tr('tap.hint', { b: cfg.batchSize, m: cfg.longRestMinutes, s: cfg.restSeconds })}
      </p>
    </div>
  );
}
