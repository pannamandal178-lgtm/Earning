import React, { useState } from 'react';
import { X, Gift } from 'lucide-react';
import { useFeatureConfig } from '../lib/featureConfig';

const KEY_RE = /^[0-9a-fA-F]{32}$/;

/**
 * OfferwallApi offerwall.
 * The user id sent to the wall (sub id) is the Firebase UID exactly as it is - never changed -
 * because the postback server only credits an exact match.
 * The wall runs in a cross-origin iframe (it cannot read this app's login or data).
 */
export function OfferwallApiWall({ uid }: { uid: string }) {
  const cfg = useFeatureConfig();
  const [open, setOpen] = useState(false);
  const key = cfg.offerwallApiKey;

  if (!uid || !KEY_RE.test(key)) return null;

  const src = `https://offerwallapi.com/offerwall/${key}/${encodeURIComponent(uid)}`;

  return (
    <>
      <div className="glass-card p-5 space-y-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-accent/10 flex items-center justify-center">
            <Gift className="w-5 h-5 text-accent" />
          </div>
          <div>
            <h3 className="text-sm font-black">Offerwall</h3>
            <p className="text-[11px] text-text-muted">Watch ads, visit links and finish tasks to earn coins</p>
          </div>
        </div>
        <button
          onClick={() => setOpen(true)}
          className="w-full h-12 rounded-xl bg-accent text-black font-black text-sm"
        >
          Open Offerwall
        </button>
        <p className="text-[10px] text-text-muted">
          Coins are added automatically after the offer is verified. This can take a few minutes.
        </p>
      </div>

      {open && (
        <div className="fixed inset-0 z-[100] bg-black flex flex-col">
          <div className="flex items-center justify-between px-4 h-12 border-b border-white/10">
            <span className="text-sm font-black">Offerwall</span>
            <button onClick={() => setOpen(false)} aria-label="Close" className="p-2">
              <X className="w-5 h-5" />
            </button>
          </div>
          <iframe
            title="Offerwall"
            src={src}
            allow="notifications"
            sandbox="allow-scripts allow-same-origin allow-popups allow-popups-to-escape-sandbox allow-forms allow-modals"
            style={{ flex: 1, width: '100%', border: 0 }}
          />
        </div>
      )}
    </>
  );
}
