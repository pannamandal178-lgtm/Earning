import React, { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { X, Gift } from 'lucide-react';
import { useFeatureConfig } from '../lib/featureConfig';

const KEY_RE = /^[0-9a-fA-F]{32}$/;

/**
 * OfferwallApi offerwall.
 * The user id sent to the wall (sub id) is the Firebase UID exactly as it is - never changed -
 * because the postback server only credits an exact match.
 * The wall runs in a cross-origin iframe (it cannot read this app's login or data).
 * It opens full screen through a portal on <body>, so animated parent containers cannot shrink it.
 */
export function OfferwallApiWall({ uid }: { uid: string }) {
  const cfg = useFeatureConfig();
  const [open, setOpen] = useState(false);
  const key = cfg.offerwallApiKey;

  // While the wall is open: lock page scrolling and let the phone's Back button close it
  useEffect(() => {
    if (!open) return;
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    window.history.pushState({ offerwall: true }, '');
    const onPop = () => setOpen(false);
    window.addEventListener('popstate', onPop);
    return () => {
      document.body.style.overflow = prevOverflow;
      window.removeEventListener('popstate', onPop);
    };
  }, [open]);

  if (!uid || !KEY_RE.test(key)) return null;

  const src = `https://offerwallapi.com/offerwall/${key}/${encodeURIComponent(uid)}`;

  const close = () => {
    // go back one step (this also fires popstate and closes the wall); fall back to a plain close
    if (window.history.state && window.history.state.offerwall) window.history.back();
    else setOpen(false);
  };

  return (
    <>
      <div className="glass-card p-5 space-y-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-accent/10 flex items-center justify-center">
            <Gift className="w-5 h-5 text-accent" />
          </div>
          <div>
            <h3 className="text-sm font-black">Offerwall</h3>
            <p className="text-[11px] text-text-muted">Watch ads, visit links and finish tasks to earn coins</p>
          </div>
        </div>
        <button
          onClick={() => setOpen(true)}
          className="w-full h-12 rounded-xl bg-accent text-black font-black text-sm"
        >
          Open Offerwall
        </button>
        <p className="text-[10px] text-text-muted">
          Coins are added automatically after the offer is verified. This can take a few minutes.
        </p>
      </div>

      {open &&
        createPortal(
          <div
            className="fixed left-0 top-0 w-full bg-black flex flex-col"
            style={{ height: '100dvh', zIndex: 1000 }}
          >
            <div
              className="flex items-center justify-between px-4 border-b border-white/10"
              style={{ height: 48, paddingTop: 'env(safe-area-inset-top)' }}
            >
              <span className="text-sm font-black text-white">Offerwall</span>
              <button onClick={close} aria-label="Close" className="p-2 text-white">
                <X className="w-5 h-5" />
              </button>
            </div>
            <iframe
              title="Offerwall"
              src={src}
              allow="notifications"
              sandbox="allow-scripts allow-same-origin allow-popups allow-popups-to-escape-sandbox allow-forms allow-modals"
              style={{ flex: 1, minHeight: 0, width: '100%', border: 0, background: '#000' }}
            />
          </div>,
          document.body
        )}
    </>
  );
}
