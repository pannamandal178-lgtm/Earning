import React, { useEffect, useRef, useState } from 'react';
import { toast } from 'react-hot-toast';
import { Camera, Check, X, Loader2, Clock, AlertCircle } from 'lucide-react';
import {
  collection,
  deleteField,
  doc,
  getDoc,
  getDocs,
  increment,
  limit as fsLimit,
  onSnapshot,
  orderBy,
  query,
  runTransaction,
  serverTimestamp,
  setDoc,
  where,
  writeBatch
} from 'firebase/firestore';
import { auth, db } from '../firebase';
import { cn } from '../lib/utils';
import { tr } from '../lib/i18n';
import { DEFAULT_FEATURES, FeatureConfig, mergeFeatures, useFeatureConfig } from '../lib/featureConfig';
import { TASK_MIN_SECONDS, TASK_REWARD_COINS } from '../constants';

export const ADMIN_EMAIL = 'pannamandal178@gmail.com';
const MAX_BYTES = 200 * 1024;
const DAY_MS = 24 * 60 * 60 * 1000;

export type ProofStatus = 'pending' | 'approved' | 'rejected';

export interface OfferProof {
  id: string;
  uid: string;
  userName: string;
  userEmail: string;
  offerId: string;
  offerTitle: string;
  imageData?: string;
  imageData2?: string;
  imageHash: string;
  imageHash2?: string;
  status: ProofStatus;
  rejectReason?: string;
  createdAt?: any;
  reviewedAt?: any;
}

/* ------------------------------------------------------------------ */
/* Helpers                                                            */
/* ------------------------------------------------------------------ */

const dataUrlBytes = (d: string) => Math.floor(((d.length - d.indexOf(',') - 1) * 3) / 4);

/** Compress an image file in the browser: max width 720px, JPEG, final size under 200 KB. */
export async function compressImage(file: File): Promise<string> {
  if (!file || !file.type || !file.type.startsWith('image/')) {
    throw new Error(tr('proof.onlyImage'));
  }
  const url = URL.createObjectURL(file);
  try {
    const img: HTMLImageElement = await new Promise((resolve, reject) => {
      const i = new Image();
      i.onload = () => resolve(i);
      i.onerror = () => reject(new Error(tr('proof.readFail')));
      i.src = url;
    });
    let width = Math.min(720, img.naturalWidth);
    for (let attempt = 0; attempt < 6; attempt++) {
      const scale = width / img.naturalWidth;
      const canvas = document.createElement('canvas');
      canvas.width = Math.max(1, Math.round(img.naturalWidth * scale));
      canvas.height = Math.max(1, Math.round(img.naturalHeight * scale));
      const ctx = canvas.getContext('2d');
      if (!ctx) throw new Error(tr('proof.processFail'));
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      for (let q = 0.6; q >= 0.19; q = Math.round((q - 0.1) * 10) / 10) {
        const data = canvas.toDataURL('image/jpeg', q);
        if (dataUrlBytes(data) <= MAX_BYTES) return data;
      }
      width = Math.round(width * 0.8);
    }
    throw new Error(tr('proof.tooBig'));
  } finally {
    URL.revokeObjectURL(url);
  }
}

export async function sha256Hex(text: string): Promise<string> {
  const subtle = (globalThis as any).crypto?.subtle;
  if (!subtle) throw new Error(tr('proof.noVerify'));
  const buf = await subtle.digest('SHA-256', new TextEncoder().encode(text));
  return Array.from(new Uint8Array(buf))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

/** Reward source of truth: admin-configured values in Firestore (never taken from the user's proof document). */
export function rewardForOffer(offerId: string, cfg: any, features: FeatureConfig): { reward: number; title: string } | null {
  if (/^task_\d+$/.test(offerId)) {
    return { reward: Number(cfg?.taskReward ?? TASK_REWARD_COINS) || 0, title: 'Complete Task & Earn' };
  }
  if (/^gamebonus_\d+$/.test(offerId)) {
    return { reward: Number(features.gameBonusCoins) || 0, title: 'Play & Earn Extra Bonus' };
  }
  const offer = (cfg?.specialOffers || []).find((o: any) => o.id === offerId);
  return offer ? { reward: Number(offer.coins) || 0, title: String(offer.title || 'Offer') } : null;
}

/** A repeating slot (task_N / gamebonus_N) can be used again if it was rejected, or approved more than 24h ago. */
export function isSlotFree(p?: OfferProof): boolean {
  if (!p) return true;
  if (p.status === 'rejected') return true;
  const created = p.createdAt?.toMillis?.() ?? 0;
  return p.status === 'approved' && created > 0 && Date.now() - created > DAY_MS;
}

export function slotInfo(
  proofs: Record<string, OfferProof>,
  prefix: 'task' | 'gamebonus',
  limit: number
): { freeSlot: number | null; used: number } {
  let used = 0;
  let freeSlot: number | null = null;
  for (let i = 1; i <= Math.max(0, limit); i++) {
    if (isSlotFree(proofs[`${prefix}_${i}`])) {
      if (freeSlot === null) freeSlot = i;
    } else {
      used++;
    }
  }
  return { freeSlot, used };
}

/* ------------------------------------------------------------------ */
/* User side                                                          */
/* ------------------------------------------------------------------ */

/** Live map of the signed-in user's own proofs, keyed by offerId. */
export function useMyProofs(uid: string): Record<string, OfferProof> {
  const [map, setMap] = useState<Record<string, OfferProof>>({});
  useEffect(() => {
    if (!uid || auth.currentUser?.uid !== uid) {
      setMap({});
      return;
    }
    const q = query(collection(db, 'offerProofs'), where('uid', '==', uid));
    const unsub = onSnapshot(
      q,
      (snap) => {
        const next: Record<string, OfferProof> = {};
        snap.forEach((d) => {
          const data = d.data() as any;
          next[data.offerId] = { id: d.id, ...data } as OfferProof;
        });
        setMap(next);
      },
      (err) => console.error('offerProofs listener error', err)
    );
    return () => unsub();
  }, [uid]);
  return map;
}

export function ProofStatusBadge({ proof }: { proof?: OfferProof }) {
  if (!proof) return null;
  const cfg = {
    pending: { text: tr('badge.pending'), cls: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/30' },
    approved: { text: tr('badge.approved'), cls: 'bg-green-500/10 text-green-400 border-green-500/30' },
    rejected: { text: tr('badge.rejected'), cls: 'bg-red-500/10 text-red-400 border-red-500/30' }
  }[proof.status];
  return (
    <div className="space-y-1">
      <span className={cn('inline-block px-3 py-1 rounded-full border text-[10px] font-black uppercase tracking-widest', cfg.cls)}>
        {cfg.text}
      </span>
      {proof.status === 'rejected' && proof.rejectReason && (
        <p className="text-[11px] text-red-400 leading-relaxed">{tr('proof.reason', { reason: proof.rejectReason })}</p>
      )}
    </div>
  );
}

export function ProofModal({
  userData,
  offerId,
  offerTitle,
  existing,
  shots,
  shotLabels,
  onClose,
  onSubmitted
}: {
  userData: any;
  offerId: string;
  offerTitle: string;
  existing?: OfferProof;
  shots: 1 | 2;
  shotLabels?: string[];
  onClose: () => void;
  onSubmitted?: () => void;
}) {
  const [images, setImages] = useState<(string | null)[]>(shots === 2 ? [null, null] : [null]);
  const [busy, setBusy] = useState(false);
  const inputs = useRef<(HTMLInputElement | null)[]>([]);

  const pick = async (index: number, file?: File | null) => {
    if (!file) return;
    try {
      const data = await compressImage(file);
      setImages((prev) => prev.map((v, i) => (i === index ? data : v)));
    } catch (e: any) {
      toast.error(e?.message || tr('proof.pickFail'));
    }
  };

  const submit = async () => {
    if (busy) return;
    if (!auth.currentUser || auth.currentUser.uid !== userData.uid) {
      toast.error(tr('proof.loginRequired'));
      return;
    }
    if (existing && !(existing.status === 'rejected' || isSlotFree(existing))) {
      toast.error(tr('proof.already'));
      return;
    }
    if (images.some((i) => !i)) {
      toast.error(shots === 2 ? tr('proof.needBoth') : tr('proof.needOne'));
      return;
    }
    setBusy(true);
    try {
      const imageData = images[0] as string;
      const payload: any = {
        uid: userData.uid,
        userName: String(userData.nickname || userData.name || ''),
        userEmail: String(userData.email || auth.currentUser.email || ''),
        offerId,
        offerTitle,
        imageData,
        imageHash: await sha256Hex(imageData),
        status: 'pending',
        createdAt: serverTimestamp()
      };
      if (shots === 2 && images[1]) {
        payload.imageData2 = images[1];
        payload.imageHash2 = await sha256Hex(images[1] as string);
      }
      if (payload.imageHash2 && payload.imageHash2 === payload.imageHash) {
        toast.error(tr('proof.distinct'));
        return;
      }
      // Lock each image hash (create-only): the same screenshot can never be submitted again, on any day, by anyone.
      const batch = writeBatch(db);
      batch.set(doc(db, 'proofHashes', payload.imageHash), { uid: userData.uid, createdAt: serverTimestamp() });
      if (payload.imageHash2) {
        batch.set(doc(db, 'proofHashes', payload.imageHash2), { uid: userData.uid, createdAt: serverTimestamp() });
      }
      batch.set(doc(db, 'offerProofs', `${userData.uid}_${offerId}`), payload);
      await batch.commit();
      toast.success(tr('proof.submitted'));
      onSubmitted?.();
      onClose();
    } catch (e: any) {
      console.error(e);
      toast.error(
        e?.code === 'permission-denied' || e?.message?.includes('permission')
          ? tr('proof.permissionDenied')
          : e?.message || tr('proof.failed')
      );
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[90] bg-black/80 flex items-end sm:items-center justify-center p-4">
      <div className="w-full max-w-md bg-surface border border-border rounded-3xl p-5 space-y-4 max-h-[90vh] overflow-y-auto">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h4 className="font-black text-lg">{tr('proof.title')}</h4>
            <p className="text-xs text-text-muted">{offerTitle}</p>
          </div>
          <button onClick={onClose} className="p-2 rounded-full bg-white/5"><X size={18} /></button>
        </div>

        {existing?.status === 'rejected' && (
          <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-xs text-red-400">
            {existing.rejectReason
              ? tr('proof.prevRejectedReason', { reason: existing.rejectReason })
              : tr('proof.prevRejected')}
          </div>
        )}

        {images.map((img, i) => (
          <div key={i} className="space-y-2">
            <p className="text-[11px] font-bold text-text-muted uppercase tracking-widest">
              {shotLabels?.[i] || tr('proof.shot', { n: i + 1 })}
            </p>
            <input
              ref={(el) => { inputs.current[i] = el; }}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => {
                pick(i, e.target.files?.[0]);
                e.target.value = '';
              }}
            />
            {img ? (
              <img src={img} alt={`proof ${i + 1}`} className="w-full max-h-64 object-contain rounded-xl border border-border bg-black" />
            ) : null}
            <button
              type="button"
              onClick={() => inputs.current[i]?.click()}
              className="w-full h-11 rounded-xl bg-white/5 border border-white/10 text-xs font-bold flex items-center justify-center gap-2"
            >
              <Camera size={16} /> {img ? tr('proof.change') : tr('proof.gallery')}
            </button>
          </div>
        ))}

        <button
          onClick={submit}
          disabled={busy}
          className="w-full h-12 rounded-xl bg-accent text-black font-black text-sm disabled:opacity-60 flex items-center justify-center gap-2"
        >
          {busy ? <Loader2 size={16} className="animate-spin" /> : null}
          {busy ? tr('proof.submitting') : tr('proof.title')}
        </button>
        <p className="text-[10px] text-text-muted text-center">{tr('proof.noCoinNote')}</p>
      </div>
    </div>
  );
}

/** Shown on each Special Offer card: status, and the Submit Proof button once the link was opened. */
export function OfferProofControls({
  userData,
  offerId,
  offerTitle,
  opened,
  proof
}: {
  userData: any;
  offerId: string;
  offerTitle: string;
  opened: boolean;
  proof?: OfferProof;
}) {
  const [show, setShow] = useState(false);
  const canSubmit = opened && (!proof || proof.status === 'rejected');
  if (!proof && !opened) return null;
  return (
    <div className="space-y-2">
      <ProofStatusBadge proof={proof} />
      {canSubmit && (
        <button
          onClick={() => setShow(true)}
          className="w-full h-10 rounded-xl bg-white/5 border border-accent/30 text-accent text-xs font-black uppercase tracking-widest"
        >
          {tr('proof.title')}
        </button>
      )}
      {show && (
        <ProofModal
          userData={userData}
          offerId={offerId}
          offerTitle={offerTitle}
          existing={proof}
          shots={1}
          onClose={() => setShow(false)}
        />
      )}
    </div>
  );
}

export const offerOpenedKey = (uid: string, offerId: string) => `halal_offer_opened_${uid}_${offerId}`;

export function TaskSteps() {
  return (
    <ol className="text-[11px] text-gray-300 space-y-1 list-decimal pl-5">
      {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((n) => (
        <li key={n} className={n === 9 ? 'text-yellow-400 font-bold' : undefined}>{tr(`step.${n}`)}</li>
      ))}
    </ol>
  );
}

/** "Complete Task & Earn" card: start -> ad link -> download app & use 1 min -> 2 screenshots -> admin review. */
export function AdminProofsTab() {
  const isAdmin = auth.currentUser?.email === ADMIN_EMAIL;
  const [proofs, setProofs] = useState<OfferProof[]>([]);
  const [loading, setLoading] = useState(true);
  const [cfg, setCfg] = useState<any>(null);
  const [feat, setFeat] = useState<FeatureConfig>(DEFAULT_FEATURES);
  const [dups, setDups] = useState<Record<string, boolean>>({});
  const [zoom, setZoom] = useState<string | null>(null);
  const [rejectingId, setRejectingId] = useState<string | null>(null);
  const [reason, setReason] = useState('');
  const [busyId, setBusyId] = useState<string | null>(null);
  const [filter, setFilter] = useState<'pending' | 'approved' | 'rejected' | 'all'>('pending');
  const [history, setHistory] = useState<OfferProof[]>([]);
  const [histLoading, setHistLoading] = useState(false);
  const [limitN, setLimitN] = useState(25);

  useEffect(() => {
    if (!isAdmin) return;
    getDoc(doc(db, 'appConfig', 'general')).then((s) => setCfg(s.data() || {})).catch(() => setCfg({}));
    getDoc(doc(db, 'appConfig', 'features')).then((s) => setFeat(mergeFeatures(s.data()))).catch(() => undefined);
    const q = query(collection(db, 'offerProofs'), where('status', '==', 'pending'));
    const unsub = onSnapshot(
      q,
      (snap) => {
        const list: OfferProof[] = [];
        snap.forEach((d) => list.push({ id: d.id, ...(d.data() as any) } as OfferProof));
        list.sort((a, b) => (b.createdAt?.toMillis?.() ?? 0) - (a.createdAt?.toMillis?.() ?? 0));
        setProofs(list);
        setLoading(false);
      },
      (err) => {
        console.error(err);
        toast.error('Could not load proofs');
        setLoading(false);
      }
    );
    return () => unsub();
  }, [isAdmin]);

  // Duplicate-image detection: any other proof (any status) with the same imageHash.
  const idsKey = proofs.map((p) => p.id).join('|');
  useEffect(() => {
    if (!isAdmin || proofs.length === 0) return;
    let cancelled = false;
    (async () => {
      const result: Record<string, boolean> = {};
      for (const p of proofs.slice(0, 50)) {
        let dup = false;
        const hashes = [p.imageHash, p.imageHash2].filter(Boolean) as string[];
        for (const h of hashes) {
          for (const field of ['imageHash', 'imageHash2']) {
            try {
              const snap = await getDocs(query(collection(db, 'offerProofs'), where(field, '==', h)));
              snap.forEach((d) => { if (d.id !== p.id) dup = true; });
            } catch (_) { /* ignore */ }
          }
        }
        result[p.id] = dup;
      }
      if (!cancelled) setDups(result);
    })();
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [idsKey, isAdmin]);

  // History (approved / rejected / all): newest first, loaded in pages of 25
  const pendingCount = proofs.length;
  useEffect(() => {
    if (!isAdmin || filter === 'pending') return;
    let cancelled = false;
    setHistLoading(true);
    getDocs(query(collection(db, 'offerProofs'), orderBy('createdAt', 'desc'), fsLimit(limitN)))
      .then((snap) => {
        if (cancelled) return;
        const list: OfferProof[] = [];
        snap.forEach((d) => list.push({ id: d.id, ...(d.data() as any) } as OfferProof));
        setHistory(list);
      })
      .catch((e) => {
        console.error(e);
        toast.error('Could not load proofs');
      })
      .finally(() => {
        if (!cancelled) setHistLoading(false);
      });
    return () => { cancelled = true; };
  }, [filter, limitN, pendingCount, isAdmin]);

  if (!isAdmin) {
    return <p className="text-sm text-text-muted text-center py-10">This tab is for the admin only.</p>;
  }

  const approve = async (p: OfferProof) => {
    if (busyId) return;
    setBusyId(p.id);
    try {
      await runTransaction(db, async (tx) => {
        const pRef = doc(db, 'offerProofs', p.id);
        const pSnap = await tx.get(pRef);
        if (!pSnap.exists() || (pSnap.data() as any).status !== 'pending') {
          throw new Error('This proof was already reviewed');
        }
        const proof = pSnap.data() as any;
        const cfgSnap = await tx.get(doc(db, 'appConfig', 'general'));
        const featSnap = await tx.get(doc(db, 'appConfig', 'features'));
        const info = rewardForOffer(String(proof.offerId), cfgSnap.data(), mergeFeatures(featSnap.data()));
        if (!info || !(info.reward > 0)) throw new Error('Offer or reward not found');
        const r = info.reward;
        tx.update(doc(db, 'users', proof.uid), {
          coins: increment(r),
          totalEarnings: increment(r),
          weeklyCoins: increment(r),
          monthlyCoins: increment(r)
        });
        tx.set(doc(collection(db, 'users', proof.uid, 'transactions')), {
          type: 'offer',
          amount: r,
          note: `Offer Reward: ${info.title}`,
          createdAt: Date.now()
        });
        tx.update(pRef, {
          status: 'approved',
          reviewedAt: serverTimestamp(),
          imageData: deleteField(),
          imageData2: deleteField()
        });
      });
      toast.success('Approved — coins added');
    } catch (e: any) {
      console.error(e);
      toast.error(e?.message || 'Could not approve');
    } finally {
      setBusyId(null);
    }
  };

  const reject = async (p: OfferProof) => {
    const text = reason.trim();
    if (!text) {
      toast.error('Please write a reject reason');
      return;
    }
    if (busyId) return;
    setBusyId(p.id);
    try {
      await runTransaction(db, async (tx) => {
        const pRef = doc(db, 'offerProofs', p.id);
        const pSnap = await tx.get(pRef);
        if (!pSnap.exists() || (pSnap.data() as any).status !== 'pending') {
          throw new Error('This proof was already reviewed');
        }
        tx.update(pRef, {
          status: 'rejected',
          rejectReason: text,
          reviewedAt: serverTimestamp(),
          imageData: deleteField(),
          imageData2: deleteField()
        });
      });
      toast.success('Rejected');
      setRejectingId(null);
      setReason('');
    } catch (e: any) {
      console.error(e);
      toast.error(e?.message || 'Could not reject');
    } finally {
      setBusyId(null);
    }
  };

  if (loading) {
    return <div className="py-10 flex justify-center"><Loader2 className="animate-spin text-accent" /></div>;
  }

  const shown: OfferProof[] =
    filter === 'pending' ? proofs : history.filter((h) => filter === 'all' || h.status === filter);
  const when = (p: OfferProof) => {
    const ms = p.createdAt?.toMillis?.() ?? 0;
    return ms ? new Date(ms).toLocaleString() : '';
  };
  const chips: { key: typeof filter; label: string }[] = [
    { key: 'pending', label: `Pending (${proofs.length})` },
    { key: 'approved', label: 'Approved' },
    { key: 'rejected', label: 'Rejected' },
    { key: 'all', label: 'All' }
  ];

  return (
    <div className="space-y-4">
      <h3 className="text-xs font-black uppercase tracking-[0.2em] px-1">Proofs ({shown.length})</h3>

      <div className="flex gap-2 overflow-x-auto pb-1">
        {chips.map((c) => (
          <button
            key={c.key}
            onClick={() => setFilter(c.key)}
            className={cn(
              'shrink-0 px-4 h-9 rounded-full text-xs font-black border',
              filter === c.key ? 'bg-accent text-black border-accent' : 'bg-white/5 text-text-muted border-white/10'
            )}
          >
            {c.label}
          </button>
        ))}
      </div>

      {filter !== 'pending' && histLoading && (
        <div className="py-6 flex justify-center"><Loader2 className="animate-spin text-accent" /></div>
      )}

      {shown.length === 0 && !(filter !== 'pending' && histLoading) && (
        <p className="text-sm text-text-muted text-center py-10">No proofs here.</p>
      )}

      {shown.map((p) => {
        const info = rewardForOffer(String(p.offerId), cfg || {}, feat);
        const isPending = p.status === 'pending';
        const imgs = [p.imageData, p.imageData2].filter(Boolean) as string[];
        return (
          <div key={p.id} className="p-4 bg-surface border border-border rounded-3xl space-y-3">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <p className="font-black truncate">{p.userName || 'User'}</p>
                <p className="text-[11px] text-text-muted truncate">{p.userEmail}</p>
              </div>
              <div className="text-right shrink-0">
                <p className="text-xs font-black text-accent">+{info ? info.reward : '?'} coins</p>
                {isPending && dups[p.id] && (
                  <span className="inline-flex items-center gap-1 mt-1 px-2 py-0.5 rounded-full bg-red-500/10 border border-red-500/30 text-red-400 text-[10px] font-black">
                    <AlertCircle size={10} /> Duplicate image
                  </span>
                )}
              </div>
            </div>
            <p className="text-xs text-text-muted">Offer: <span className="text-white font-bold">{p.offerTitle}</span></p>
            <div className="flex items-center justify-between gap-2">
              <span className="text-[10px] text-text-muted">{when(p)}</span>
              {!isPending && <ProofStatusBadge proof={p} />}
            </div>

            {imgs.length > 0 ? (
              <div className="grid grid-cols-2 gap-2">
                {imgs.map((img, i) => (
                  <img
                    key={i}
                    src={img}
                    alt={`proof ${i + 1}`}
                    onClick={() => setZoom(img)}
                    className="w-full h-40 object-cover rounded-xl border border-border bg-black cursor-zoom-in"
                  />
                ))}
              </div>
            ) : (
              !isPending && (
                <p className="text-[10px] text-text-muted">Screenshots are removed after review to save storage.</p>
              )
            )}

            {isPending && (rejectingId === p.id ? (
              <div className="space-y-2">
                <textarea
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  placeholder="Reject reason (required) — the user will see this"
                  className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-xs outline-none"
                  rows={2}
                />
                <div className="flex gap-2">
                  <button
                    onClick={() => reject(p)}
                    disabled={busyId === p.id}
                    className="flex-1 h-10 rounded-xl bg-red-500 text-white text-xs font-black disabled:opacity-60"
                  >
                    Confirm Reject
                  </button>
                  <button
                    onClick={() => { setRejectingId(null); setReason(''); }}
                    className="flex-1 h-10 rounded-xl bg-white/5 border border-white/10 text-xs font-bold"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex gap-2">
                <button
                  onClick={() => approve(p)}
                  disabled={busyId === p.id}
                  className="flex-1 h-10 rounded-xl bg-accent text-black text-xs font-black flex items-center justify-center gap-1 disabled:opacity-60"
                >
                  {busyId === p.id ? <Loader2 size={14} className="animate-spin" /> : <Check size={14} />} Approve
                </button>
                <button
                  onClick={() => { setRejectingId(p.id); setReason(''); }}
                  disabled={busyId === p.id}
                  className="flex-1 h-10 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 text-xs font-black flex items-center justify-center gap-1 disabled:opacity-60"
                >
                  <X size={14} /> Reject
                </button>
              </div>
            ))}
          </div>
        );
      })}

      {filter !== 'pending' && !histLoading && history.length >= limitN && (
        <button
          onClick={() => setLimitN(limitN + 25)}
          className="w-full h-11 rounded-xl bg-white/5 border border-white/10 text-xs font-bold"
        >
          Load more
        </button>
      )}

      {zoom && (
        <div className="fixed inset-0 z-[100] bg-black/95 flex items-center justify-center p-3" onClick={() => setZoom(null)}>
          <img src={zoom} alt="zoom" className="max-w-full max-h-full object-contain" />
        </div>
      )}
    </div>
  );
}

/** Admin: phones locked to an email (1 account per device). Reset a phone when its old account was deleted. */
function AdminDeviceLocks() {
  const [devices, setDevices] = useState<{ id: string; emails: string[]; createdAt?: number }[]>([]);
  const [loading, setLoading] = useState(false);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [search, setSearch] = useState('');

  const load = async () => {
    setLoading(true);
    try {
      const snap = await getDocs(query(collection(db, 'devices'), fsLimit(300)));
      const list: { id: string; emails: string[]; createdAt?: number }[] = [];
      snap.forEach((d) => {
        const data = d.data() as any;
        const emails = ((data.emails || []) as string[]).filter((e) => e && e !== ADMIN_EMAIL);
        if (emails.length) list.push({ id: d.id, emails, createdAt: data.createdAt });
      });
      list.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
      setDevices(list);
    } catch (e: any) {
      console.error(e);
      toast.error('Could not load devices');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const reset = async (ids: string[]) => {
    if (busyId || ids.length === 0) return;
    setBusyId(ids.length === 1 ? ids[0] : 'all');
    try {
      for (const id of ids) {
        await setDoc(doc(db, 'devices', id), { uids: [], emails: [], createdAt: Date.now() });
      }
      toast.success(ids.length === 1 ? 'Device lock reset' : `${ids.length} device locks reset`);
      await load();
    } catch (e: any) {
      console.error(e);
      toast.error(e?.message || 'Could not reset');
    } finally {
      setBusyId(null);
    }
  };

  const q = search.trim().toLowerCase();
  const shown = q ? devices.filter((d) => d.emails.some((e) => e.toLowerCase().includes(q))) : devices;

  return (
    <div className="space-y-3 pt-4 border-t border-white/10">
      <h3 className="text-xs font-black uppercase tracking-[0.2em] px-1">Device locks ({devices.length})</h3>
      <p className="text-[11px] text-text-muted px-1">
        Each phone can use 1 account. If an account was deleted and the same phone still says "Security Limit", reset that phone here.
      </p>
      <input
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        placeholder="Search email"
        className="w-full h-11 bg-white/5 border border-white/10 rounded-xl px-4 text-xs outline-none focus:border-accent/40"
      />
      {loading && <div className="py-4 flex justify-center"><Loader2 className="animate-spin text-accent" /></div>}
      {!loading && shown.length === 0 && (
        <p className="text-xs text-text-muted text-center py-4">No locked devices.</p>
      )}
      {shown.map((d) => (
        <div key={d.id} className="p-3 bg-surface border border-border rounded-2xl flex items-center justify-between gap-3">
          <div className="min-w-0">
            {d.emails.map((e) => (
              <p key={e} className="text-xs font-bold truncate">{e}</p>
            ))}
            <p className="text-[10px] text-text-muted">{d.createdAt ? new Date(d.createdAt).toLocaleString() : ''}</p>
          </div>
          <button
            onClick={() => reset([d.id])}
            disabled={busyId !== null}
            className="shrink-0 h-9 px-4 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 text-xs font-black disabled:opacity-60"
          >
            {busyId === d.id ? '...' : 'Reset'}
          </button>
        </div>
      ))}
      {shown.length > 1 && (
        <button
          onClick={() => {
            if (window.confirm(`Reset ${shown.length} devices?`)) reset(shown.map((d) => d.id));
          }}
          disabled={busyId !== null}
          className="w-full h-11 rounded-xl bg-white/5 border border-white/10 text-xs font-bold disabled:opacity-60"
        >
          Reset all shown ({shown.length})
        </button>
      )}
    </div>
  );
}

/** Admin: limits and rewards for Play & Earn and Complete Task & Earn (saved in appConfig/features). */
export function AdminLimitsTab() {
  const isAdmin = auth.currentUser?.email === ADMIN_EMAIL;
  const [form, setForm] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const fields: { key: keyof FeatureConfig; label: string; min: number; max: number }[] = [
    { key: 'gameDailyLimit', label: 'Play & Earn — rewarded games per user per day', min: 1, max: 100 },
    { key: 'gameCoinsPerGame', label: 'Play & Earn — coins per completed game (given instantly)', min: 0, max: 1000 },
    { key: 'taskDailyLimit', label: 'Complete Task & Earn — tasks per user per 24 hours', min: 0, max: 20 }
  ];

  useEffect(() => {
    if (!isAdmin) return;
    getDoc(doc(db, 'appConfig', 'features'))
      .then((s) => {
        const m = mergeFeatures(s.data());
        const next: Record<string, string> = {};
        (Object.keys(m) as (keyof FeatureConfig)[]).forEach((k) => { next[k] = String(m[k]); });
        setForm(next);
      })
      .catch(() => {
        const next: Record<string, string> = {};
        (Object.keys(DEFAULT_FEATURES) as (keyof FeatureConfig)[]).forEach((k) => { next[k] = String((DEFAULT_FEATURES as any)[k]); });
        setForm(next);
      })
      .finally(() => setLoading(false));
  }, [isAdmin]);

  if (!isAdmin) {
    return <p className="text-sm text-text-muted text-center py-10">This tab is for the admin only.</p>;
  }
  if (loading) {
    return <div className="py-10 flex justify-center"><Loader2 className="animate-spin text-accent" /></div>;
  }

  const save = async () => {
    const payload: any = {};
    for (const f of fields) {
      const n = Number(form[f.key]);
      if (!Number.isInteger(n) || n < f.min || n > f.max) {
        toast.error(`${f.label}: enter a whole number from ${f.min} to ${f.max}`);
        return;
      }
      payload[f.key] = n;
    }
    const owKey = (form.offerwallApiKey || '').trim();
    if (!/^[0-9a-fA-F]{32}$/.test(owKey)) {
      toast.error('OfferwallApi API key must be 32 letters/numbers (copy it from your OfferwallApi dashboard)');
      return;
    }
    payload.offerwallApiKey = owKey;
    setSaving(true);
    try {
      await setDoc(doc(db, 'appConfig', 'features'), payload, { merge: true });
      toast.success('Saved');
    } catch (e: any) {
      console.error(e);
      toast.error('Could not save');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-4">
      <h3 className="text-xs font-black uppercase tracking-[0.2em] px-1">Limits & Rewards</h3>
      <p className="text-[11px] text-text-muted px-1">
        Coins per Complete Task are set in Settings → "Reward Coins per Task". Task and extra-bonus limits are counted per rolling 24 hours.
      </p>
      {fields.map((f) => (
        <div key={f.key} className="space-y-2">
          <label className="text-[10px] text-gray-500 uppercase font-bold px-1">{f.label}</label>
          <input
            type="number"
            min={f.min}
            max={f.max}
            value={form[f.key] ?? ''}
            onChange={(e) => setForm({ ...form, [f.key]: e.target.value })}
            className="w-full h-12 bg-white/5 border border-white/10 rounded-xl px-4 text-sm outline-none focus:border-accent/40 transition-all font-mono"
          />
        </div>
      ))}
      <div className="space-y-2">
        <label className="text-[10px] text-gray-500 uppercase font-bold px-1">OfferwallApi API key (32 characters)</label>
        <input
          type="text"
          value={form.offerwallApiKey ?? ''}
          onChange={(e) => setForm({ ...form, offerwallApiKey: e.target.value })}
          className="w-full h-12 bg-white/5 border border-white/10 rounded-xl px-4 text-xs outline-none focus:border-accent/40 transition-all font-mono"
        />
      </div>
      <button
        onClick={save}
        disabled={saving}
        className="w-full h-12 rounded-xl bg-accent text-black font-black text-sm disabled:opacity-60"
      >
        {saving ? 'Saving...' : 'Save'}
      </button>
      <AdminDeviceLocks />
    </div>
  );
}
