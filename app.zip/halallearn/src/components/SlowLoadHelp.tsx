import React, { useEffect, useState } from 'react';
import { signOut } from 'firebase/auth';
import { auth } from '../firebase';

/** Shown under the loading spinner. If loading takes too long, the user gets a way out. */
export function SlowLoadHelp() {
  const [slow, setSlow] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setSlow(true), 12000);
    return () => clearTimeout(t);
  }, []);

  if (!slow) return null;

  return (
    <div className="space-y-3 pt-2 w-full max-w-xs">
      <p className="text-[11px] text-text-muted">Taking longer than usual. Check your internet connection.</p>
      <button
        onClick={() => window.location.reload()}
        className="w-full h-11 rounded-xl bg-accent text-black font-black text-sm"
      >
        Reload
      </button>
      <button
        onClick={async () => {
          try {
            await signOut(auth);
          } catch (_) {
            /* ignore */
          }
          window.location.reload();
        }}
        className="w-full h-11 rounded-xl bg-white/10 text-white font-bold text-sm"
      >
        Sign out and try again
      </button>
    </div>
  );
}
