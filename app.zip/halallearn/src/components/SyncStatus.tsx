import React, { useEffect, useState } from 'react';
import { doc, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase';

interface Status {
  authCount?: number;
  docCount?: number;
  lastRun?: number;
  pending?: number;
  blocked?: boolean;
}

/** Admin only: shows how many login accounts Firebase has and how many profiles are listed here (no buttons, it runs by itself). */
export function SyncStatusLine({ listed }: { listed: number }) {
  const [st, setSt] = useState<Status | null>(null);

  useEffect(
    () =>
      onSnapshot(
        doc(db, 'syncState', 'status'),
        (s) => setSt(s.exists() ? (s.data() as Status) : null),
        () => setSt(null)
      ),
    []
  );

  const mins = st?.lastRun ? Math.max(0, Math.round((Date.now() - st.lastRun) / 60000)) : null;

  return (
    <div className="bg-surface border border-border rounded-2xl px-4 py-3 text-[11px] text-text-muted space-y-1">
      <p>
        Profiles listed here: <b className="text-text-primary">{listed}</b>
        {st?.authCount !== undefined && (
          <>
            {' '}· Firebase login accounts: <b className="text-text-primary">{st.authCount}</b>
          </>
        )}
      </p>
      {st ? (
        <p>
          Last automatic check: {mins === null ? '-' : mins < 1 ? 'just now' : `${mins} min ago`}
          {st.pending ? ` · ${st.pending} waiting to be removed` : ''}
          {st.blocked ? ' · paused (too many accounts looked removed, nothing was deleted)' : ''}
        </p>
      ) : (
        <p>No automatic check has run yet. It starts when the server is awake.</p>
      )}
    </div>
  );
}
