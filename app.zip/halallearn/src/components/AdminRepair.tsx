import React, { useState } from 'react';
import { collection, doc, getDoc, getDocs, query, updateDoc, where } from 'firebase/firestore';
import { toast } from 'react-hot-toast';
import { Loader2 } from 'lucide-react';
import { auth, db } from '../firebase';
import { SERVER_URL } from '../lib/server';

interface Info {
  uid: string;
  name: string;
  email: string;
  coins: number;
  totalEarnings: number;
  historyTotal: number;
  historyEarned: number;
  count: number;
  last: { note: string; amount: number; createdAt: number }[];
}

/**
 * Admin Hub -> Repair.
 * If a user's wallet was reset to 0 but the history still shows the coins, this adds up the history
 * and (after you confirm) puts the total back into the wallet.
 * History: money coming in is +, withdrawals are -, so wallet = sum of all history amounts.
 */
function RestoreCard() {
  const [term, setTerm] = useState('');
  const [busy, setBusy] = useState(false);
  const [saving, setSaving] = useState(false);
  const [info, setInfo] = useState<Info | null>(null);

  const check = async () => {
    const q = term.trim();
    if (!q) return;
    setBusy(true);
    setInfo(null);
    try {
      let uid = '';
      let data: any = null;
      if (q.includes('@')) {
        const snap = await getDocs(query(collection(db, 'users'), where('email', '==', q)));
        if (snap.empty) return void toast.error('No user with this email');
        uid = snap.docs[0].id;
        data = snap.docs[0].data();
      } else {
        const s = await getDoc(doc(db, 'users', q));
        if (!s.exists()) return void toast.error('No user with this ID');
        uid = s.id;
        data = s.data();
      }
      const txs = await getDocs(collection(db, 'users', uid, 'transactions'));
      let historyTotal = 0;
      let historyEarned = 0;
      const list: Info['last'] = [];
      txs.forEach((d) => {
        const x: any = d.data();
        const a = Number(x.amount) || 0;
        historyTotal += a;
        if (a > 0) historyEarned += a;
        list.push({ note: String(x.note || x.type || ''), amount: a, createdAt: Number(x.createdAt) || 0 });
      });
      list.sort((a, b) => b.createdAt - a.createdAt);
      setInfo({
        uid,
        name: String(data.name || ''),
        email: String(data.email || ''),
        coins: Number(data.coins) || 0,
        totalEarnings: Number(data.totalEarnings) || 0,
        historyTotal,
        historyEarned,
        count: list.length,
        last: list.slice(0, 8)
      });
    } catch (_) {
      toast.error('Could not load this user');
    } finally {
      setBusy(false);
    }
  };

  const apply = async () => {
    if (!info) return;
    if (info.historyTotal < 0) return void toast.error('History total is negative, check the history first');
    if (
      !window.confirm(
        `${info.name || info.email}: set wallet from ${info.coins} to ${info.historyTotal} coins and total earnings to ${info.historyEarned}?`
      )
    )
      return;
    setSaving(true);
    try {
      await updateDoc(doc(db, 'users', info.uid), { coins: info.historyTotal, totalEarnings: info.historyEarned });
      toast.success('Wallet restored');
      setInfo({ ...info, coins: info.historyTotal, totalEarnings: info.historyEarned });
    } catch (_) {
      toast.error('Could not save');
    } finally {
      setSaving(false);
    }
  };

  const same = info && info.coins === info.historyTotal;

  return (
    <div className="bg-surface border border-border rounded-2xl p-4 space-y-4">
      <h3 className="text-sm font-black">Restore a wallet from history</h3>
      <p className="text-[11px] text-text-muted">
        Type the user's email or user ID. This compares the wallet with the sum of the history.
      </p>
      <div className="flex gap-2">
        <input
          className="w-full h-11 bg-white/5 border border-white/10 rounded-xl px-3 text-sm outline-none focus:border-accent/40"
          placeholder="email or user ID"
          value={term}
          onChange={(e) => setTerm(e.target.value)}
        />
        <button onClick={check} disabled={busy} className="px-4 rounded-xl bg-white/10 text-xs font-bold shrink-0">
          {busy ? <Loader2 className="animate-spin" size={16} /> : 'Check'}
        </button>
      </div>

      {info && (
        <div className="space-y-3">
          <div className="bg-white/5 rounded-xl p-3 space-y-1">
            <p className="text-sm font-bold">{info.name || info.uid}</p>
            <p className="text-[10px] text-text-muted">{info.email}</p>
            <p className="text-xs">Wallet now: <b>{info.coins}</b> coins</p>
            <p className="text-xs">History total ({info.count} entries): <b>{info.historyTotal}</b> coins</p>
            <p className="text-xs">Total ever earned (history): <b>{info.historyEarned}</b></p>
          </div>
          <div className="space-y-1">
            {info.last.map((t, i) => (
              <div key={i} className="flex justify-between text-[11px] text-text-muted">
                <span className="truncate pr-2">{t.note}</span>
                <span className={t.amount > 0 ? 'text-accent' : 'text-red-400'}>{t.amount > 0 ? '+' : ''}{t.amount}</span>
              </div>
            ))}
          </div>
          {same ? (
            <p className="text-xs text-accent font-bold">The wallet already matches the history. Nothing to fix.</p>
          ) : (
            <>
              <p className="text-[10px] text-yellow-400">
                Look at the entries above first. Use this only if the wallet is wrong (for example 0) and the history is right.
              </p>
              <button
                onClick={apply}
                disabled={saving}
                className="w-full h-12 rounded-xl bg-accent text-black font-black text-sm"
              >
                {saving ? 'Saving...' : `Set wallet to ${info.historyTotal}`}
              </button>
            </>
          )}
        </div>
      )}
    </div>
  );
}


interface SyncResult {
  authCount: number;
  docCount: number;
  total: number;
  orphans: { uid: string; name: string; email: string }[];
}

/**
 * People deleted in Firebase Authentication still have a profile (coins) in the database, so they stay on the leaderboard.
 * This finds those profiles and (after you confirm) removes them.
 */
function SyncCard() {
  const [busy, setBusy] = useState(false);
  const [res, setRes] = useState<SyncResult | null>(null);

  const call = async (body: Record<string, unknown>) => {
    const token = await auth.currentUser?.getIdToken();
    if (!token) throw new Error('login');
    const r = await fetch(`${SERVER_URL}/admin/sync-users`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(data.error || 'error');
    return data;
  };

  const explain = (e: unknown) => {
    const m = e instanceof Error ? e.message : '';
    if (m === 'not-admin') return 'Only the admin account can do this';
    if (m === 'changed') return 'The list changed. Press Check again.';
    if (m === 'too-many') return 'More than half of the profiles look removed. This looks like a mistake, nothing was deleted.';
    return 'Could not reach the server. It may be waking up, try again in a minute.';
  };

  const check = async () => {
    setBusy(true);
    try {
      setRes(await call({ mode: 'check' }));
    } catch (e) {
      toast.error(explain(e));
    } finally {
      setBusy(false);
    }
  };

  const remove = async () => {
    if (!res || res.total === 0) return;
    if (
      !window.confirm(
        `Delete the data (coins, history) of ${res.total} users who no longer have a login account? This cannot be undone.`
      )
    )
      return;
    setBusy(true);
    try {
      const out = await call({ mode: 'delete', expected: res.total });
      toast.success(`Removed ${out.deleted} profiles`);
      setRes(await call({ mode: 'check' }));
    } catch (e) {
      toast.error(explain(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="bg-surface border border-border rounded-2xl p-4 space-y-4">
      <h3 className="text-sm font-black">Match the database with login accounts</h3>
      <p className="text-[11px] text-text-muted">
        If you delete a user in Firebase Authentication, their coins stay in the database and they stay on the
        leaderboard. Check finds those users. Nothing is deleted until you confirm.
      </p>
      <button onClick={check} disabled={busy} className="w-full h-11 rounded-xl bg-white/10 text-xs font-bold">
        {busy ? <Loader2 className="animate-spin mx-auto" size={16} /> : 'Check'}
      </button>

      {res && (
        <div className="space-y-3">
          <div className="bg-white/5 rounded-xl p-3 space-y-1 text-xs">
            <p>Login accounts: <b>{res.authCount}</b></p>
            <p>Profiles in the database: <b>{res.docCount}</b></p>
            <p>Profiles without a login account: <b>{res.total}</b></p>
          </div>
          {res.orphans.length > 0 && (
            <div className="space-y-1 max-h-48 overflow-y-auto">
              {res.orphans.map((o) => (
                <div key={o.uid} className="flex justify-between text-[11px] text-text-muted">
                  <span className="truncate pr-2">{o.name || o.uid}</span>
                  <span className="truncate">{o.email}</span>
                </div>
              ))}
              {res.total > res.orphans.length && (
                <p className="text-[10px] text-text-muted">...and {res.total - res.orphans.length} more</p>
              )}
            </div>
          )}
          {res.total === 0 ? (
            <p className="text-xs text-accent font-bold">Everything matches. Nothing to remove.</p>
          ) : (
            <button
              onClick={remove}
              disabled={busy}
              className="w-full h-12 rounded-xl bg-red-500/90 text-white font-black text-sm"
            >
              Delete these {res.total} profiles
            </button>
          )}
        </div>
      )}
    </div>
  );
}

export function AdminRepairTab() {
  return (
    <div className="space-y-6">
      <SyncCard />
      <RestoreCard />
    </div>
  );
}
