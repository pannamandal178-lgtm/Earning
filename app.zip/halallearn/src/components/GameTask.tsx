import React, { useEffect, useRef, useState } from 'react';
import { doc, onSnapshot, serverTimestamp, setDoc } from 'firebase/firestore';
import { toast } from 'react-hot-toast';
import { Gamepad2, Check, Loader2 } from 'lucide-react';
import { auth, db } from '../firebase';
import { tr } from '../lib/i18n';
import {
  TASK_SERVER_URL,
  injectTaskAd,
  normalizeTaskConfig,
  taskDay,
  type TaskConfig
} from '../lib/taskGame';

type Phase = 'idle' | 'starting' | 'waiting' | 'saving';

/**
 * Tap -> the ad is shown -> the user stays on the ad for the wait time (5 seconds) -> task counted.
 * Leaving earlier = not counted. The daily limit and the wait time are checked again on the server.
 * Coins are paid by the admin the next day, from the admin panel (Tasks tab).
 */
export function GameTaskCard({ uid }: { uid: string }) {
  const [cfg, setCfg] = useState<TaskConfig>(normalizeTaskConfig(null));
  const [count, setCount] = useState(0);
  const [today, setToday] = useState(taskDay(Date.now()));
  const [phase, setPhase] = useState<Phase>('idle');
  const [left, setLeft] = useState(0);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const run = useRef<{ t0: number; wait: number; hidden: boolean; done: boolean } | null>(null);

  useEffect(
    () =>
      onSnapshot(
        doc(db, 'appConfig', 'taskGame'),
        (s) => setCfg(normalizeTaskConfig(s.exists() ? s.data() : null)),
        () => {}
      ),
    []
  );

  useEffect(() => {
    if (!uid) return;
    return onSnapshot(
      doc(db, 'gameTasks', `${uid}_${today}`),
      (s) => setCount(s.exists() ? Number((s.data() as any).count) || 0 : 0),
      () => setCount(0)
    );
  }, [uid, today]);

  // the day changes at midnight India time
  useEffect(() => {
    const t = setInterval(() => {
      const d = taskDay(Date.now());
      setToday((prev) => (prev === d ? prev : d));
    }, 60000);
    return () => clearInterval(t);
  }, []);

  // wake the (free) server up while the user looks at the card
  useEffect(() => {
    fetch(`${TASK_SERVER_URL}/health`).catch(() => {});
  }, []);

  const finish = async () => {
    setPhase('saving');
    try {
      const token = await auth.currentUser?.getIdToken();
      if (!token) throw new Error('no-token');
      const res = await fetch(`${TASK_SERVER_URL}/task/complete`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json().catch(() => ({}));
      if (res.ok && data.ok) {
        setMsg({ ok: true, text: tr('task.done') });
        toast.success(tr('task.done'));
      } else if (data.error === 'limit') {
        setMsg({ ok: false, text: tr('task.limit', { max: cfg.dailyLimit }) });
      } else if (data.error === 'too-early') {
        setMsg({ ok: false, text: tr('task.early') });
      } else {
        setMsg({ ok: false, text: tr('task.error') });
      }
    } catch (_) {
      setMsg({ ok: false, text: tr('task.error') });
    } finally {
      setPhase('idle');
    }
  };

  const start = async () => {
    if (phase !== 'idle' || count >= cfg.dailyLimit || !uid) return;
    setMsg(null);
    setPhase('starting');
    injectTaskAd(cfg.adZone); // inside the tap, so the ad can open
    fetch(`${TASK_SERVER_URL}/health`).catch(() => {});
    try {
      // the start time is the real server time (Firestore rules force it)
      await setDoc(doc(db, 'taskStarts', uid), { startedAt: serverTimestamp() });
    } catch (_) {
      setPhase('idle');
      setMsg({ ok: false, text: tr('task.error') });
      return;
    }
    run.current = { t0: Date.now(), wait: cfg.waitSeconds * 1000, hidden: document.visibilityState === 'hidden', done: false };
    setLeft(cfg.waitSeconds);
    setPhase('waiting');
  };

  const cancel = () => {
    if (run.current) run.current.done = true;
    setPhase('idle');
  };

  // while waiting: count the seconds and watch whether the user leaves the ad too early
  useEffect(() => {
    if (phase !== 'waiting' || !run.current) return;
    const r = run.current;
    const check = () => {
      if (r.done) return;
      const elapsed = Date.now() - r.t0;
      setLeft(Math.max(0, Math.ceil((r.wait - elapsed) / 1000)));
      if (document.visibilityState === 'hidden') {
        r.hidden = true; // the user is looking at the ad in another tab
        return;
      }
      if (elapsed >= r.wait) {
        r.done = true;
        finish();
        return;
      }
      if (r.hidden) {
        // came back before the time was over
        r.done = true;
        setPhase('idle');
        setMsg({ ok: false, text: tr('task.early') });
      }
    };
    const id = setInterval(check, 250);
    document.addEventListener('visibilitychange', check);
    return () => {
      clearInterval(id);
      document.removeEventListener('visibilitychange', check);
    };
  }, [phase]);

  const limit = cfg.dailyLimit;
  const finished = count >= limit;
  const rates = Object.keys(cfg.payout)
    .map(Number)
    .filter((n) => n <= limit)
    .sort((a, b) => a - b);

  return (
    <div className="glass-card p-5 space-y-4">
      <div className="flex items-center gap-3">
        <div className="w-11 h-11 rounded-xl bg-accent/10 flex items-center justify-center">
          <Gamepad2 className="w-5 h-5 text-accent" />
        </div>
        <div className="flex-1">
          <h4 className="font-bold">{tr('task.title')}</h4>
          <p className="text-[11px] text-text-muted">{tr('task.count', { n: count, max: limit })}</p>
        </div>
        {finished && (
          <span className="w-7 h-7 rounded-full bg-accent text-black flex items-center justify-center">
            <Check size={16} />
          </span>
        )}
      </div>

      <div className="flex gap-1.5">
        {Array.from({ length: limit }, (_, i) => (
          <div key={i} className={'h-2 flex-1 rounded-full ' + (i < count ? 'bg-accent' : 'bg-white/10')} />
        ))}
      </div>

      {rates.length > 0 && (
        <div className="flex flex-wrap gap-1.5">
          {rates.map((n) => (
            <span key={n} className="px-2 py-1 rounded-lg bg-white/5 text-[10px] font-bold text-text-muted">
              {n} {n === 1 ? 'task' : 'tasks'} = <span className="text-accent">{cfg.payout[String(n)]}</span>
            </span>
          ))}
        </div>
      )}

      {phase === 'waiting' ? (
        <div className="space-y-2">
          <div className="w-full h-12 rounded-xl bg-white/10 flex items-center justify-center font-black text-sm">
            {tr('task.wait', { s: left })}
          </div>
          <button onClick={cancel} className="w-full h-10 rounded-xl bg-white/5 text-text-muted text-xs font-bold">
            {tr('task.cancel')}
          </button>
        </div>
      ) : (
        <button
          onClick={start}
          disabled={phase !== 'idle' || finished}
          className={
            'w-full h-12 rounded-xl font-black text-sm flex items-center justify-center gap-2 ' +
            (finished ? 'bg-white/5 text-text-muted' : 'bg-accent text-black')
          }
        >
          {phase === 'starting' || phase === 'saving' ? (
            <>
              <Loader2 className="animate-spin" size={16} /> {tr('task.saving')}
            </>
          ) : finished ? (
            tr('task.limit', { max: limit })
          ) : (
            tr('task.cta')
          )}
        </button>
      )}

      {msg && <p className={'text-xs font-bold ' + (msg.ok ? 'text-accent' : 'text-yellow-400')}>{msg.text}</p>}

      <p className="text-[10px] text-text-muted">{tr('task.sub', { s: cfg.waitSeconds })}</p>
      <p className="text-[10px] text-text-muted">{tr('task.note')}</p>
    </div>
  );
}
