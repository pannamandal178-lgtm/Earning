import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import { AdBlockGate } from './components/AdBlockGate';
import './index.css';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <AdBlockGate>
      <App />
    </AdBlockGate>
  </StrictMode>,
);
