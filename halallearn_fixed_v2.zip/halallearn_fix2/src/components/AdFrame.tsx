import React, { useEffect, useRef, useState } from 'react';
import { tr } from '../lib/i18n';

/**
 * Shows an ad script inside a sandboxed iframe (no access to the app, its login or its storage),
 * with a countdown. onDone fires when the countdown ends. onCancel closes it with no reward.
 * NOTE: a plain ad script cannot confirm that the ad was really watched; the countdown is the only check.
 */
export function AdFrame({
  scriptUrl,
  seconds,
  reward = true,
  onDone,
  onCancel
}: {
  scriptUrl: string;
  seconds: number;
  reward?: boolean;
  onDone: () => void;
  onCancel: () => void;
}) {
  const [left, setLeft] = useState(Math.max(1, Math.round(seconds)));
  const doneRef = useRef(false);
  const valid = /^https:\/\/[^\s"'<>]+$/.test(scriptUrl);

  useEffect(() => {
    if (!valid) return;
    const t = window.setInterval(() => setLeft((l) => l - 1), 1000);
    return () => window.clearInterval(t);
  }, [valid]);

  useEffect(() => {
    if (valid && left <= 0 && !doneRef.current) {
      doneRef.current = true;
      onDone();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [left]);

  const srcDoc = valid
    ? '<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"></head>' +
      '<body style="margin:0;background:#0f172a;min-height:100vh"><script src="' + scriptUrl + '"><\/script></body></html>'
    : '';

  return (
    <div className="fixed inset-0 z-[95] bg-black/95 flex flex-col items-center justify-center p-4 gap-4">
      <p className="text-xs font-black uppercase tracking-[0.3em] text-text-muted">{tr('ad.label')}</p>
      {valid ? (
        <iframe
          title="advertisement"
          sandbox="allow-scripts allow-popups allow-popups-to-escape-sandbox"
          srcDoc={srcDoc}
          style={{ width: '100%', maxWidth: 400, height: '55vh', border: 0, background: '#0f172a', borderRadius: 12 }}
        />
      ) : (
        <p className="text-sm text-red-400">{tr('ad.unavailable')}</p>
      )}
      {valid && (
        <p className="text-sm font-bold text-accent">{tr(reward ? 'ad.wait' : 'ad.continue', { s: Math.max(0, left) })}</p>
      )}
      <button
        onClick={onCancel}
        className="px-6 h-10 rounded-xl bg-white/5 border border-white/10 text-xs font-bold text-text-muted"
      >
        {tr('ad.close')}
      </button>
    </div>
  );
}
