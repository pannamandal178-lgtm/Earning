import { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { toast } from 'react-hot-toast';
import { Loader2, X } from 'lucide-react';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { auth, db } from '../firebase';
import { ADMIN_EMAIL } from './Proofs';

const EMPTY_TEXT = 'The Privacy Policy will be published soon.';

/** Full-screen Privacy Policy page. The text is written by the admin (Admin > Settings > Privacy Policy). */
export function PrivacyPolicyPage({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [text, setText] = useState<string | null>(null);

  useEffect(() => {
    if (!open) return;
    let cancelled = false;
    setText(null);
    getDoc(doc(db, 'appConfig', 'privacy'))
      .then((snap) => {
        if (cancelled) return;
        const t = snap.exists() ? String((snap.data() as any).text || '').trim() : '';
        setText(t || EMPTY_TEXT);
      })
      .catch(() => {
        if (!cancelled) setText(EMPTY_TEXT);
      });
    return () => {
      cancelled = true;
    };
  }, [open]);

  if (!open) return null;
  // Shown through a portal so it covers the whole screen, even when opened from inside the animated login card
  return createPortal(
    <div className="fixed inset-0 z-[200] bg-background flex flex-col">
      <div className="flex items-center justify-between p-5 border-b border-white/10">
        <h2 className="text-lg font-black text-white">Privacy Policy</h2>
        <button onClick={onClose} className="p-3 bg-surface rounded-2xl text-text-primary active:scale-95 transition-all">
          <X size={18} />
        </button>
      </div>
      <div className="flex-1 overflow-y-auto p-5">
        {text === null ? (
          <div className="py-10 flex justify-center">
            <Loader2 className="animate-spin text-accent" />
          </div>
        ) : (
          <p className="text-sm text-text-primary leading-relaxed whitespace-pre-wrap break-words">{text}</p>
        )}
      </div>
    </div>,
    document.body
  );
}

/** Admin card: write the Privacy Policy in your own words and save it. */
export function AdminPrivacyEditor() {
  const isAdmin = auth.currentUser?.email === ADMIN_EMAIL;
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!isAdmin) return;
    getDoc(doc(db, 'appConfig', 'privacy'))
      .then((snap) => setText(snap.exists() ? String((snap.data() as any).text || '') : ''))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [isAdmin]);

  if (!isAdmin) return null;

  const save = async () => {
    setSaving(true);
    try {
      await setDoc(doc(db, 'appConfig', 'privacy'), { text: text.trim(), updatedAt: Date.now() });
      toast.success('Privacy Policy saved');
    } catch (e: any) {
      console.error(e);
      toast.error(e?.message || 'Could not save');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-3 pt-6 border-t border-white/10">
      <h3 className="text-xs font-black uppercase tracking-[0.2em] px-1">Privacy Policy (your own words)</h3>
      <p className="text-[11px] text-text-muted px-1">
        This text opens when a user taps "Privacy Policy" on the login page. Empty = "will be published soon".
      </p>
      {loading ? (
        <div className="py-4 flex justify-center">
          <Loader2 className="animate-spin text-accent" />
        </div>
      ) : (
        <>
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            rows={12}
            placeholder="Write your Privacy Policy here..."
            className="w-full bg-white/5 border border-white/10 rounded-xl p-4 text-sm outline-none focus:border-accent/40"
          />
          <button
            onClick={save}
            disabled={saving}
            className="w-full h-12 rounded-xl bg-accent text-black text-sm font-black disabled:opacity-60 flex items-center justify-center gap-2"
          >
            {saving && <Loader2 size={16} className="animate-spin" />}
            Save Privacy Policy
          </button>
        </>
      )}
    </div>
  );
}
