import { useCallback, useEffect, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import { DEFAULT_FEATURES } from '../lib/featureConfig';
import { tr } from '../lib/i18n';

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

/** true = an ad blocker (extension, ad-filter DNS, blocking browser) is very likely active. */
async function adBlockerActive(): Promise<boolean> {
  // 1) Bait element: cosmetic filters hide elements with ad-like class names.
  const bait = document.createElement('div');
  bait.className = 'adsbox ad-banner ad_unit ad-placement textads banner-ads pub_300x250';
  bait.style.cssText = 'position:absolute;left:-9999px;top:-9999px;width:10px;height:10px;';
  bait.innerHTML = '&nbsp;';
  document.body.appendChild(bait);
  await sleep(200);
  const cs = window.getComputedStyle(bait);
  const hidden = bait.offsetHeight === 0 || cs.display === 'none' || cs.visibility === 'hidden';
  bait.remove();
  if (hidden) return true;

  // 2) Network: can the ad script be reached while the normal internet works?
  if (!navigator.onLine) return false;
  const tryFetch = async (url: string, ms: number): Promise<'ok' | 'fail' | 'timeout'> => {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), ms);
    try {
      await fetch(url, { mode: 'no-cors', cache: 'no-store', signal: ctrl.signal });
      return 'ok';
    } catch (e: any) {
      return e?.name === 'AbortError' ? 'timeout' : 'fail';
    } finally {
      clearTimeout(t);
    }
  };
  // Only the ad domain's home page is checked, never the ad link itself (that would count as a click)
  let adHost = '';
  try {
    adHost = new URL(DEFAULT_FEATURES.gameAdLinkUrl).origin + '/';
  } catch (_) {
    return false;
  }
  const ad = await tryFetch(adHost, 8000);
  if (ad !== 'fail') return false;
  const control = await tryFetch('https://www.gstatic.com/generate_204', 8000);
  return control === 'ok';
}

/** Wraps the whole app. If an ad blocker is detected, the app is covered until it is turned off. */
export function AdBlockGate({ children }: { children: ReactNode }) {
  const [blocked, setBlocked] = useState(false);
  const [checking, setChecking] = useState(false);
  const busy = useRef(false);

  const check = useCallback(async () => {
    if (busy.current) return;
    busy.current = true;
    setChecking(true);
    try {
      setBlocked(await adBlockerActive());
    } catch {
      /* never lock users out because of a failed check */
    } finally {
      busy.current = false;
      setChecking(false);
    }
  }, []);

  useEffect(() => {
    check();
    const onVisible = () => {
      if (!document.hidden) check();
    };
    document.addEventListener('visibilitychange', onVisible);
    const timer = window.setInterval(check, 60000);
    return () => {
      document.removeEventListener('visibilitychange', onVisible);
      window.clearInterval(timer);
    };
  }, [check]);

  return (
    <>
      {children}
      {blocked && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            zIndex: 100000,
            background: '#050816',
            color: '#fff',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            padding: 24,
            textAlign: 'center'
          }}
        >
          <div style={{ fontSize: 56 }}>🚫</div>
          <h2 style={{ fontSize: 22, fontWeight: 900, margin: '12px 0 8px' }}>{tr('adblock.title')}</h2>
          <p style={{ fontSize: 14, color: '#cbd5e1', maxWidth: 320, lineHeight: 1.6 }}>{tr('adblock.text')}</p>
          <button
            onClick={check}
            disabled={checking}
            style={{
              marginTop: 24,
              padding: '14px 24px',
              borderRadius: 14,
              border: 'none',
              background: '#22c55e',
              color: '#000',
              fontWeight: 900,
              fontSize: 14,
              opacity: checking ? 0.6 : 1
            }}
          >
            {tr('adblock.retry')}
          </button>
        </div>
      )}
    </>
  );
}
