import React from 'react';
import { getLang, setLang, tr } from '../lib/i18n';
import { cn } from '../lib/utils';

export function LanguageSelector() {
  const current = getLang();
  return (
    <div className="p-6 bg-background/20 rounded-3xl border border-border space-y-4">
      <div>
        <h4 className="text-[10px] font-black uppercase tracking-[0.3em] text-text-muted">{tr('lang.title')}</h4>
        <p className="text-xs text-text-muted mt-1">{tr('lang.note')}</p>
      </div>
      <div className="flex bg-background/50 p-1 rounded-2xl border border-border">
        {([['en', 'English'], ['bn', 'বাংলা']] as const).map(([code, label]) => (
          <button
            key={code}
            onClick={() => { if (code !== current) setLang(code); }}
            className={cn(
              'flex-1 py-3 text-xs font-black rounded-xl transition-all',
              current === code ? 'bg-accent text-black shadow-lg' : 'text-text-muted hover:text-white'
            )}
          >
            {label}
          </button>
        ))}
      </div>
    </div>
  );
}
