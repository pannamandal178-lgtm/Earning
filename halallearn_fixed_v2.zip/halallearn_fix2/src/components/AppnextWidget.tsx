import React, { useMemo } from 'react';
import { useFeatureConfig } from '../lib/featureConfig';
import { tr } from '../lib/i18n';

const ID_RE = /^[0-9a-fA-F-]{32,40}$/;

/**
 * Appnext "Recommendation Widget" (mobile web) shown on the Home screen as a normal ad.
 * It runs inside a sandboxed iframe (no access to the app, login or storage). No coins are given for it.
 */
export function AppnextWidget() {
  const f = useFeatureConfig();
  const androidId = f.appnextAndroidId;
  const iosId = f.appnextIosId || f.appnextAndroidId;
  const valid = ID_RE.test(androidId) && ID_RE.test(iosId);

  const srcDoc = useMemo(() => {
    if (!valid) return '';
    return (
      '<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"></head>' +
      '<body style="margin:0;background:transparent">' +
      '<div id="appnext_recommendation"></div>' +
      '<script type="text/javascript">' +
      'var Appnext_Widget = {' +
      'parent_url: ' + JSON.stringify(window.location.origin) + ',' +
      "android_id: '" + androidId + "'," +
      "ios_id: '" + iosId + "'," +
      "ph: 'appnext_recommendation'," +
      "cnt: '', pbk: '', mute: '', creative: '', subid: '', b_title: '', b_color: '', title: ''," +
      "ad_server: 'true'" +
      '};' +
      '(function(){var _s=document.createElement("script");_s.type="text/javascript";_s.async=true;' +
      '_s.src="https://cdn3.appnext.com/tools/tags/widget/m.js";document.body.appendChild(_s);})();' +
      '<\/script></body></html>'
    );
  }, [valid, androidId, iosId]);

  if (!valid) return null;

  return (
    <div className="glass-card p-4 space-y-2">
      <p className="text-[10px] font-black uppercase tracking-[0.3em] text-text-muted">{tr('sponsored')}</p>
      <iframe
        title="sponsored apps"
        sandbox="allow-scripts allow-popups allow-popups-to-escape-sandbox"
        srcDoc={srcDoc}
        style={{ width: '100%', height: 260, border: 0, borderRadius: 12, background: 'transparent' }}
      />
    </div>
  );
}
