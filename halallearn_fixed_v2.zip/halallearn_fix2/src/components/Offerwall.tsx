import { useState } from 'react';
import { createPortal } from 'react-dom';
import { ArrowRight, Gift, X } from 'lucide-react';
import { CLIXWALL_API_KEY } from '../constants';
import { tr } from '../lib/i18n';

/** Full-screen ClixWall offerwall. Coins are added by the postback server after the user finishes an offer. */
function OfferwallPage({ open, userId, onClose }: { open: boolean; userId: string; onClose: () => void }) {
  if (!open) return null;
  const src = `https://clixwall.com/wall?api=${CLIXWALL_API_KEY}&user=${encodeURIComponent(userId)}&theme=dark`;
  // Shown through a portal so it covers the whole screen
  return createPortal(
    <div className="fixed inset-0 z-[200] bg-background flex flex-col">
      <div className="flex items-center justify-between gap-3 p-4 border-b border-white/10">
        <div className="min-w-0">
          <h2 className="text-lg font-black text-white">{tr('offers.title')}</h2>
          <p className="text-[11px] text-text-muted">{tr('offers.note')}</p>
        </div>
        <button onClick={onClose} className="shrink-0 p-3 bg-surface rounded-2xl text-text-primary active:scale-95 transition-all">
          <X size={18} />
        </button>
      </div>
      <iframe src={src} title="Offers" className="flex-1 w-full border-0" allow="clipboard-write" />
    </div>,
    document.body
  );
}

/** Home card that opens the offerwall. */
export function OffersCard({ userId }: { userId: string }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <div
        onClick={() => setOpen(true)}
        className="glass-card p-5 flex items-center justify-between gap-3 cursor-pointer active:scale-[0.98] transition-all border-l-4 border-l-blue-500/50 group"
      >
        <div className="flex items-center gap-4 min-w-0">
          <div className="w-12 h-12 shrink-0 rounded-2xl bg-blue-500/10 flex items-center justify-center text-blue-400">
            <Gift size={24} />
          </div>
          <div className="min-w-0">
            <h4 className="font-bold">{tr('offers.title')}</h4>
            <p className="text-[10px] text-text-muted">{tr('offers.sub')}</p>
          </div>
        </div>
        <ArrowRight size={16} className="shrink-0 text-text-muted group-hover:text-blue-400 transition-colors" />
      </div>
      <OfferwallPage open={open} userId={userId} onClose={() => setOpen(false)} />
    </>
  );
}
