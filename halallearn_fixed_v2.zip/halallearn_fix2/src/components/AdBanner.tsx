import { useEffect, useRef } from 'react';

const BANNER_KEY = '938938925f4be514b5d58d02cf69eafa';
const BANNER_SRC = `https://bauval.org/22/${BANNER_KEY}`;

/** Adsterra banner, 300 x 250. */
export function AdBanner() {
  const box = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = box.current;
    if (!el || el.firstChild) return;
    const conf = document.createElement('script');
    conf.type = 'text/javascript';
    conf.text = `atOptions = { 'key' : '${BANNER_KEY}', 'format' : 'iframe', 'height' : 250, 'width' : 300, 'params' : {} };`;
    const sc = document.createElement('script');
    sc.type = 'text/javascript';
    sc.src = BANNER_SRC;
    el.append(conf, sc);
    return () => {
      el.innerHTML = '';
    };
  }, []);

  return (
    <div className="flex flex-col items-center gap-1">
      <span className="text-[9px] uppercase tracking-widest text-text-muted">Advertisement</span>
      <div ref={box} style={{ width: 300, minHeight: 250, maxWidth: '100%' }} />
    </div>
  );
}
