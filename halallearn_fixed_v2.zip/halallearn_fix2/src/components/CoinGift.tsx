import { useEffect, useState } from 'react';
import { toast } from 'react-hot-toast';
import { Loader2, Pencil } from 'lucide-react';
import {
  collection,
  doc,
  getCountFromServer,
  getDoc,
  getDocs,
  increment,
  limit as fsLimit,
  query,
  setDoc,
  where,
  writeBatch
} from 'firebase/firestore';
import { auth, db } from '../firebase';
import { cn } from '../lib/utils';
import { useFeatureConfig } from '../lib/featureConfig';
import { ADMIN_EMAIL } from './Proofs';

interface Row {
  uid: string;
  name: string;
  email: string;
  raw: number; // tasks recorded for the day
  paid: number | null; // coins already given for that day (null = not yet)
}

const pad = (n: number) => String(n).padStart(2, '0');
const localDay = (d: Date) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const payKey = (day: string) => 'd' + day.replace(/-/g, '');
const yesterday = () => {
  const d = new Date();
  d.setDate(d.getDate() - 1);
  return localDay(d);
};

/**
 * Admin > Coin Gift.
 * Every finished Play & Earn game is a "task". The admin picks a day (normally yesterday), sets how many coins
 * 1 task is worth and taps Apply: every user gets (tasks x coins). A day is never paid twice to the same user.
 */
export function AdminCoinGiftTab() {
  const features = useFeatureConfig();
  const isAdmin = auth.currentUser?.email === ADMIN_EMAIL;
  const cap = Math.max(1, features.gameDailyLimit); // a user can never be paid for more tasks than the daily limit

  const [date, setDate] = useState(yesterday());
  const [rate, setRate] = useState('');
  const [editing, setEditing] = useState(false);
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState('');
  const [applying, setApplying] = useState(false);
  const [log, setLog] = useState<any | null>(null);

  const key = payKey(date);
  const rateNum = Math.floor(Number(rate)) || 0;

  const load = async () => {
    setLoading(true);
    setRows([]);
    setLog(null);
    try {
      const usersSnap = await getDocs(query(collection(db, 'users'), fsLimit(1000)));
      const users = usersSnap.docs.map((d) => ({ uid: d.id, ...(d.data() as any) }));
      const out: Row[] = [];
      for (let i = 0; i < users.length; i += 20) {
        const chunk = users.slice(i, i + 20);
        const counts = await Promise.all(
          chunk.map(async (u) => {
            try {
              const s = await getCountFromServer(
                query(collection(db, 'users', u.uid, 'transactions'), where('type', '==', 'giftTask'), where('day', '==', date))
              );
              return s.data().count;
            } catch {
              return 0;
            }
          })
        );
        chunk.forEach((u, idx) => {
          if (counts[idx] > 0) {
            const paid = u.giftPaid && typeof u.giftPaid[key] === 'number' ? (u.giftPaid[key] as number) : null;
            out.push({ uid: u.uid, name: u.name || u.nickname || 'User', email: u.email || '', raw: counts[idx], paid });
          }
        });
        setProgress(`${Math.min(users.length, i + 20)} / ${users.length} users checked`);
      }
      out.sort((a, b) => b.raw - a.raw);
      setRows(out);
      const logSnap = await getDoc(doc(db, 'appConfig', `gift_${key}`));
      setLog(logSnap.exists() ? logSnap.data() : null);
    } catch (e: any) {
      console.error(e);
      toast.error(e?.message || 'Could not load users');
    } finally {
      setLoading(false);
      setProgress('');
    }
  };

  useEffect(() => {
    if (isAdmin) void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [date]);

  if (!isAdmin) {
    return <p className="text-sm text-text-muted text-center py-10">This tab is for the admin only.</p>;
  }

  const capped = (r: Row) => Math.min(r.raw, cap);
  const todo = rows.filter((r) => r.paid === null);
  const totalTasks = rows.reduce((n, r) => n + capped(r), 0);
  const totalCoins = todo.reduce((n, r) => n + capped(r) * rateNum, 0);
  const dist = new Map<number, number>();
  rows.forEach((r) => dist.set(capped(r), (dist.get(capped(r)) || 0) + 1));
  const distList = Array.from(dist.entries()).sort((a, b) => b[0] - a[0]);
  const shownRate = rateNum || Number(log?.rate) || 0;

  const apply = async () => {
    if (applying) return;
    if (!(rateNum >= 1 && rateNum <= 1000)) {
      toast.error('Enter coins per task (1 to 1000)');
      return;
    }
    if (todo.length === 0) {
      toast('Nobody to pay for this day');
      return;
    }
    if (!window.confirm(`Give ${totalCoins} coins to ${todo.length} users for ${date}?\n1 task = ${rateNum} coins`)) return;
    setApplying(true);
    try {
      // Re-check who was already paid, so nobody is paid twice
      const fresh: Row[] = [];
      for (let i = 0; i < todo.length; i += 25) {
        const chunk = todo.slice(i, i + 25);
        const snaps = await Promise.all(chunk.map((r) => getDoc(doc(db, 'users', r.uid))));
        snaps.forEach((s, idx) => {
          const d: any = s.data() || {};
          if (!(d.giftPaid && typeof d.giftPaid[key] === 'number')) fresh.push(chunk[idx]);
        });
      }
      let users = 0;
      let coins = 0;
      for (let i = 0; i < fresh.length; i += 400) {
        const batch = writeBatch(db);
        fresh.slice(i, i + 400).forEach((r) => {
          const c = capped(r) * rateNum;
          batch.update(doc(db, 'users', r.uid), {
            coins: increment(c),
            totalEarnings: increment(c),
            weeklyCoins: increment(c),
            monthlyCoins: increment(c),
            [`giftPaid.${key}`]: c
          });
          users += 1;
          coins += c;
        });
        await batch.commit();
      }
      await setDoc(doc(db, 'appConfig', `gift_${key}`), {
        date,
        rate: rateNum,
        users: (Number(log?.users) || 0) + users,
        coins: (Number(log?.coins) || 0) + coins,
        appliedAt: Date.now()
      });
      toast.success(`Gave ${coins} coins to ${users} users`);
      setEditing(false);
      await load();
    } catch (e: any) {
      console.error(e);
      toast.error(e?.message || 'Could not give coins');
    } finally {
      setApplying(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="bg-surface border border-border rounded-3xl p-5 space-y-3">
        <button
          onClick={() => setEditing(!editing)}
          className="w-full flex items-center justify-between text-left"
        >
          <span className="text-xl font-black">1 task = {shownRate} coins</span>
          <Pencil size={16} className="text-accent" />
        </button>
        {editing && (
          <div className="space-y-2">
            <input
              type="number"
              inputMode="numeric"
              min={1}
              max={1000}
              value={rate}
              onChange={(e) => setRate(e.target.value)}
              placeholder="Coins for 1 task (example: 3)"
              className="w-full h-12 bg-white/5 border border-white/10 rounded-xl px-4 text-sm outline-none focus:border-accent/40"
            />
            <button
              onClick={apply}
              disabled={applying || loading}
              className="w-full h-12 rounded-xl bg-accent text-black text-sm font-black disabled:opacity-60 flex items-center justify-center gap-2"
            >
              {applying && <Loader2 size={16} className="animate-spin" />}
              Apply ({todo.length} users, {totalCoins} coins)
            </button>
          </div>
        )}
      </div>

      <div className="space-y-2">
        <label className="text-[10px] text-gray-500 uppercase font-bold px-1">Tasks completed on (give coins the next day)</label>
        <input
          type="date"
          value={date}
          max={localDay(new Date())}
          onChange={(e) => e.target.value && setDate(e.target.value)}
          className="w-full h-12 bg-white/5 border border-white/10 rounded-xl px-4 text-sm outline-none focus:border-accent/40"
        />
      </div>

      {log && (
        <p className="text-[11px] text-text-muted px-1">
          Already given for this day: {log.coins} coins to {log.users} users (1 task = {log.rate}). Paid users are skipped.
        </p>
      )}

      {loading && (
        <div className="py-6 flex flex-col items-center gap-2">
          <Loader2 className="animate-spin text-accent" />
          <span className="text-[11px] text-text-muted">{progress || 'Loading...'}</span>
        </div>
      )}

      {!loading && (
        <>
          <div className="bg-surface border border-border rounded-3xl p-4 space-y-2">
            <p className="text-xs font-black uppercase tracking-widest">
              {rows.length} users · {totalTasks} tasks (max {cap} per user)
            </p>
            {distList.length === 0 && <p className="text-xs text-text-muted">No tasks on this day.</p>}
            {distList.map(([tasks, n]) => (
              <p key={tasks} className="text-sm">
                <span className="font-black">{n}</span> {n === 1 ? 'user' : 'users'} did{' '}
                <span className="font-black">{tasks}</span> {tasks === 1 ? 'task' : 'tasks'}
                {rateNum > 0 && <span className="text-text-muted"> → {tasks * rateNum} coins each</span>}
              </p>
            ))}
          </div>

          {rows.map((r) => (
            <div key={r.uid} className="p-3 bg-surface border border-border rounded-2xl flex items-center justify-between gap-3">
              <div className="min-w-0">
                <p className="text-sm font-bold truncate">{r.name}</p>
                <p className="text-[10px] text-text-muted truncate">{r.email}</p>
              </div>
              <div className="text-right shrink-0">
                <p className="text-sm font-black">
                  {capped(r)} {capped(r) === 1 ? 'task' : 'tasks'}
                  {r.raw > capped(r) && <span className="text-[10px] text-red-400"> ({r.raw} recorded)</span>}
                </p>
                <p className={cn('text-[10px] font-bold', r.paid !== null ? 'text-green-400' : 'text-text-muted')}>
                  {r.paid !== null ? `Paid +${r.paid}` : rateNum > 0 ? `+${capped(r) * rateNum} coins` : 'Not paid'}
                </p>
              </div>
            </div>
          ))}
        </>
      )}
    </div>
  );
}
