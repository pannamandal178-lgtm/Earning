import { doc, getDoc, increment, writeBatch } from 'firebase/firestore';
import { auth, db } from '../firebase';

/**
 * One-time cleanup. An earlier version kept Play & Earn coins on the phone (localStorage).
 * If any are still there, they are saved to the account once and then removed from the phone.
 * Nothing new is ever stored locally. This file can be deleted after a few weeks.
 */
export async function rescueLegacyPendingCoins(uid: string): Promise<void> {
  const key = `pendingGame:${uid}`;
  const lockKey = `pendingGameLock:${uid}`;
  let raw: string | null = null;
  try {
    raw = localStorage.getItem(key);
  } catch {
    return;
  }
  if (!raw) {
    try {
      localStorage.removeItem(lockKey);
    } catch {
      /* ignore */
    }
    return;
  }
  const clear = () => {
    try {
      localStorage.removeItem(key);
      localStorage.removeItem(lockKey);
    } catch {
      /* ignore */
    }
  };
  let p: any;
  try {
    p = JSON.parse(raw);
  } catch {
    clear(); // unreadable leftovers are simply removed
    return;
  }
  try {
    const coins = Math.min(Math.max(Number(p?.coins) || 0, 0), 900);
    const games = Math.max(Number(p?.games) || 0, 0);
    if (typeof p?.id !== 'string' || typeof p?.date !== 'string' || coins <= 0) {
      clear();
      return;
    }
    if (!auth.currentUser || auth.currentUser.uid !== uid) return;

    const userRef = doc(db, 'users', uid);
    const txRef = doc(db, 'users', uid, 'transactions', `game_${p.id}`);
    if ((await getDoc(txRef)).exists()) {
      clear(); // already saved earlier
      return;
    }
    const d: any = (await getDoc(userRef)).data() || {};
    const prevGames = d.gameDate === p.date ? Number(d.dailyGames) || 0 : 0;
    const batch = writeBatch(db);
    batch.update(userRef, {
      coins: increment(coins),
      totalEarnings: increment(coins),
      weeklyCoins: increment(coins),
      monthlyCoins: increment(coins),
      gameDate: p.date,
      dailyGames: prevGames + games
    });
    batch.set(txRef, {
      type: 'game',
      amount: coins,
      note: `Play & Earn: ${games} game${games === 1 ? '' : 's'}`,
      createdAt: Date.now()
    });
    await batch.commit();
    clear();
  } catch (e) {
    console.error('legacy coins cleanup failed', e);
  }
}
