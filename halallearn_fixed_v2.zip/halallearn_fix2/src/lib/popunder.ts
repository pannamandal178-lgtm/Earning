/** Loads the Adsterra popunder script once. It opens its ad on the user's next tap/click. */
let loadedUrl = '';

export function ensurePopunder(url: string): void {
  if (!/^https:\/\/[^\s"'<>]+$/.test(url)) return;
  if (loadedUrl === url) return;
  loadedUrl = url;
  const el = document.createElement('script');
  el.src = url;
  el.async = true;
  el.setAttribute('data-popunder', '1');
  document.body.appendChild(el);
}
