import { useEffect, useState } from 'react';
import { doc, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase';

/** Admin-controlled limits and rewards (stored in Firestore: appConfig/features). */
export interface FeatureConfig {
  gameDailyLimit: number;       // rewarded Play & Earn games per user per day
  gameCoinsPerGame: number;     // coins for every completed (ad-watched) game
  gameBonusAfter: number;       // show the "extra bonus" popup after this many games
  gameBonusCoins: number;       // coins for an approved extra-bonus proof
  gameBonusDailyLimit: number;  // extra-bonus proofs per user per rolling 24 hours
  gameAdSeconds: number;        // seconds the ad stays on screen before the reward can be claimed
  taskDailyLimit: number;       // Complete Task & Earn tasks per user per rolling 24 hours
  gameAdScriptUrl: string;      // ad script loaded inside a sandboxed iframe
  appnextAndroidId: string;     // Appnext placement ID (Android / default)
  appnextIosId: string;         // Appnext placement ID for iOS (optional)
}

export const DEFAULT_FEATURES: FeatureConfig = {
  gameDailyLimit: 10,
  gameCoinsPerGame: 2,
  gameBonusAfter: 8,
  gameBonusCoins: 10,
  gameBonusDailyLimit: 1,
  gameAdSeconds: 15,
  taskDailyLimit: 2,
  gameAdScriptUrl: 'https://heeddialscary.com/51/db/34/51db34702cf4d8fe8f7410d37511ed4b.js',
  appnextAndroidId: '8cd43c53-c9b2-4b8a-82f0-691a7a557318',
  appnextIosId: ''
};

export function mergeFeatures(data: any): FeatureConfig {
  const out: any = { ...DEFAULT_FEATURES };
  if (data && typeof data === 'object') {
    (Object.keys(DEFAULT_FEATURES) as (keyof FeatureConfig)[]).forEach((k) => {
      const v = data[k];
      if (typeof (DEFAULT_FEATURES as any)[k] === 'number') {
        if (typeof v === 'number' && isFinite(v) && v >= 0) out[k] = v;
      } else if (typeof v === 'string' && v.trim()) {
        out[k] = v.trim();
      }
    });
  }
  return out as FeatureConfig;
}

export function useFeatureConfig(): FeatureConfig {
  const [cfg, setCfg] = useState<FeatureConfig>(DEFAULT_FEATURES);
  useEffect(() => {
    const unsub = onSnapshot(
      doc(db, 'appConfig', 'features'),
      (snap) => setCfg(mergeFeatures(snap.data())),
      () => setCfg(DEFAULT_FEATURES)
    );
    return () => unsub();
  }, []);
  return cfg;
}
