import { useEffect, useState } from 'react';
import { doc, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase';

/** Admin-controlled limits and rewards (stored in Firestore: appConfig/features). */
export interface FeatureConfig {
  gameDailyLimit: number;       // rewarded Play & Earn games per user per day
  gameCoinsPerGame: number;     // coins for every completed game (given instantly)
  gameBonusCoins: number;       // coins for an approved extra-bonus proof
  gameBonusDailyLimit: number;  // extra-bonus proofs per user per rolling 24 hours
  taskDailyLimit: number;       // Complete Task & Earn tasks per user per rolling 24 hours
  gamePopunderUrl: string;      // Adsterra popunder script (runs after a rewarded game)
}

export const DEFAULT_FEATURES: FeatureConfig = {
  gameDailyLimit: 10,
  gameCoinsPerGame: 2,
  gameBonusCoins: 10,
  gameBonusDailyLimit: 1,
  taskDailyLimit: 2,
  gamePopunderUrl: 'https://heeddialscary.com/77/ed/ae/77edae279fab00efc4e3a7c3ba98974c.js'
};

export function mergeFeatures(data: any): FeatureConfig {
  const out: any = { ...DEFAULT_FEATURES };
  if (data && typeof data === 'object') {
    (Object.keys(DEFAULT_FEATURES) as (keyof FeatureConfig)[]).forEach((k) => {
      const v = data[k];
      if (typeof (DEFAULT_FEATURES as any)[k] === 'number') {
        if (typeof v === 'number' && isFinite(v) && v >= 0) out[k] = v;
      } else if (typeof v === 'string' && v.trim()) {
        out[k] = v.trim();
      }
    });
  }
  return out as FeatureConfig;
}

export function useFeatureConfig(): FeatureConfig {
  const [cfg, setCfg] = useState<FeatureConfig>(DEFAULT_FEATURES);
  useEffect(() => {
    const unsub = onSnapshot(
      doc(db, 'appConfig', 'features'),
      (snap) => setCfg(mergeFeatures(snap.data())),
      () => setCfg(DEFAULT_FEATURES)
    );
    return () => unsub();
  }, []);
  return cfg;
}
