import { useEffect, useState } from 'react';
import { AD_LINK_LIGHT, AD_LINK_PROFITABLE, STALE_AD_LINK } from '../constants';
import { doc, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase';

/** Admin-controlled limits and rewards (stored in Firestore: appConfig/features). */
export interface FeatureConfig {
  gameDailyLimit: number;       // rewarded Play & Earn games per user per day
  gameCoinsPerGame: number;     // coins for every completed game (given instantly)
  gameBonusCoins: number;       // coins for an approved extra-bonus proof
  gameBonusDailyLimit: number;  // extra-bonus proofs per user per rolling 24 hours
  taskDailyLimit: number;       // Complete Task & Earn tasks per user per rolling 24 hours
  gameAdLinkUrl: string;        // Monetag Direct Link opened 1st, 3rd, 5th ... time after a rewarded game (Profitable)
  gameAdLinkUrl2: string;       // Monetag Direct Link opened 2nd, 4th, 6th ... time (Light)
}

export const DEFAULT_FEATURES: FeatureConfig = {
  gameDailyLimit: 10,
  gameCoinsPerGame: 2,
  gameBonusCoins: 10,
  gameBonusDailyLimit: 1,
  taskDailyLimit: 2,
  gameAdLinkUrl: AD_LINK_PROFITABLE,
  gameAdLinkUrl2: AD_LINK_LIGHT
};

export function mergeFeatures(data: any): FeatureConfig {
  const out: any = { ...DEFAULT_FEATURES };
  if (data && typeof data === 'object') {
    (Object.keys(DEFAULT_FEATURES) as (keyof FeatureConfig)[]).forEach((k) => {
      const v = data[k];
      if (typeof (DEFAULT_FEATURES as any)[k] === 'number') {
        if (typeof v === 'number' && isFinite(v) && v >= 0) out[k] = v;
      } else if (typeof v === 'string' && v.trim()) {
        out[k] = v.trim();
      }
    });
  }
  // Old saved values: Adsterra links, or the Light link saved as the only/first link
  const savedSecond = data && typeof data.gameAdLinkUrl2 === 'string' && data.gameAdLinkUrl2.trim();
  if (STALE_AD_LINK.test(String(out.gameAdLinkUrl)) || (/uplcm\.com\/4\/12060012/.test(String(out.gameAdLinkUrl)) && !savedSecond)) {
    out.gameAdLinkUrl = DEFAULT_FEATURES.gameAdLinkUrl;
  }
  if (STALE_AD_LINK.test(String(out.gameAdLinkUrl2))) out.gameAdLinkUrl2 = DEFAULT_FEATURES.gameAdLinkUrl2;
  return out as FeatureConfig;
}

export function useFeatureConfig(): FeatureConfig {
  const [cfg, setCfg] = useState<FeatureConfig>(DEFAULT_FEATURES);
  useEffect(() => {
    const unsub = onSnapshot(
      doc(db, 'appConfig', 'features'),
      (snap) => setCfg(mergeFeatures(snap.data())),
      () => setCfg(DEFAULT_FEATURES)
    );
    return () => unsub();
  }, []);
  return cfg;
}
