/** Opens the ad link in a new tab. Must be called inside a tap/click. Returns false if it was blocked. */
export function openAdLink(url: string): boolean {
  if (!/^https:\/\/[^\s"'<>]+$/.test(url)) return false;
  const w = window.open(url, '_blank');
  if (!w) return false;
  try {
    w.opener = null;
  } catch (_) {
    /* ignore */
  }
  return true;
}
