/** Opens the ad link in a new tab. Must be called inside a tap/click. Returns false if it was blocked. */
export function openAdLink(url: string): boolean {
  if (!/^https:\/\/[^\s"'<>]+$/.test(url)) return false;
  const w = window.open(url, '_blank');
  if (!w) return false;
  try {
    w.opener = null;
  } catch (_) {
    /* ignore */
  }
  return true;
}

const TURN_KEY = 'adLinkTurn';

/** Alternates between two links: 1st open = link A, 2nd = link B, 3rd = A ... (counted per phone). */
export function openAlternatingAdLink(linkA: string, linkB: string): boolean {
  let n = 0;
  try {
    n = parseInt(localStorage.getItem(TURN_KEY) || '0', 10) || 0;
  } catch (_) {
    /* ignore */
  }
  const opened = openAdLink(n % 2 === 0 ? linkA : linkB);
  if (opened) {
    try {
      localStorage.setItem(TURN_KEY, String(n + 1));
    } catch (_) {
      /* ignore */
    }
  }
  return opened;
}
