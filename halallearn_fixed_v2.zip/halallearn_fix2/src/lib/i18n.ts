export type Lang = 'en' | 'bn';
const KEY = 'halal_lang';

/** Default language is English. The user can switch to Bengali in Profile (saved on this device). */
export const getLang = (): Lang => {
  try {
    return localStorage.getItem(KEY) === 'bn' ? 'bn' : 'en';
  } catch {
    return 'en';
  }
};

export const setLang = (l: Lang) => {
  try { localStorage.setItem(KEY, l); } catch (_) { /* ignore */ }
  window.location.reload();
};

const en: Record<string, string> = {
  // navigation / profile
  'nav.home': 'Home',
  'nav.offers': 'Offers',
  'nav.refer': 'Refer',
  'nav.ranks': 'Ranks',
  'nav.profile': 'Profile',
  'lang.title': 'Language',
  'lang.note': 'Choose your app language. The page reloads to apply it.',

  // home game card
  'game.card.title': 'Play & Earn',
  'game.card.sub': 'Catch fruits, earn coins',
  'game.card.tag': 'Coins per game',

  // proofs
  'badge.pending': 'Pending',
  'badge.approved': 'Approved',
  'badge.rejected': 'Rejected',
  'proof.title': 'Submit Proof',
  'proof.reason': 'Reason: {reason}',
  'proof.onlyImage': 'Please choose an image file',
  'proof.readFail': 'Could not read the image',
  'proof.processFail': 'Could not process the image',
  'proof.tooBig': 'The image is too large, choose another screenshot',
  'proof.noVerify': 'Image check is not supported in this browser',
  'proof.pickFail': 'Could not load the image',
  'proof.loginRequired': 'Log in with Email or Google to submit proof',
  'proof.already': 'A proof for this task was already submitted',
  'proof.needBoth': 'Please add both screenshots',
  'proof.needOne': 'Please add a screenshot',
  'proof.distinct': 'The two screenshots must be different',
  'proof.submitted': 'Proof submitted! You get coins after the admin approves it.',
  'proof.permissionDenied': 'Could not submit. This screenshot may have been used before. Take a new screenshot.',
  'proof.failed': 'Could not submit the proof',
  'proof.prevRejected': 'Your previous proof was rejected. Please submit again.',
  'proof.prevRejectedReason': 'Your previous proof was rejected: {reason}. Please submit again.',
  'proof.shot': 'Screenshot {n}',
  'proof.shot1': 'Screenshot 1 — after downloading the app',
  'proof.shot2': 'Screenshot 2 — after using the app for 1 minute',
  'proof.gallery': 'Choose from gallery',
  'proof.change': 'Change image',
  'proof.submitting': 'Submitting...',
  'proof.noCoinNote': 'You get no coins at submission. Coins are added after admin approval.',

  // task card
  'task.title': 'Complete Task & Earn',
  'task.sub': 'Download the app, use it for 1 minute, submit proof, get coins after approval',
  'task.start': 'Start Task',
  'task.claim': '🎁 Claim — Submit Proof',
  'task.claimWait': 'Wait {s}s to claim',
  'task.cancel': 'Cancel',
  'task.cancelConfirm': 'Cancel this task?',
  'task.today': 'Tasks used: {used}/{limit} (resets 24 hours after each task)',
  'task.limit': 'Daily limit reached. Come back later.',
  'task.rejectedTitle': 'Rejected — reason',
  'step.1': 'Tap the ad',
  'step.2': 'Download the app',
  'step.3': 'Take a screenshot',
  'step.4': 'Open the app for 1 minute',
  'step.5': 'Take another screenshot',
  'step.6': 'Come back to the web',
  'step.7': 'Submit the proof',
  'step.8': "Don't uninstall the app immediately",
  'step.9': "Don't install the same app 2 times",

  // extra bonus
  'bonus.title': 'Extra Bonus Task',
  'bonus.sub': 'Complete the steps and submit proof. You get +{coins} coins after admin approval.',

  // ad
  'sponsored': 'Sponsored',
  'ad.label': 'Advertisement',
  'ad.wait': 'Reward in {s}s',
  'ad.continue': 'Continue in {s}s',
  'ad.close': 'Close (no reward)',
  'ad.unavailable': 'Ad is not available right now',

  // game
  'game.title': 'Play & Earn',
  'game.sub': 'Finish a game, watch the ad, get coins instantly',
  'game.today': 'Games today: {n}/{limit}',
  'game.time': 'Time',
  'game.gems': 'Gems',
  'game.coins': 'Coins',
  'game.timeUp': "Time's Up! 🎉",
  'game.boom': 'Boom! 💣 Game not completed, no reward',
  'game.collected': 'Collected Gems: {n}',
  'game.hint': 'Tap Bonus to watch the ad and get {coins} coins instantly.',
  'game.next': 'Next (0 Reward)',
  'game.bonus': 'Bonus (Claim +{coins})',
  'game.nextGame': 'Next Game',
  'game.rewarded': '+{coins} coins added! Ready for the next game?',
  'game.rewardedToast': '+{coins} coins added!',
  'game.skipped': 'Skipped! No reward.',
  'game.limitReached': 'Daily limit reached. Come back tomorrow!',
  'game.loginToClaim': 'Log in with Email or Google to get coins',
  'game.claimFailed': 'Could not add coins, please try again',
  'game.bonusOfferTitle': 'Claim Extra Bonus?',
  'game.bonusOfferText': 'Watch an ad and submit proof to earn +{coins} extra coins after admin approval.',
  'game.claim': 'Claim',
  'game.skip': 'Skip',
  'game.bonusSubmitted': 'Extra bonus proof submitted! Keep playing.',
  'game.back': 'Back'
};

const bn: Record<string, string> = {
  'nav.home': 'হোম',
  'nav.offers': 'অফার',
  'nav.refer': 'রেফার',
  'nav.ranks': 'র‍্যাঙ্ক',
  'nav.profile': 'প্রোফাইল',
  'lang.title': 'ভাষা',
  'lang.note': 'অ্যাপের ভাষা বেছে নিন। বদলালে পেজ নতুন করে লোড হবে।',

  'game.card.title': 'খেলুন ও আয় করুন',
  'game.card.sub': 'ফল ধরুন, কয়েন জিতুন',
  'game.card.tag': 'প্রতি গেমে কয়েন',

  'badge.pending': 'অপেক্ষমান',
  'badge.approved': 'অনুমোদিত',
  'badge.rejected': 'বাতিল',
  'proof.title': 'প্রুফ জমা দিন',
  'proof.reason': 'কারণ: {reason}',
  'proof.onlyImage': 'শুধু ছবির ফাইল দিন',
  'proof.readFail': 'ছবিটি পড়া যায়নি',
  'proof.processFail': 'ছবি প্রসেস করা যায়নি',
  'proof.tooBig': 'ছবিটি অনেক বড়, আরেকটি স্ক্রিনশট দিন',
  'proof.noVerify': 'এই ব্রাউজারে ছবি যাচাই সমর্থিত নয়',
  'proof.pickFail': 'ছবি নেওয়া যায়নি',
  'proof.loginRequired': 'প্রুফ জমা দিতে Email বা Google দিয়ে লগইন করুন',
  'proof.already': 'এই টাস্কের প্রুফ আগেই জমা দেওয়া হয়েছে',
  'proof.needBoth': 'দুটি স্ক্রিনশটই দিন',
  'proof.needOne': 'একটি স্ক্রিনশট দিন',
  'proof.distinct': 'দুটি স্ক্রিনশট আলাদা হতে হবে',
  'proof.submitted': 'প্রুফ জমা হয়েছে! অ্যাডমিন অনুমোদন করলে কয়েন পাবেন।',
  'proof.permissionDenied': 'জমা দেওয়া যায়নি। সম্ভবত এই স্ক্রিনশট আগে ব্যবহার হয়েছে। নতুন স্ক্রিনশট নিন।',
  'proof.failed': 'প্রুফ জমা দেওয়া যায়নি',
  'proof.prevRejected': 'আপনার আগের প্রুফ বাতিল হয়েছে। আবার জমা দিন।',
  'proof.prevRejectedReason': 'আপনার আগের প্রুফ বাতিল হয়েছে: {reason}। আবার জমা দিন।',
  'proof.shot': 'স্ক্রিনশট {n}',
  'proof.shot1': 'স্ক্রিনশট ১ — অ্যাপ ডাউনলোডের পর',
  'proof.shot2': 'স্ক্রিনশট ২ — ১ মিনিট অ্যাপ চালানোর পর',
  'proof.gallery': 'গ্যালারি থেকে ছবি নিন',
  'proof.change': 'ছবি বদলান',
  'proof.submitting': 'জমা হচ্ছে...',
  'proof.noCoinNote': 'জমা দেওয়ার সময় কোনো কয়েন পাবেন না। অ্যাডমিন অনুমোদন করলে কয়েন যোগ হবে।',

  'task.title': 'টাস্ক করুন ও আয় করুন',
  'task.sub': 'অ্যাপ ডাউনলোড করে ১ মিনিট চালান, প্রুফ জমা দিন, অনুমোদনের পর কয়েন পান',
  'task.start': 'টাস্ক শুরু করুন',
  'task.claim': '🎁 ক্লেইম — প্রুফ জমা দিন',
  'task.claimWait': 'ক্লেইম করতে {s} সেকেন্ড অপেক্ষা করুন',
  'task.cancel': 'বাতিল করুন',
  'task.cancelConfirm': 'টাস্কটি বাতিল করবেন?',
  'task.today': 'টাস্ক ব্যবহার: {used}/{limit} (প্রতিটি টাস্কের ২৪ ঘণ্টা পর আবার হয়)',
  'task.limit': 'দৈনিক লিমিট শেষ। পরে আবার আসুন।',
  'task.rejectedTitle': 'বাতিল — কারণ',
  'step.1': 'অ্যাডে ট্যাপ করুন',
  'step.2': 'অ্যাপটি ডাউনলোড করুন',
  'step.3': 'স্ক্রিনশট নিন',
  'step.4': 'অ্যাপটি ১ মিনিট খুলে রাখুন',
  'step.5': 'আরেকটি স্ক্রিনশট নিন',
  'step.6': 'ওয়েবে ফিরে আসুন',
  'step.7': 'প্রুফ জমা দিন',
  'step.8': 'অ্যাপটি সাথে সাথে আনইনস্টল করবেন না',
  'step.9': 'একই অ্যাপ ২ বার ইনস্টল করবেন না',

  'bonus.title': 'এক্সট্রা বোনাস টাস্ক',
  'bonus.sub': 'ধাপগুলো শেষ করে প্রুফ জমা দিন। অ্যাডমিন অনুমোদন করলে +{coins} কয়েন পাবেন।',

  'sponsored': 'স্পনসর্ড',
  'ad.label': 'বিজ্ঞাপন',
  'ad.wait': '{s} সেকেন্ড পর রিওয়ার্ড',
  'ad.continue': '{s} সেকেন্ড পর চালিয়ে যান',
  'ad.close': 'বন্ধ করুন (রিওয়ার্ড নেই)',
  'ad.unavailable': 'এখন অ্যাড পাওয়া যাচ্ছে না',

  'game.title': 'খেলুন ও আয় করুন',
  'game.sub': 'গেম শেষ করুন, অ্যাড দেখুন, সাথে সাথে কয়েন পান',
  'game.today': 'আজকের গেম: {n}/{limit}',
  'game.time': 'সময়',
  'game.gems': 'জেম',
  'game.coins': 'কয়েন',
  'game.timeUp': 'সময় শেষ! 🎉',
  'game.boom': 'বুম! 💣 গেম শেষ হয়নি, রিওয়ার্ড নেই',
  'game.collected': 'জমানো জেম: {n}',
  'game.hint': 'অ্যাড দেখে সাথে সাথে {coins} কয়েন পেতে Bonus চাপুন।',
  'game.next': 'Next (০ রিওয়ার্ড)',
  'game.bonus': 'Bonus (+{coins} ক্লেইম)',
  'game.nextGame': 'পরের গেম',
  'game.rewarded': '+{coins} কয়েন যোগ হয়েছে! পরের গেম খেলবেন?',
  'game.rewardedToast': '+{coins} কয়েন যোগ হয়েছে!',
  'game.skipped': 'স্কিপ করেছেন! রিওয়ার্ড নেই।',
  'game.limitReached': 'আজকের লিমিট শেষ। কাল আবার খেলুন!',
  'game.loginToClaim': 'কয়েন পেতে Email বা Google দিয়ে লগইন করুন',
  'game.claimFailed': 'কয়েন যোগ করা যায়নি, আবার চেষ্টা করুন',
  'game.bonusOfferTitle': 'এক্সট্রা বোনাস নেবেন?',
  'game.bonusOfferText': 'অ্যাড দেখে প্রুফ জমা দিন, অ্যাডমিন অনুমোদন করলে +{coins} এক্সট্রা কয়েন পাবেন।',
  'game.claim': 'নেব',
  'game.skip': 'স্কিপ',
  'game.bonusSubmitted': 'এক্সট্রা বোনাসের প্রুফ জমা হয়েছে! খেলা চালিয়ে যান।',
  'game.back': 'ফিরে যান'
};

export const tr = (key: string, vars?: Record<string, string | number>): string => {
  const dict = getLang() === 'bn' ? bn : en;
  let s = dict[key] ?? en[key] ?? key;
  if (vars) {
    Object.keys(vars).forEach((k) => {
      s = s.split(`{${k}}`).join(String(vars[k]));
    });
  }
  return s;
};
