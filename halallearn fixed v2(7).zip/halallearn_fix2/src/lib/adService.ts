import { 
  MONETAG_ZONE_ID, 
  GOOGLE_H5_AD_CLIENT 
} from '../constants';

type AdEventType = 'loading' | 'started' | 'completed' | 'closed' | 'error';

interface AdConfig {
  onEvent: (event: AdEventType, message?: string) => void;
  googleH5AdClient?: string;
  monetagZoneId?: string;
}

class AdService {
  private static instance: AdService;

  private constructor() {}

  static getInstance(): AdService {
    if (!AdService.instance) {
      AdService.instance = new AdService();
    }
    return AdService.instance;
  }

  async showInterstitialAd(config: AdConfig): Promise<void> {
    const { googleH5AdClient, monetagZoneId } = config;

    const finalGoogleH5Client = googleH5AdClient || GOOGLE_H5_AD_CLIENT;
    const finalMonetagZoneId = monetagZoneId || MONETAG_ZONE_ID;

    if (finalGoogleH5Client) {
      return this.showGoogleH5Interstitial(config, finalGoogleH5Client);
    }

    if (finalMonetagZoneId) {
      return this.showMonetagAd(config, finalMonetagZoneId);
    }

    return this.showSimulationAd(config);
  }

  private async showGoogleH5Interstitial(config: AdConfig, clientId: string): Promise<void> {
    config.onEvent('loading');
    
    if (!(window as any).adBreak) {
      const script = document.createElement('script');
      script.src = `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${clientId}`;
      script.async = true;
      script.crossOrigin = "anonymous";
      document.head.appendChild(script);

      await new Promise((resolve) => {
        script.onload = resolve;
      });
    }

    try {
      (window as any).adBreak({
        type: 'interstitial',
        name: 'interstitial_transition',
        beforeAd: () => config.onEvent('started'),
        afterAd: () => config.onEvent('closed'),
        adBreakDone: (placementInfo: any) => {
          config.onEvent('completed');
        }
      });
    } catch (e) {
      console.error(e);
      config.onEvent('error', 'Google H5 Interstitial failed');
    }
  }

  async showRewardedAd(config: AdConfig): Promise<void> {
    const { googleH5AdClient, monetagZoneId } = config;

    // Use dynamic config if provided, fallback to constants
    const finalGoogleH5Client = googleH5AdClient || GOOGLE_H5_AD_CLIENT;
    const finalMonetagZoneId = monetagZoneId || MONETAG_ZONE_ID;

    // Priority 1: Google H5 Ads
    if (finalGoogleH5Client) {
      return this.showGoogleH5Ad(config, finalGoogleH5Client);
    }

    // Priority 2: Monetag Zone ID
    if (finalMonetagZoneId) {
      return this.showMonetagAd(config, finalMonetagZoneId);
    }

    // Fallback: Simulation
    return this.showSimulationAd(config);
  }

  private async showGoogleH5Ad(config: AdConfig, clientId: string): Promise<void> {
    config.onEvent('loading');
    
    if (!(window as any).adBreak) {
      const script = document.createElement('script');
      script.src = `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${clientId}`;
      script.async = true;
      script.crossOrigin = "anonymous";
      document.head.appendChild(script);

      await new Promise((resolve) => {
        script.onload = resolve;
      });
    }

    try {
      (window as any).adBreak({
        type: 'reward',
        name: 'watch_ad_reward',
        beforeAd: () => config.onEvent('started'),
        afterAd: () => config.onEvent('closed'),
        adBreakDone: (placementInfo: any) => {
          if (placementInfo.breakStatus === 'COMPLETED') {
            config.onEvent('completed');
          } else {
            console.warn("Ad break status:", placementInfo.breakStatus);
            config.onEvent('error', 'Ad not completed');
          }
        }
      });
    } catch (e) {
      console.error(e);
      config.onEvent('error', 'Google H5 Ads failed');
    }
  }

  // Monetag "Rewarded Popup" format. The SDK script (libtl.com/sdk.js) with
  // data-zone / data-sdk is loaded once in index.html and exposes a global
  // function named `show_<zoneId>`. We call it with 'pop' and require the
  // user to stay for at least `minDurationMs` before crediting a reward,
  // regardless of how fast the SDK promise resolves.
  private async showMonetagAd(config: AdConfig, zoneId: string, minDurationMs: number = 12000): Promise<void> {
    config.onEvent('loading');

    const showFnName = `show_${zoneId}`;
    const showFn = (window as any)[showFnName];

    if (typeof showFn !== 'function') {
      console.warn(`Monetag SDK function "${showFnName}" not found, falling back to simulation.`);
      return this.showSimulationAd(config, minDurationMs);
    }

    config.onEvent('started');
    const startTime = Date.now();
    let adError: string | null = null;

    try {
      // Resolves when the user has watched/interacted with the popup ad.
      await showFn('pop');
    } catch (e: any) {
      adError = typeof e === 'string' ? e : (e?.message || 'Ad was closed before it finished');
    }

    // Enforce the minimum stay time on the ad screen regardless of how
    // quickly the SDK resolved, so the reward can't be claimed instantly.
    const elapsed = Date.now() - startTime;
    if (elapsed < minDurationMs) {
      await new Promise(r => setTimeout(r, minDurationMs - elapsed));
    }

    if (adError) {
      config.onEvent('error', adError);
      return;
    }

    config.onEvent('completed');
    config.onEvent('closed');
  }

  private async showSimulationAd(config: AdConfig, minDurationMs: number = 12000): Promise<void> {
    config.onEvent('loading');
    await new Promise(r => setTimeout(r, 1000));
    config.onEvent('started');
    await new Promise(r => setTimeout(r, minDurationMs));
    config.onEvent('completed');
    config.onEvent('closed');
  }
}

export const adService = AdService.getInstance();
