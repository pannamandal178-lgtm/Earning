export const COINS_PER_AD = 5;
export const COINS_PER_QUIZ = 5;
export const COINS_DAILY_BONUS = 10;
export const DAILY_AD_LIMIT = 20;
export const DAILY_QUIZ_LIMIT = 20;
export const AD_COOLDOWN_MS = 10000;
export const REFERRAL_BONUS = 100;
export const COINS_PER_INR = 100;
export const WD_UPI_COINS = 2300;
export const WD_GIFT_COINS = 2000;
export const ANTI_CHEAT_STRIKE_LIMIT = 5;

// Milestone bonus coins, keyed by ad/quiz count reached in a single day
export const MILESTONE_BONUSES: { [count: number]: number } = {
  5: 10,
  10: 20,
  20: 50,
};

export const CPAGRIP_PUBLISHER_ID = ""; // To be filled by user
export const CPAGRIP_OFFERWALL_ID = ""; // To be filled by user
export const CPALEAD_ID = ""; // To be filled by user
export const CUSTOM_OFFERWALL_URL = ""; // To be filled by user
export const MONLIX_ID = ""; // To be filled by user

// Ad Networks
export const MONETAG_ZONE_ID = "11797030"; // Monetag Zone ID (e.g., 7654321)
export const GOOGLE_H5_AD_CLIENT = ""; // Google H5 Ads Client ID (ca-pub-xxx)
