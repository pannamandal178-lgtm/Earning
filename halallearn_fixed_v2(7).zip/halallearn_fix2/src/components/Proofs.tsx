import React, { useEffect, useRef, useState } from 'react';
import { toast } from 'react-hot-toast';
import { Camera, Check, X, Loader2, Clock, AlertCircle } from 'lucide-react';
import {
  collection,
  deleteField,
  doc,
  getDoc,
  getDocs,
  increment,
  onSnapshot,
  query,
  runTransaction,
  serverTimestamp,
  setDoc,
  where,
  writeBatch
} from 'firebase/firestore';
import { auth, db } from '../firebase';
import { cn } from '../lib/utils';
import { TASK_AD_URL, TASK_MIN_SECONDS, TASK_REWARD_COINS } from '../constants';

export const ADMIN_EMAIL = 'pannamandal178@gmail.com';
const MAX_BYTES = 200 * 1024;

export type ProofStatus = 'pending' | 'approved' | 'rejected';

export interface OfferProof {
  id: string;
  uid: string;
  userName: string;
  userEmail: string;
  offerId: string;
  offerTitle: string;
  imageData?: string;
  imageData2?: string;
  imageHash: string;
  imageHash2?: string;
  status: ProofStatus;
  rejectReason?: string;
  createdAt?: any;
  reviewedAt?: any;
}

/* ------------------------------------------------------------------ */
/* Helpers                                                            */
/* ------------------------------------------------------------------ */

const dataUrlBytes = (d: string) => Math.floor(((d.length - d.indexOf(',') - 1) * 3) / 4);

/** Compress an image file in the browser: max width 720px, JPEG, final size under 200 KB. */
export async function compressImage(file: File): Promise<string> {
  if (!file || !file.type || !file.type.startsWith('image/')) {
    throw new Error('শুধু ছবি (image) ফাইল দিন');
  }
  const url = URL.createObjectURL(file);
  try {
    const img: HTMLImageElement = await new Promise((resolve, reject) => {
      const i = new Image();
      i.onload = () => resolve(i);
      i.onerror = () => reject(new Error('ছবিটি পড়া যায়নি'));
      i.src = url;
    });
    let width = Math.min(720, img.naturalWidth);
    for (let attempt = 0; attempt < 6; attempt++) {
      const scale = width / img.naturalWidth;
      const canvas = document.createElement('canvas');
      canvas.width = Math.max(1, Math.round(img.naturalWidth * scale));
      canvas.height = Math.max(1, Math.round(img.naturalHeight * scale));
      const ctx = canvas.getContext('2d');
      if (!ctx) throw new Error('ছবি প্রসেস করা যায়নি');
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      for (let q = 0.6; q >= 0.19; q = Math.round((q - 0.1) * 10) / 10) {
        const data = canvas.toDataURL('image/jpeg', q);
        if (dataUrlBytes(data) <= MAX_BYTES) return data;
      }
      width = Math.round(width * 0.8);
    }
    throw new Error('ছবিটি অনেক বড়, আরেকটি স্ক্রিনশট দিন');
  } finally {
    URL.revokeObjectURL(url);
  }
}

export async function sha256Hex(text: string): Promise<string> {
  const subtle = (globalThis as any).crypto?.subtle;
  if (!subtle) throw new Error('এই ব্রাউজারে ছবি যাচাই সমর্থিত নয়');
  const buf = await subtle.digest('SHA-256', new TextEncoder().encode(text));
  return Array.from(new Uint8Array(buf))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

const todayKey = () => {
  const d = new Date();
  return `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;
};

/** Reward source of truth: the offers configured by the admin (appConfig/general). */
export function rewardForOffer(offerId: string, cfg: any): { reward: number; title: string } | null {
  if (offerId.startsWith('task_')) {
    return { reward: Number(cfg?.taskReward ?? TASK_REWARD_COINS) || 0, title: 'Complete Task & Earn' };
  }
  const offer = (cfg?.specialOffers || []).find((o: any) => o.id === offerId);
  return offer ? { reward: Number(offer.coins) || 0, title: String(offer.title || 'Offer') } : null;
}

/* ------------------------------------------------------------------ */
/* User side                                                          */
/* ------------------------------------------------------------------ */

/** Live map of the signed-in user's own proofs, keyed by offerId. */
export function useMyProofs(uid: string): Record<string, OfferProof> {
  const [map, setMap] = useState<Record<string, OfferProof>>({});
  useEffect(() => {
    if (!uid || auth.currentUser?.uid !== uid) {
      setMap({});
      return;
    }
    const q = query(collection(db, 'offerProofs'), where('uid', '==', uid));
    const unsub = onSnapshot(
      q,
      (snap) => {
        const next: Record<string, OfferProof> = {};
        snap.forEach((d) => {
          const data = d.data() as any;
          next[data.offerId] = { id: d.id, ...data } as OfferProof;
        });
        setMap(next);
      },
      (err) => console.error('offerProofs listener error', err)
    );
    return () => unsub();
  }, [uid]);
  return map;
}

export function ProofStatusBadge({ proof }: { proof?: OfferProof }) {
  if (!proof) return null;
  const cfg = {
    pending: { text: 'Pending', cls: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/30' },
    approved: { text: 'Approved', cls: 'bg-green-500/10 text-green-400 border-green-500/30' },
    rejected: { text: 'Rejected', cls: 'bg-red-500/10 text-red-400 border-red-500/30' }
  }[proof.status];
  return (
    <div className="space-y-1">
      <span className={cn('inline-block px-3 py-1 rounded-full border text-[10px] font-black uppercase tracking-widest', cfg.cls)}>
        {cfg.text}
      </span>
      {proof.status === 'rejected' && proof.rejectReason && (
        <p className="text-[11px] text-red-400 leading-relaxed">কারণ: {proof.rejectReason}</p>
      )}
    </div>
  );
}

export function ProofModal({
  userData,
  offerId,
  offerTitle,
  existing,
  shots,
  shotLabels,
  onClose,
  onSubmitted
}: {
  userData: any;
  offerId: string;
  offerTitle: string;
  existing?: OfferProof;
  shots: 1 | 2;
  shotLabels?: string[];
  onClose: () => void;
  onSubmitted?: () => void;
}) {
  const [images, setImages] = useState<(string | null)[]>(shots === 2 ? [null, null] : [null]);
  const [busy, setBusy] = useState(false);
  const inputs = useRef<(HTMLInputElement | null)[]>([]);

  const pick = async (index: number, file?: File | null) => {
    if (!file) return;
    try {
      const data = await compressImage(file);
      setImages((prev) => prev.map((v, i) => (i === index ? data : v)));
    } catch (e: any) {
      toast.error(e?.message || 'ছবি নেওয়া যায়নি');
    }
  };

  const submit = async () => {
    if (busy) return;
    if (!auth.currentUser || auth.currentUser.uid !== userData.uid) {
      toast.error('প্রুফ জমা দিতে Email/Google দিয়ে লগইন করুন');
      return;
    }
    if (existing && (existing.status === 'pending' || existing.status === 'approved')) {
      toast.error('এই অফারের প্রুফ আগেই জমা দেওয়া হয়েছে');
      return;
    }
    if (images.some((i) => !i)) {
      toast.error(shots === 2 ? 'দুটি স্ক্রিনশটই দিন' : 'একটি স্ক্রিনশট দিন');
      return;
    }
    setBusy(true);
    try {
      const imageData = images[0] as string;
      const payload: any = {
        uid: userData.uid,
        userName: String(userData.nickname || userData.name || ''),
        userEmail: String(userData.email || auth.currentUser.email || ''),
        offerId,
        offerTitle,
        imageData,
        imageHash: await sha256Hex(imageData),
        status: 'pending',
        createdAt: serverTimestamp()
      };
      if (shots === 2 && images[1]) {
        payload.imageData2 = images[1];
        payload.imageHash2 = await sha256Hex(images[1] as string);
      }
      if (payload.imageHash2 && payload.imageHash2 === payload.imageHash) {
        toast.error('দুটি স্ক্রিনশট আলাদা হতে হবে');
        return;
      }
      // Lock each image hash (create-only): the same screenshot can never be submitted again by anyone.
      const batch = writeBatch(db);
      batch.set(doc(db, 'proofHashes', payload.imageHash), { uid: userData.uid, createdAt: serverTimestamp() });
      if (payload.imageHash2) {
        batch.set(doc(db, 'proofHashes', payload.imageHash2), { uid: userData.uid, createdAt: serverTimestamp() });
      }
      batch.set(doc(db, 'offerProofs', `${userData.uid}_${offerId}`), payload);
      await batch.commit();
      toast.success('প্রুফ জমা হয়েছে! অ্যাডমিন রিভিউ করলে কয়েন পাবেন।');
      onSubmitted?.();
      onClose();
    } catch (e: any) {
      console.error(e);
      toast.error(
        e?.code === 'permission-denied' || e?.message?.includes('permission')
          ? 'জমা দেওয়া যায়নি — সম্ভবত এই স্ক্রিনশট আগে ব্যবহার হয়েছে। নতুন স্ক্রিনশট নিন।'
          : e?.message || 'প্রুফ জমা দেওয়া যায়নি'
      );
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[90] bg-black/80 flex items-end sm:items-center justify-center p-4">
      <div className="w-full max-w-md bg-surface border border-border rounded-3xl p-5 space-y-4 max-h-[90vh] overflow-y-auto">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h4 className="font-black text-lg">Submit Proof</h4>
            <p className="text-xs text-text-muted">{offerTitle}</p>
          </div>
          <button onClick={onClose} className="p-2 rounded-full bg-white/5"><X size={18} /></button>
        </div>

        {existing?.status === 'rejected' && (
          <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-xs text-red-400">
            আগের প্রুফ বাতিল হয়েছে{existing.rejectReason ? `: ${existing.rejectReason}` : ''}। নতুন করে জমা দিন।
          </div>
        )}

        {images.map((img, i) => (
          <div key={i} className="space-y-2">
            <p className="text-[11px] font-bold text-text-muted uppercase tracking-widest">
              {shotLabels?.[i] || `Screenshot ${i + 1}`}
            </p>
            <input
              ref={(el) => { inputs.current[i] = el; }}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => {
                pick(i, e.target.files?.[0]);
                e.target.value = '';
              }}
            />
            {img ? (
              <img src={img} alt={`proof ${i + 1}`} className="w-full max-h-64 object-contain rounded-xl border border-border bg-black" />
            ) : null}
            <button
              type="button"
              onClick={() => inputs.current[i]?.click()}
              className="w-full h-11 rounded-xl bg-white/5 border border-white/10 text-xs font-bold flex items-center justify-center gap-2"
            >
              <Camera size={16} /> {img ? 'ছবি বদলান' : 'গ্যালারি থেকে ছবি নিন'}
            </button>
          </div>
        ))}

        <button
          onClick={submit}
          disabled={busy}
          className="w-full h-12 rounded-xl bg-accent text-black font-black text-sm disabled:opacity-60 flex items-center justify-center gap-2"
        >
          {busy ? <Loader2 size={16} className="animate-spin" /> : null}
          {busy ? 'জমা হচ্ছে...' : 'Submit Proof'}
        </button>
        <p className="text-[10px] text-text-muted text-center">জমা দেওয়ার সময় কোনো কয়েন পাবেন না। অ্যাডমিন অনুমোদন করলে কয়েন যোগ হবে।</p>
      </div>
    </div>
  );
}

/** Shown on each Special Offer card: status, and the Submit Proof button once the link was opened. */
export function OfferProofControls({
  userData,
  offerId,
  offerTitle,
  opened,
  proof
}: {
  userData: any;
  offerId: string;
  offerTitle: string;
  opened: boolean;
  proof?: OfferProof;
}) {
  const [show, setShow] = useState(false);
  const canSubmit = opened && (!proof || proof.status === 'rejected');
  if (!proof && !opened) return null;
  return (
    <div className="space-y-2">
      <ProofStatusBadge proof={proof} />
      {canSubmit && (
        <button
          onClick={() => setShow(true)}
          className="w-full h-10 rounded-xl bg-white/5 border border-accent/30 text-accent text-xs font-black uppercase tracking-widest"
        >
          Submit Proof
        </button>
      )}
      {show && (
        <ProofModal
          userData={userData}
          offerId={offerId}
          offerTitle={offerTitle}
          existing={proof}
          shots={1}
          onClose={() => setShow(false)}
        />
      )}
    </div>
  );
}

export const offerOpenedKey = (uid: string, offerId: string) => `halal_offer_opened_${uid}_${offerId}`;

/** "Complete Task & Earn" card: start -> ad link -> download app & use 1 min -> 2 screenshots -> admin review. */
export function TaskEarnCard({ userData, appConfig }: { userData: any; appConfig: any }) {
  const reward = appConfig?.taskReward ?? TASK_REWARD_COINS;
  const url = appConfig?.taskAdUrl || TASK_AD_URL;
  const storageKey = `halal_task_${userData.uid}`;
  const dayKey = todayKey();
  const proofs = useMyProofs(userData.uid);

  const [started, setStarted] = useState<{ startedAt: number; offerId: string } | null>(() => {
    try {
      const raw = localStorage.getItem(storageKey);
      return raw ? JSON.parse(raw) : null;
    } catch {
      return null;
    }
  });
  const [now, setNow] = useState(Date.now());
  const [showProof, setShowProof] = useState(false);

  useEffect(() => {
    if (!started) return;
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, [started]);

  const clearStarted = () => {
    try { localStorage.removeItem(storageKey); } catch (_) { /* ignore */ }
    setStarted(null);
  };

  // If a proof for the started task already exists (pending/approved), the local "started" state is not needed.
  useEffect(() => {
    if (!started) return;
    const p = proofs[started.offerId];
    if (p && (p.status === 'pending' || p.status === 'approved')) clearStarted();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [proofs, started]);

  const todayOfferId = `task_${dayKey}`;
  const todayProof = proofs[todayOfferId];
  const blocked = !started && !!todayProof && (todayProof.status === 'pending' || todayProof.status === 'approved');

  const startTask = () => {
    const next = { startedAt: Date.now(), offerId: todayOfferId };
    try { localStorage.setItem(storageKey, JSON.stringify(next)); } catch (_) { /* ignore */ }
    setStarted(next);
    setNow(Date.now());
    window.open(url, '_blank');
  };

  const waitLeft = started ? Math.max(0, TASK_MIN_SECONDS - Math.floor((now - started.startedAt) / 1000)) : 0;
  const activeOfferId = started?.offerId || todayOfferId;

  const steps = [
    'Tap the ad',
    'Download the app',
    'Take screenshot',
    'Open for 1 minutes',
    'Take screen shot',
    'Back the web',
    'Submit proof',
    "Don't uninstall the app immediately"
  ];

  return (
    <div className="glass-card p-5 space-y-4 border-l-4 border-l-accent/50">
      <div className="flex items-center gap-3">
        <div className="w-12 h-12 rounded-2xl bg-accent/10 flex items-center justify-center text-accent">
          <Clock size={22} />
        </div>
        <div className="flex-1">
          <h4 className="font-bold text-lg">Complete Task & Earn</h4>
          <p className="text-xs text-text-muted">অ্যাপ ডাউনলোড করে ১ মিনিট চালান, প্রুফ জমা দিন, অনুমোদনের পর কয়েন পান</p>
        </div>
        <span className="text-xs font-black text-accent bg-accent/10 px-3 py-1 rounded-full">+{reward}</span>
      </div>

      <ol className="text-[11px] text-gray-300 space-y-1 list-decimal pl-5">
        {steps.map((s) => (
          <li key={s}>{s}</li>
        ))}
      </ol>

      {blocked ? (
        <div className="space-y-2">
          <p className="text-xs text-text-muted">আজকের টাস্কের প্রুফ জমা হয়েছে:</p>
          <ProofStatusBadge proof={todayProof} />
        </div>
      ) : started ? (
        <div className="space-y-2">
          <button
            onClick={() => setShowProof(true)}
            disabled={waitLeft > 0}
            className="w-full h-12 rounded-xl bg-accent text-black font-black text-sm disabled:opacity-50 active:scale-[0.98] transition-all"
          >
            {waitLeft > 0 ? `ক্লেইম করতে অপেক্ষা করুন (${waitLeft}s)` : '🎁 Claim — Submit Proof'}
          </button>
          <button
            onClick={() => {
              if (window.confirm('টাস্কটি বাতিল করবেন?')) clearStarted();
            }}
            className="w-full h-10 rounded-xl bg-white/5 border border-white/10 text-xs font-bold text-text-muted"
          >
            টাস্ক বাতিল করুন (Cancel)
          </button>
        </div>
      ) : (
        <div className="space-y-2">
          {todayProof?.status === 'rejected' && <ProofStatusBadge proof={todayProof} />}
          <button
            onClick={startTask}
            className="w-full h-12 rounded-xl bg-accent text-black font-black text-sm active:scale-[0.98] transition-all"
          >
            টাস্ক শুরু করুন
          </button>
        </div>
      )}

      {showProof && (
        <ProofModal
          userData={userData}
          offerId={activeOfferId}
          offerTitle="Complete Task & Earn"
          existing={proofs[activeOfferId]}
          shots={2}
          shotLabels={['Screenshot 1 — অ্যাপ ডাউনলোডের পর', 'Screenshot 2 — ১ মিনিট ওপেন রাখার পর']}
          onClose={() => setShowProof(false)}
          onSubmitted={clearStarted}
        />
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Admin side                                                         */
/* ------------------------------------------------------------------ */

export function AdminProofsTab() {
  const isAdmin = auth.currentUser?.email === ADMIN_EMAIL;
  const [proofs, setProofs] = useState<OfferProof[]>([]);
  const [loading, setLoading] = useState(true);
  const [cfg, setCfg] = useState<any>(null);
  const [dups, setDups] = useState<Record<string, boolean>>({});
  const [zoom, setZoom] = useState<string | null>(null);
  const [rejectingId, setRejectingId] = useState<string | null>(null);
  const [reason, setReason] = useState('');
  const [busyId, setBusyId] = useState<string | null>(null);

  useEffect(() => {
    if (!isAdmin) return;
    getDoc(doc(db, 'appConfig', 'general')).then((s) => setCfg(s.data() || {})).catch(() => setCfg({}));
    const q = query(collection(db, 'offerProofs'), where('status', '==', 'pending'));
    const unsub = onSnapshot(
      q,
      (snap) => {
        const list: OfferProof[] = [];
        snap.forEach((d) => list.push({ id: d.id, ...(d.data() as any) } as OfferProof));
        list.sort((a, b) => (b.createdAt?.toMillis?.() ?? 0) - (a.createdAt?.toMillis?.() ?? 0));
        setProofs(list);
        setLoading(false);
      },
      (err) => {
        console.error(err);
        toast.error('Proofs লোড করা যায়নি');
        setLoading(false);
      }
    );
    return () => unsub();
  }, [isAdmin]);

  // Duplicate-image detection: any other proof (any status) with the same imageHash.
  const idsKey = proofs.map((p) => p.id).join('|');
  useEffect(() => {
    if (!isAdmin || proofs.length === 0) return;
    let cancelled = false;
    (async () => {
      const result: Record<string, boolean> = {};
      for (const p of proofs.slice(0, 50)) {
        let dup = false;
        const hashes = [p.imageHash, p.imageHash2].filter(Boolean) as string[];
        for (const h of hashes) {
          for (const field of ['imageHash', 'imageHash2']) {
            try {
              const snap = await getDocs(query(collection(db, 'offerProofs'), where(field, '==', h)));
              snap.forEach((d) => { if (d.id !== p.id) dup = true; });
            } catch (_) { /* ignore */ }
          }
        }
        result[p.id] = dup;
      }
      if (!cancelled) setDups(result);
    })();
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [idsKey, isAdmin]);

  if (!isAdmin) {
    return <p className="text-sm text-text-muted text-center py-10">এই ট্যাব শুধু অ্যাডমিনের জন্য।</p>;
  }

  const approve = async (p: OfferProof) => {
    if (busyId) return;
    setBusyId(p.id);
    try {
      await runTransaction(db, async (tx) => {
        const pRef = doc(db, 'offerProofs', p.id);
        const pSnap = await tx.get(pRef);
        if (!pSnap.exists() || (pSnap.data() as any).status !== 'pending') {
          throw new Error('এই প্রুফ আগেই রিভিউ হয়ে গেছে');
        }
        const proof = pSnap.data() as any;
        const cfgSnap = await tx.get(doc(db, 'appConfig', 'general'));
        const info = rewardForOffer(String(proof.offerId), cfgSnap.data());
        if (!info || !(info.reward > 0)) throw new Error('অফার বা রিওয়ার্ড খুঁজে পাওয়া যায়নি');
        const r = info.reward;
        tx.update(doc(db, 'users', proof.uid), {
          coins: increment(r),
          totalEarnings: increment(r),
          weeklyCoins: increment(r),
          monthlyCoins: increment(r)
        });
        tx.set(doc(collection(db, 'users', proof.uid, 'transactions')), {
          type: 'offer',
          amount: r,
          note: `Offer Reward: ${info.title}`,
          createdAt: Date.now()
        });
        tx.update(pRef, {
          status: 'approved',
          reviewedAt: serverTimestamp(),
          imageData: deleteField(),
          imageData2: deleteField()
        });
      });
      toast.success('Approved — কয়েন যোগ হয়েছে');
    } catch (e: any) {
      console.error(e);
      toast.error(e?.message || 'Approve করা যায়নি');
    } finally {
      setBusyId(null);
    }
  };

  const reject = async (p: OfferProof) => {
    const text = reason.trim();
    if (!text) {
      toast.error('Reject করার কারণ লিখুন');
      return;
    }
    if (busyId) return;
    setBusyId(p.id);
    try {
      await runTransaction(db, async (tx) => {
        const pRef = doc(db, 'offerProofs', p.id);
        const pSnap = await tx.get(pRef);
        if (!pSnap.exists() || (pSnap.data() as any).status !== 'pending') {
          throw new Error('এই প্রুফ আগেই রিভিউ হয়ে গেছে');
        }
        tx.update(pRef, {
          status: 'rejected',
          rejectReason: text,
          reviewedAt: serverTimestamp(),
          imageData: deleteField(),
          imageData2: deleteField()
        });
      });
      toast.success('Rejected');
      setRejectingId(null);
      setReason('');
    } catch (e: any) {
      console.error(e);
      toast.error(e?.message || 'Reject করা যায়নি');
    } finally {
      setBusyId(null);
    }
  };

  if (loading) {
    return <div className="py-10 flex justify-center"><Loader2 className="animate-spin text-accent" /></div>;
  }

  return (
    <div className="space-y-4">
      <h3 className="text-xs font-black uppercase tracking-[0.2em] px-1">Pending Proofs ({proofs.length})</h3>

      {proofs.length === 0 && (
        <p className="text-sm text-text-muted text-center py-10">কোনো পেন্ডিং প্রুফ নেই।</p>
      )}

      {proofs.map((p) => {
        const info = rewardForOffer(String(p.offerId), cfg || {});
        return (
          <div key={p.id} className="p-4 bg-surface border border-border rounded-3xl space-y-3">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <p className="font-black truncate">{p.userName || 'User'}</p>
                <p className="text-[11px] text-text-muted truncate">{p.userEmail}</p>
              </div>
              <div className="text-right shrink-0">
                <p className="text-xs font-black text-accent">+{info ? info.reward : '?'} coins</p>
                {dups[p.id] && (
                  <span className="inline-flex items-center gap-1 mt-1 px-2 py-0.5 rounded-full bg-red-500/10 border border-red-500/30 text-red-400 text-[10px] font-black">
                    <AlertCircle size={10} /> Duplicate image
                  </span>
                )}
              </div>
            </div>
            <p className="text-xs text-text-muted">Offer: <span className="text-white font-bold">{p.offerTitle}</span></p>

            <div className="grid grid-cols-2 gap-2">
              {[p.imageData, p.imageData2].filter(Boolean).map((img, i) => (
                <img
                  key={i}
                  src={img as string}
                  alt={`proof ${i + 1}`}
                  onClick={() => setZoom(img as string)}
                  className="w-full h-40 object-cover rounded-xl border border-border bg-black cursor-zoom-in"
                />
              ))}
            </div>

            {rejectingId === p.id ? (
              <div className="space-y-2">
                <textarea
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  placeholder="Reject করার কারণ (বাধ্যতামূলক)"
                  className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-xs outline-none"
                  rows={2}
                />
                <div className="flex gap-2">
                  <button
                    onClick={() => reject(p)}
                    disabled={busyId === p.id}
                    className="flex-1 h-10 rounded-xl bg-red-500 text-white text-xs font-black disabled:opacity-60"
                  >
                    Confirm Reject
                  </button>
                  <button
                    onClick={() => { setRejectingId(null); setReason(''); }}
                    className="flex-1 h-10 rounded-xl bg-white/5 border border-white/10 text-xs font-bold"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex gap-2">
                <button
                  onClick={() => approve(p)}
                  disabled={busyId === p.id}
                  className="flex-1 h-10 rounded-xl bg-accent text-black text-xs font-black flex items-center justify-center gap-1 disabled:opacity-60"
                >
                  {busyId === p.id ? <Loader2 size={14} className="animate-spin" /> : <Check size={14} />} Approve
                </button>
                <button
                  onClick={() => { setRejectingId(p.id); setReason(''); }}
                  disabled={busyId === p.id}
                  className="flex-1 h-10 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 text-xs font-black flex items-center justify-center gap-1 disabled:opacity-60"
                >
                  <X size={14} /> Reject
                </button>
              </div>
            )}
          </div>
        );
      })}

      {zoom && (
        <div className="fixed inset-0 z-[100] bg-black/95 flex items-center justify-center p-3" onClick={() => setZoom(null)}>
          <img src={zoom} alt="zoom" className="max-w-full max-h-full object-contain" />
        </div>
      )}
    </div>
  );
}
