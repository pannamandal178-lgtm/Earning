import React, { useEffect, useRef, useState } from 'react';
import { toast } from 'react-hot-toast';
import { ArrowLeft } from 'lucide-react';
import { collection, doc, increment, writeBatch } from 'firebase/firestore';
import { auth, db } from '../firebase';
import { tr } from '../lib/i18n';
import { useFeatureConfig } from '../lib/featureConfig';
import { AdFrame } from './AdFrame';
import { BonusProofPanel, slotInfo, useMyProofs } from './Proofs';

const FRUITS = ['🍎', '🍌', '🍇', '🍊', '🍉'];
const STAGE_SECONDS = 10;

const todayStr = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};

type Phase = 'playing' | 'ended' | 'ad' | 'bombAd' | 'chosen' | 'bonusOffer' | 'bonusAd' | 'bonusProof' | 'limit';

interface FallingItem {
  el: HTMLDivElement;
  x: number;
  y: number;
  isBomb: boolean;
  speed: number;
}

export function PlayAndEarnScreen({ userData, onBack }: { userData: any; onBack: () => void; appConfig?: any }) {
  const features = useFeatureConfig();
  const featRef = useRef(features);
  featRef.current = features;
  const proofs = useMyProofs(userData.uid);
  const proofsRef = useRef(proofs);
  proofsRef.current = proofs;

  const playRef = useRef<HTMLDivElement>(null);
  const basketRef = useRef<HTMLDivElement>(null);

  const initialGames = userData?.gameDate === todayStr() ? Number(userData?.dailyGames) || 0 : 0;
  const dailyRef = useRef({ date: todayStr(), games: initialGames });

  const [timeLeft, setTimeLeft] = useState(STAGE_SECONDS);
  const [gems, setGems] = useState(0);
  const [sessionCoins, setSessionCoins] = useState(0);
  const [gamesToday, setGamesToday] = useState(initialGames);
  const [phase, setPhase] = useState<Phase>('playing');
  const [title, setTitle] = useState('');
  const [completed, setCompleted] = useState(false);
  const [bonusSlot, setBonusSlot] = useState<number>(1);

  // Mutable game state (kept out of React state: updated every 20 ms)
  const g = useRef({
    playing: false,
    gems: 0,
    basketX: 200,
    W: 360,
    H: 460,
    timeLeft: STAGE_SECONDS,
    items: [] as FallingItem[],
    gameInt: 0,
    spawnInt: 0,
    timerInt: 0
  });

  const clearTimers = () => {
    const st = g.current;
    window.clearInterval(st.gameInt);
    window.clearInterval(st.spawnInt);
    window.clearInterval(st.timerInt);
  };

  const clearItems = () => {
    const st = g.current;
    st.items.forEach((o) => o.el.remove());
    st.items = [];
  };

  const placeBasket = () => {
    const st = g.current;
    st.basketX = Math.min(Math.max(st.basketX, 35), st.W - 35);
    if (basketRef.current) basketRef.current.style.left = st.basketX + 'px';
  };

  const catchAnim = () => {
    const b = basketRef.current;
    if (!b) return;
    b.style.transform = 'translateX(-50%) scale(1.2) rotate(5deg)';
    window.setTimeout(() => {
      if (basketRef.current) basketRef.current.style.transform = 'translateX(-50%)';
    }, 150);
  };

  const endGame = (didComplete: boolean) => {
    const st = g.current;
    st.playing = false;
    clearTimers();
    clearItems();
    setCompleted(didComplete);
    setTitle(didComplete ? tr('game.timeUp') : tr('game.boom'));
    // Bomb: an ad is shown, but no coins are given
    setPhase(didComplete ? 'ended' : 'bombAd');
  };

  const spawnItem = () => {
    const st = g.current;
    const area = playRef.current;
    if (!st.playing || !area) return;
    const isBomb = Math.random() < 0.15;
    const x = Math.floor(Math.random() * Math.max(10, st.W - 56)) + 10;
    const el = document.createElement('div');
    el.style.cssText = `position:absolute;width:36px;height:36px;font-size:28px;display:flex;align-items:center;justify-content:center;top:-40px;left:${x}px;z-index:3;pointer-events:none;`;
    el.textContent = isBomb ? '💣' : FRUITS[Math.floor(Math.random() * FRUITS.length)];
    area.appendChild(el);
    st.items.push({ el, x, y: -40, isBomb, speed: Math.random() * 1 + 3 });
  };

  const updateGame = () => {
    const st = g.current;
    if (!st.playing) return;
    for (let i = st.items.length - 1; i >= 0; i--) {
      const o = st.items[i];
      o.y += o.speed;
      o.el.style.top = o.y + 'px';

      if (o.y >= st.H - 48 && o.y <= st.H + 2) {
        if (Math.abs(o.x + 18 - st.basketX) < 38) {
          catchAnim();
          o.el.remove();
          st.items.splice(i, 1);
          if (o.isBomb) {
            st.gems = 0;
            setGems(0);
            endGame(false);
            return;
          }
          st.gems += 1;
          setGems(st.gems);
          continue;
        }
      }
      if (o.y > st.H + 22) {
        o.el.remove();
        st.items.splice(i, 1);
      }
    }
  };

  const startGame = () => {
    const st = g.current;
    const area = playRef.current;
    if (!area) return;
    clearTimers();
    clearItems();

    const today = todayStr();
    if (dailyRef.current.date !== today) {
      dailyRef.current = { date: today, games: 0 };
      setGamesToday(0);
    }
    if (dailyRef.current.games >= featRef.current.gameDailyLimit) {
      st.playing = false;
      setTitle(tr('game.limitReached'));
      setPhase('limit');
      return;
    }

    const rect = area.getBoundingClientRect();
    st.W = rect.width || 360;
    st.H = rect.height || 460;
    st.basketX = st.W / 2;
    placeBasket();

    st.timeLeft = STAGE_SECONDS;
    st.gems = 0;
    st.playing = true;
    setTimeLeft(STAGE_SECONDS);
    setGems(0);
    setPhase('playing');
    setTitle('');

    st.gameInt = window.setInterval(updateGame, 20);
    st.spawnInt = window.setInterval(spawnItem, 700);
    st.timerInt = window.setInterval(() => {
      st.timeLeft -= 1;
      setTimeLeft(Math.max(0, st.timeLeft));
      if (st.timeLeft <= 0) endGame(true);
    }, 1000);
  };

  // Basket control (mouse + touch)
  useEffect(() => {
    const area = playRef.current;
    if (!area) return;
    const move = (clientX: number) => {
      const st = g.current;
      if (!st.playing) return;
      st.basketX = clientX - area.getBoundingClientRect().left;
      placeBasket();
    };
    const onMouse = (e: MouseEvent) => move(e.clientX);
    const onTouch = (e: TouchEvent) => {
      // Only block the browser while a game is running. Otherwise the popup buttons
      // (which live inside this area) never receive their tap/click.
      if (!g.current.playing) return;
      if (e.touches[0]) move(e.touches[0].clientX);
      e.preventDefault();
    };
    area.addEventListener('mousemove', onMouse);
    area.addEventListener('touchmove', onTouch, { passive: false });
    area.addEventListener('touchstart', onTouch, { passive: false });
    return () => {
      area.removeEventListener('mousemove', onMouse);
      area.removeEventListener('touchmove', onTouch);
      area.removeEventListener('touchstart', onTouch);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    startGame();
    return () => {
      g.current.playing = false;
      clearTimers();
      clearItems();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /** Adds the per-game coins instantly and counts the game for today's limit. */
  const awardGameCoins = async (amount: number): Promise<boolean> => {
    if (!auth.currentUser || auth.currentUser.uid !== userData.uid) {
      toast.error(tr('game.loginToClaim'));
      return false;
    }
    const today = todayStr();
    if (dailyRef.current.date !== today) dailyRef.current = { date: today, games: 0 };
    if (dailyRef.current.games >= featRef.current.gameDailyLimit) {
      toast.error(tr('game.limitReached'));
      return false;
    }
    const newGames = dailyRef.current.games + 1;
    try {
      const batch = writeBatch(db);
      batch.update(doc(db, 'users', userData.uid), {
        coins: increment(amount),
        totalEarnings: increment(amount),
        weeklyCoins: increment(amount),
        monthlyCoins: increment(amount),
        gameDate: today,
        dailyGames: newGames
      });
      batch.set(doc(collection(db, 'users', userData.uid, 'transactions')), {
        type: 'game',
        amount,
        note: 'Play & Earn: game reward',
        createdAt: Date.now()
      });
      await batch.commit();
      dailyRef.current.games = newGames;
      setGamesToday(newGames);
      setSessionCoins((c) => c + amount);
      toast.success(tr('game.rewardedToast', { coins: amount }));
      return true;
    } catch (e) {
      console.error(e);
      toast.error(tr('game.claimFailed'));
      return false;
    }
  };

  const tapBonus = () => {
    if (!auth.currentUser || auth.currentUser.uid !== userData.uid) {
      toast.error(tr('game.loginToClaim'));
      return;
    }
    setPhase('ad');
  };

  const onAdDone = async () => {
    const f = featRef.current;
    const ok = await awardGameCoins(f.gameCoinsPerGame);
    if (!ok) {
      setPhase('ended');
      return;
    }
    const bonusFree = slotInfo(proofsRef.current, 'gamebonus', f.gameBonusDailyLimit).freeSlot;
    if (dailyRef.current.games === f.gameBonusAfter && bonusFree !== null) {
      setBonusSlot(bonusFree);
      setPhase('bonusOffer');
    } else {
      setTitle(tr('game.rewarded', { coins: f.gameCoinsPerGame }));
      setPhase('chosen');
    }
  };

  const skipReward = () => {
    setTitle(tr('game.skipped'));
    setPhase('chosen');
  };

  const popupVisible = phase === 'ended' || phase === 'chosen' || phase === 'bonusOffer' || phase === 'limit';
  const limitHit = gamesToday >= features.gameDailyLimit;

  return (
    <div className="space-y-4 pb-24">
      <div className="flex items-center gap-3">
        <button onClick={onBack} className="p-2 rounded-full bg-white/5 border border-white/10">
          <ArrowLeft size={18} />
        </button>
        <div>
          <h2 className="text-xl font-bold tracking-tight">{tr('game.title')}</h2>
          <p className="text-[10px] text-text-muted">{tr('game.sub')}</p>
        </div>
        <span className="ml-auto text-[10px] font-black text-accent bg-accent/10 px-3 py-1 rounded-full">
          {tr('game.today', { n: gamesToday, limit: features.gameDailyLimit })}
        </span>
      </div>

      <div
        style={{
          width: '100%',
          maxWidth: 400,
          height: 500,
          margin: '0 auto',
          background: '#1e293b',
          borderRadius: 16,
          border: '2px solid #334155',
          overflow: 'hidden',
          display: 'flex',
          flexDirection: 'column',
          position: 'relative',
          userSelect: 'none',
          WebkitUserSelect: 'none'
        }}
      >
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            padding: '12px 18px',
            fontSize: 13,
            fontWeight: 'bold',
            background: '#334155',
            borderBottom: '2px solid #475569',
            zIndex: 10
          }}
        >
          <span>⏳ {tr('game.time')}: {timeLeft}s</span>
          <span>💎 {tr('game.gems')}: {gems}</span>
          <span>🪙 {tr('game.coins')}: {sessionCoins}</span>
        </div>

        <div
          ref={playRef}
          style={{
            flexGrow: 1,
            position: 'relative',
            background: 'linear-gradient(180deg, #1e293b 0%, #0f172a 100%)',
            overflow: 'hidden',
            touchAction: 'none'
          }}
        >
          <div
            ref={basketRef}
            style={{
              position: 'absolute',
              bottom: 15,
              left: '50%',
              width: 70,
              height: 40,
              fontSize: 38,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              transform: 'translateX(-50%)',
              zIndex: 5,
              transition: 'left 0.05s linear, transform 0.15s ease'
            }}
          >
            🧺
          </div>

          {popupVisible && (
            <div
              style={{
                position: 'absolute',
                top: '50%',
                left: '50%',
                transform: 'translate(-50%, -50%)',
                fontWeight: 'bold',
                color: '#facc15',
                textAlign: 'center',
                background: 'rgba(15, 23, 42, 0.95)',
                padding: 24,
                borderRadius: 16,
                width: '88%',
                border: '2px solid #475569',
                boxShadow: '0 20px 40px rgba(0,0,0,0.8)',
                zIndex: 20
              }}
            >
              {phase === 'ended' && (
                <>
                  <div style={{ fontSize: 18 }}>{title}</div>
                  {completed ? (
                    <>
                      <div style={{ marginTop: 12, fontSize: 15 }}>
                        {tr('game.collected', { n: gems })}
                      </div>
                      <div style={{ fontSize: 12, color: '#94a3b8', fontWeight: 'normal', marginTop: 8 }}>
                        {tr('game.hint', { coins: features.gameCoinsPerGame })}
                      </div>
                      <div style={{ display: 'flex', gap: 10, marginTop: 15 }}>
                        <button
                          onClick={skipReward}
                          style={{ flex: 1, background: 'linear-gradient(135deg,#ef4444,#dc2626)', color: '#fff', border: 'none', padding: '10px 12px', fontSize: 13, fontWeight: 'bold', borderRadius: 8 }}
                        >
                          {tr('game.next')}
                        </button>
                        <button
                          onClick={tapBonus}
                          style={{ flex: 1, background: 'linear-gradient(135deg,#22c55e,#16a34a)', color: '#fff', border: 'none', padding: '10px 12px', fontSize: 13, fontWeight: 'bold', borderRadius: 8 }}
                        >
                          {tr('game.bonus', { coins: features.gameCoinsPerGame })}
                        </button>
                      </div>
                    </>
                  ) : (
                    <button
                      onClick={startGame}
                      style={{ width: '100%', marginTop: 15, padding: 10, background: 'linear-gradient(135deg,#38bdf8,#0284c7)', color: '#fff', border: 'none', fontWeight: 'bold', borderRadius: 8 }}
                    >
                      {tr('game.nextGame')}
                    </button>
                  )}
                </>
              )}

              {phase === 'chosen' && (
                <>
                  <div style={{ fontSize: 16 }}>{title}</div>
                  {limitHit ? (
                    <div style={{ marginTop: 12, fontSize: 13, color: '#f87171' }}>{tr('game.limitReached')}</div>
                  ) : (
                    <button
                      onClick={startGame}
                      style={{ width: '100%', marginTop: 15, padding: 10, background: 'linear-gradient(135deg,#38bdf8,#0284c7)', color: '#fff', border: 'none', fontWeight: 'bold', borderRadius: 8 }}
                    >
                      {tr('game.nextGame')}
                    </button>
                  )}
                </>
              )}

              {phase === 'bonusOffer' && (
                <>
                  <div style={{ fontSize: 18 }}>{tr('game.bonusOfferTitle')}</div>
                  <div style={{ fontSize: 13, color: '#cbd5e1', fontWeight: 'normal', marginTop: 10, lineHeight: 1.5 }}>
                    {tr('game.bonusOfferText', { coins: features.gameBonusCoins })}
                  </div>
                  <div style={{ display: 'flex', gap: 10, marginTop: 15 }}>
                    <button
                      onClick={() => {
                        setTitle(tr('game.rewarded', { coins: features.gameCoinsPerGame }));
                        setPhase('chosen');
                      }}
                      style={{ flex: 1, background: 'linear-gradient(135deg,#64748b,#475569)', color: '#fff', border: 'none', padding: '10px 12px', fontSize: 14, fontWeight: 'bold', borderRadius: 8 }}
                    >
                      {tr('game.skip')}
                    </button>
                    <button
                      onClick={() => setPhase('bonusAd')}
                      style={{ flex: 1, background: 'linear-gradient(135deg,#22c55e,#16a34a)', color: '#fff', border: 'none', padding: '10px 12px', fontSize: 14, fontWeight: 'bold', borderRadius: 8 }}
                    >
                      {tr('game.claim')}
                    </button>
                  </div>
                </>
              )}

              {phase === 'limit' && (
                <>
                  <div style={{ fontSize: 16, color: '#f87171' }}>{tr('game.limitReached')}</div>
                  <button
                    onClick={onBack}
                    style={{ width: '100%', marginTop: 15, padding: 10, background: 'linear-gradient(135deg,#38bdf8,#0284c7)', color: '#fff', border: 'none', fontWeight: 'bold', borderRadius: 8 }}
                  >
                    {tr('game.back')}
                  </button>
                </>
              )}
            </div>
          )}
        </div>
      </div>

      {phase === 'ad' && (
        <AdFrame
          scriptUrl={features.gameAdScriptUrl}
          seconds={features.gameAdSeconds}
          onDone={onAdDone}
          onCancel={() => setPhase('ended')}
        />
      )}

      {phase === 'bombAd' && (
        <AdFrame
          scriptUrl={features.gameAdScriptUrl}
          seconds={features.gameAdSeconds}
          reward={false}
          onDone={() => setPhase('ended')}
          onCancel={() => setPhase('ended')}
        />
      )}

      {phase === 'bonusAd' && (
        <AdFrame
          scriptUrl={features.gameAdScriptUrl}
          seconds={features.gameAdSeconds}
          onDone={() => setPhase('bonusProof')}
          onCancel={() => {
            setTitle(tr('game.rewarded', { coins: features.gameCoinsPerGame }));
            setPhase('chosen');
          }}
        />
      )}

      {phase === 'bonusProof' && (
        <BonusProofPanel
          userData={userData}
          offerId={`gamebonus_${bonusSlot}`}
          coins={features.gameBonusCoins}
          existing={proofs[`gamebonus_${bonusSlot}`]}
          onSubmitted={() => {
            setTitle(tr('game.bonusSubmitted'));
            setPhase('chosen');
          }}
          onCancel={() => {
            setTitle(tr('game.rewarded', { coins: features.gameCoinsPerGame }));
            setPhase('chosen');
          }}
        />
      )}
    </div>
  );
}
