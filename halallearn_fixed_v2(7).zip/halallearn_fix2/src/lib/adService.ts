import {
  GOOGLE_H5_AD_CLIENT,
  RICHADS_PUB_ID,
  RICHADS_APP_ID
} from '../constants';

type AdEventType = 'loading' | 'started' | 'completed' | 'closed' | 'error';

interface AdConfig {
  onEvent: (event: AdEventType, message?: string) => void;
  googleH5AdClient?: string;
}

interface RichAdsControllerLike {
  initialize: (config: { pubId: string; appId: string; debug?: boolean }) => void;
  triggerInterstitialVideo: () => Promise<unknown>;
}

class AdService {
  private static instance: AdService;

  private constructor() {}

  static getInstance(): AdService {
    if (!AdService.instance) {
      AdService.instance = new AdService();
    }
    return AdService.instance;
  }

  private async getRichAdsController(): Promise<RichAdsControllerLike> {
    const win = window as any;

    if (!win.TelegramAdsController) {
      const existing = document.getElementById('richads-sdk');
      if (!existing) {
        const script = document.createElement('script');
        script.id = 'richads-sdk';
        script.src = 'https://richinfo.co/richpartners/telegram/js/tg-ob.js';
        script.async = true;
        document.head.appendChild(script);
        await new Promise<void>((resolve, reject) => {
          script.addEventListener('load', () => resolve(), { once: true });
          script.addEventListener('error', () => reject(new Error('RichAds SDK failed to load')), { once: true });
        });
      } else {
        await new Promise<void>((resolve) => {
          const started = Date.now();
          const timer = window.setInterval(() => {
            if (win.TelegramAdsController || Date.now() - started > 5000) {
              window.clearInterval(timer);
              resolve();
            }
          }, 50);
        });
      }
    }

    if (!win.TelegramAdsController) {
      throw new Error('RichAds SDK is unavailable');
    }

    if (!win.__ammoRichAdsController) {
      const controller = new win.TelegramAdsController();
      controller.initialize({
        pubId: RICHADS_PUB_ID,
        appId: RICHADS_APP_ID,
        debug: false
      });
      win.__ammoRichAdsController = controller;
    }

    return win.__ammoRichAdsController as RichAdsControllerLike;
  }

  async showInterstitialAd(config: AdConfig): Promise<void> {
    return this.showRichAdsVideo(config);
  }

  async showRewardedAd(config: AdConfig): Promise<void> {
    // RichAds Telegram Mini App video is the primary ad provider.
    // Google H5 remains available only when explicitly configured as a fallback.
    try {
      return await this.showRichAdsVideo(config);
    } catch (richAdsError) {
      console.warn('RichAds video failed:', richAdsError);
      const finalGoogleH5Client = config.googleH5AdClient || GOOGLE_H5_AD_CLIENT;
      if (finalGoogleH5Client) {
        return this.showGoogleH5Ad(config, finalGoogleH5Client);
      }
      config.onEvent('error', 'RichAds video unavailable right now');
    }
  }

  private async showRichAdsVideo(config: AdConfig): Promise<void> {
    config.onEvent('loading');

    try {
      const controller = await this.getRichAdsController();
      config.onEvent('started');

      // RichAds resolves/rejects the trigger promise with the ad/reward result.
      // Rewarding should only be enabled in the RichAds publisher configuration.
      await controller.triggerInterstitialVideo();

      config.onEvent('completed');
      config.onEvent('closed');
    } catch (e) {
      console.error('RichAds error:', e);
      config.onEvent('error', 'RichAds video failed to load or complete');
      throw e;
    }
  }

  private async showGoogleH5Ad(config: AdConfig, clientId: string): Promise<void> {
    config.onEvent('loading');

    if (!(window as any).adBreak) {
      const script = document.createElement('script');
      script.src = `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${clientId}`;
      script.async = true;
      script.crossOrigin = 'anonymous';
      document.head.appendChild(script);

      await new Promise<void>((resolve, reject) => {
        script.onload = () => resolve();
        script.onerror = () => reject(new Error('Google H5 Ads failed to load'));
      });
    }

    try {
      (window as any).adBreak({
        type: 'reward',
        name: 'watch_ad_reward',
        beforeAd: () => config.onEvent('started'),
        afterAd: () => config.onEvent('closed'),
        adBreakDone: (placementInfo: any) => {
          if (placementInfo.breakStatus === 'COMPLETED') {
            config.onEvent('completed');
          } else {
            config.onEvent('error', 'Ad not completed');
          }
        }
      });
    } catch (e) {
      console.error(e);
      config.onEvent('error', 'Google H5 Ads failed');
      throw e;
    }
  }

}

export const adService = AdService.getInstance();
