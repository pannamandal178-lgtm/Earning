import { GOOGLE_H5_AD_CLIENT } from '../constants';

type AdEventType = 'loading' | 'started' | 'completed' | 'closed' | 'error';

interface AdConfig {
  onEvent: (event: AdEventType, message?: string) => void;
  googleH5AdClient?: string;
}

class AdService {
  private static instance: AdService;

  private constructor() {}

  static getInstance(): AdService {
    if (!AdService.instance) {
      AdService.instance = new AdService();
    }
    return AdService.instance;
  }

  async showInterstitialAd(config: AdConfig): Promise<void> {
    const finalGoogleH5Client = config.googleH5AdClient || GOOGLE_H5_AD_CLIENT;

    if (finalGoogleH5Client) {
      return this.showGoogleH5Interstitial(config, finalGoogleH5Client);
    }

    return this.showRewardedPopup(config);
  }

  private async showGoogleH5Interstitial(config: AdConfig, clientId: string): Promise<void> {
    config.onEvent('loading');
    
    if (!(window as any).adBreak) {
      const script = document.createElement('script');
      script.src = `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${clientId}`;
      script.async = true;
      script.crossOrigin = "anonymous";
      document.head.appendChild(script);

      await new Promise((resolve) => {
        script.onload = resolve;
      });
    }

    try {
      (window as any).adBreak({
        type: 'interstitial',
        name: 'interstitial_transition',
        beforeAd: () => config.onEvent('started'),
        afterAd: () => config.onEvent('closed'),
        adBreakDone: (placementInfo: any) => {
          config.onEvent('completed');
        }
      });
    } catch (e) {
      console.error(e);
      config.onEvent('error', 'Google H5 Interstitial failed');
    }
  }

  async showRewardedAd(config: AdConfig): Promise<void> {
    const finalGoogleH5Client = config.googleH5AdClient || GOOGLE_H5_AD_CLIENT;

    // Priority 1: Google H5 Ads (only if a client ID is configured)
    if (finalGoogleH5Client) {
      return this.showGoogleH5Ad(config, finalGoogleH5Client);
    }

    // Default: Rewarded Popup
    return this.showRewardedPopup(config);
  }

  private async showGoogleH5Ad(config: AdConfig, clientId: string): Promise<void> {
    config.onEvent('loading');
    
    if (!(window as any).adBreak) {
      const script = document.createElement('script');
      script.src = `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${clientId}`;
      script.async = true;
      script.crossOrigin = "anonymous";
      document.head.appendChild(script);

      await new Promise((resolve) => {
        script.onload = resolve;
      });
    }

    try {
      (window as any).adBreak({
        type: 'reward',
        name: 'watch_ad_reward',
        beforeAd: () => config.onEvent('started'),
        afterAd: () => config.onEvent('closed'),
        adBreakDone: (placementInfo: any) => {
          if (placementInfo.breakStatus === 'COMPLETED') {
            config.onEvent('completed');
          } else {
            console.warn("Ad break status:", placementInfo.breakStatus);
            config.onEvent('error', 'Ad not completed');
          }
        }
      });
    } catch (e) {
      console.error(e);
      config.onEvent('error', 'Google H5 Ads failed');
    }
  }

  // Rewarded Popup (SDK loaded in index.html, zone 11932994)
  private async showRewardedPopup(config: AdConfig): Promise<void> {
    config.onEvent('loading');

    const showAd = (window as any).show_11932994;
    if (typeof showAd !== 'function') {
      // SDK not loaded (blocked / offline) — no ad, no reward
      config.onEvent('error', 'Ad unavailable right now. Try again!');
      return;
    }

    config.onEvent('started');
    try {
      await showAd('pop');
      // User watched the ad till the end or closed it
      config.onEvent('completed');
      config.onEvent('closed');
    } catch (e) {
      console.warn('Rewarded popup failed:', e);
      config.onEvent('error', 'Ad could not be shown. Try again!');
    }
  }
}

export const adService = AdService.getInstance();
